package main;
import board.*;
import piece.*;
import defaults.*;

import java.util.*;
import java.util.regex.*;

import javafx.application.Application;
import javafx.event.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.geometry.*;
import javafx.scene.input.*;

/**
 * The UniversalChessboardGUI class is the main class of the Universal</br>
 * Chessboard.
 * @author Adam
 *
 */
public class UniversalChessboardGUI extends Application {
	private Stage boardStage = new Stage(); // board stage
	private Scene boardScene; // board scene

	// Dialog Objects

	private Stage confirmStage = new Stage();
	private int confirmOptionChosen = -1;
	private Stage gamePresetsStage = new Stage(); // dialog for changing square colors
	private Stage fenCodeStage = new Stage(); // dialog for editing FEN Code
	private Stage fenCodeHelpStage = new Stage(); // help dialog for FEN Code
	private Stage fenCodeRequirementsStage = new Stage(); // dialog showing FEN Code requirements
	private Stage gameMovesStage = new Stage(); // dialog for editing game moves
	private Stage gameMoveHelpStage = new Stage(); // help dialog for game moves
	private Stage gameMoveRequirementsStage = new Stage(); // dialog showing game move requirements
	private Stage moveHistoryStage = new Stage();
	private TextArea moveHistory = new TextArea();
	private Stage holdingsStage = new Stage();
	private GridPane holdingsDisplay = new GridPane();
	private Stage colorsStage = new Stage(); // dialog for changing board colors
	private Stage highlightsStage = new Stage(); // dialog for changing board highlights
	private Stage promotionStage = new Stage();
	private Stage aboutStage = new Stage();
	private Stage licenseStage = new Stage();
	private Stage pieceCreditsStage = new Stage();
	private Stage modificationsStage = new Stage();
	private Stage keyBindingsStage = new Stage();
	
	// Board GUI Objects
	
	private MenuBar boardMenu; // board menu
	private GridPane boardDisplay; // visual representation of board
	private ScrollPane scrollPane;
	private StackPane boardPane;
	private VBox mainVBox;
	private HBox menuHBox;
	private Board board; // internal board
	private boolean[][] shades; // controls shading of squares. true equals dark shade.
	private PieceList pieceList;
	private int nFiles;
	private int nRanks;
	
	private StringBuffer defaultSelectedPieceColor = new StringBuffer("#80FF80"); // default selected piece color
	private StringBuffer defaultLastMoveColor = new StringBuffer("#00FF00"); // highlight for last move (origin and destination squares)
	private StringBuffer defaultLastLocustCaptureColor = new StringBuffer("#FFC000"); // highlight for last move (intermediate squares)
	private StringBuffer defaultMoveColor = new StringBuffer("#FFFF00"); // highlight for move to empty square
	private StringBuffer defaultCaptureColor = new StringBuffer("#FF0000"); // highlight for capturing enemy pieces
	private StringBuffer defaultDestroyColor = new StringBuffer("#0000FF"); // highlight for destroying friendly pieces
	private StringBuffer defaultLocustCaptureColor = new StringBuffer("#00FFFF"); // highlight for locust captures
	
	private StringBuffer defaultHoleColor = new StringBuffer("#000000");
	private StringBuffer defaultHoleBorderColor = new StringBuffer("#FFFFFF");
	
	private StringBuffer selectedPieceColor = new StringBuffer("#80FF80"); // default selected piece color
	private StringBuffer lastMoveColor = new StringBuffer("#00FF00"); // highlight for last move (origin and destination squares)
	private StringBuffer lastLocustCaptureColor = new StringBuffer("#FFC000"); // highlight for last move (intermediate squares)
	private StringBuffer moveColor = new StringBuffer("#FFFF00"); // highlight for move to empty square
	private StringBuffer captureColor = new StringBuffer("#FF0000"); // highlight for capturing enemy pieces
	private StringBuffer destroyColor = new StringBuffer("#0000FF"); // highlight for destroying friendly pieces
	private StringBuffer locustCaptureColor = new StringBuffer("#00FFFF"); // highlight for locust captures
	
	private StringBuffer holeColor = new StringBuffer("#000000");
	private StringBuffer holeBorderColor = new StringBuffer("#FFFFFF");

	private ViewingScreen viewingScreen; // screen size
	private double titleBarSize;
	private double screenWidth;
	private double screenHeight;
	
	private StringBuffer preset = new StringBuffer("default");

	// Board Display Properties

	// Default color of light squares
	private StringBuffer defaultLightShade = new StringBuffer("#FFCC9C");
	// Default color of dark squares
	private StringBuffer defaultDarkShade = new StringBuffer("#CF8948");
	// Color of light squares
	private StringBuffer lightShade = new StringBuffer("#FFCC9C");
	// Color of dark squares
	private StringBuffer darkShade = new StringBuffer("#CF8948");
	// Size of board squares
	private int squareSize = 54;
	// Whether piece images should be flipped when the board is flipped.
	private boolean flipPiecesOnBoardFlip = false;
	// Whether to flip the board.
	private boolean flipView = false;
	/*
	 * Whether to use Shogi-style coordinates and piece IDs. Affects move
	 * coordinates and piece IDs in moves and FEN Strings.
	 */
	private boolean shogiMode = false;
	
	// Variables for moving pieces
	
	/*
	 * Whether to disable board events.
	 * Set to true whenever something could change vital board statistics and
	 * set to false when that something is gone.
	 */
	private boolean disableBoardEvents = false;
	
	/*
	 * Whether to disable menu events.
	 * Set to true whenever something occurs that should disable certain
	 * menus and set to false when that something is gone.
	 */
	private boolean disableMenuEvents = false;
	
	/*
	 * Whether to disable changing.
	 * Set to true whenever board events should stay enabled/
	 * disabled and set to false otherwise.
	 */
	private boolean preventBoardEventToggling = false;
	
	// Whether a piece is selected. Set to true if a piece is selected
	private boolean pieceSelected = false;
	
	// Move Parts
	private int originX = -1; // origin
	private int originY = -1;
	private ArrayList<Integer> ex = new ArrayList<Integer>(); // intermediate squares, if present
	private ArrayList<Integer> ey = new ArrayList<Integer>();
	private int destX = -1; // destination
	private int destY = -1;
	private int promotion = -1; // promotion, if present
	
	private int promotionOption;
	
	private int lastEX = -1;
	private int lastEY = -1;

	// Initialize Application

	public static void main(String[] args) {
		launch(args);
	}

	/**
	 * GUI
	 */
	public void start(Stage primaryStage) {
		createMenu();
		createBoard();
		ResetEvents(true);
		boardStage = primaryStage;
		mainVBox = new VBox(menuHBox, boardPane);
		mainVBox.setAlignment(Pos.TOP_CENTER);
		mainVBox.setSpacing(0.0);
		mainVBox.setPadding(new Insets(0));
		boardScene = new Scene(mainVBox);
		createKeyBoardShortcuts();
		boardStage.setScene(boardScene);
		boardStage.setTitle("Universal Chessboard - Chess");
		
		boardStage.setOnCloseRequest(e -> {
			closeExcessDialogs();
			System.exit(0);
		});
		boardStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
		boardStage.show();
		resetViewingSize();
	}

	// Menu Event Handlers

	// File Menu
	
	// New Game
	private EventHandler<ActionEvent> newGameEvent = e -> {
		if(disableMenuEvents == true)
		{
			e.consume();
		}
		else
		{
			closeExcessDialogs();
			newGame(true);
		}
	};
	
	// Load Game Preset...
	private EventHandler<ActionEvent> loadGamePresetEvent = e -> {
		if(disableMenuEvents == true)
		{
			e.consume();
		}
		else
		{
			closeExcessDialogs();
			disableBoardEvents = true;
			showGamePresetsDialog();
		}
	};

	// Edit Menu

	// Load FEN Code
	private EventHandler<ActionEvent> editFENCodeEvent = e -> {
		if(disableMenuEvents == true)
		{
			e.consume();
		}
		else
		{
			closeExcessDialogs();
			disableBoardEvents = true;
			showFENCodeDialog();
		}
	};
	
	private EventHandler<ActionEvent> editGameMovesEvent = e -> {
		if(disableMenuEvents == true)
		{
			e.consume();
		}
		else
		{
			closeExcessDialogs();
			disableBoardEvents = false;
			showGameMovesDialog();
		}
	};
	
	// View Menu
	
	// Flip View
	private EventHandler<ActionEvent> flipBoardViewEvent = e -> {
		flipBoard();
	};

	// Reset Viewing Size/Position
	private EventHandler<ActionEvent> resetSizeEvent = e -> {
		resetViewingSize();
	};
	
	// Show Holdings
	private EventHandler<ActionEvent> showMoveHistoryEvent = e -> {
		showMoveHistory();
	};
	
	// Show Holdings
	private EventHandler<ActionEvent> showHoldingsEvent = e -> {
		showHoldings();
	};

	// Colors...
	private EventHandler<ActionEvent> setColorsEvent = e -> {
		closeExcessDialogs();
		if(!preventBoardEventToggling)
		{
			disableBoardEvents = false;
		}
		showColorsDialog();
	};
	
	// Colors...
	private EventHandler<ActionEvent> setHighlightsEvent = e -> {
		closeExcessDialogs();
		if(!preventBoardEventToggling)
		{
			disableBoardEvents = false;
		}
		showHighlightsDialog();
	};

	private boolean checkColorFormat(String colorString) {
		Pattern validFormat1 = Pattern.compile("#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})");
		Pattern validFormat2 = Pattern.compile("([0-9a-fA-F]{3}|[0-9a-fA-F]{6})");
		Matcher m1 = validFormat1.matcher(colorString);
		Matcher m2 = validFormat2.matcher(colorString);
		boolean isValidFormat = m1.matches() || m2.matches();
		return isValidFormat;
	}

	// Mode Menu
	
	// Help Menu

	// ----------------------------------------------------------------------------------------

	// Initialize Stage

	/**
	 * Creates the menu at the top of the application.
	 */
	private void createMenu() {
		boardMenu = new MenuBar();
		boardMenu.setPrefHeight(20);
		
		Menu fileMenu = new Menu("File");
		MenuItem newGame = new MenuItem("New Game (Ctrl-N)");
		newGame.setOnAction(newGameEvent);
		fileMenu.getItems().add(newGame);
		MenuItem loadGamePreset = new MenuItem("Load Game Preset... (Ctrl-Shift-N)");
		loadGamePreset.setOnAction(loadGamePresetEvent);
		fileMenu.getItems().add(loadGamePreset);
		boardMenu.getMenus().add(fileMenu);

		Menu editMenu = new Menu("Edit");
		MenuItem editFENCode = new MenuItem("FEN Code... (Ctrl-O)");
		editFENCode.setOnAction(editFENCodeEvent);
		editMenu.getItems().add(editFENCode);
		MenuItem editGameMoves = new MenuItem("Game Moves... (Ctrl-I)");
		editGameMoves.setOnAction(editGameMovesEvent);
		editMenu.getItems().add(editGameMoves);
		boardMenu.getMenus().add(editMenu);

		Menu viewMenu = new Menu("View");
		MenuItem flipBoard = new MenuItem("Flip View (F2)");
		flipBoard.setOnAction(flipBoardViewEvent);
		viewMenu.getItems().add(flipBoard);
		MenuItem resetSize = new MenuItem("Reset Viewing Size/Position (Ctrl-0)");
		resetSize.setOnAction(resetSizeEvent);
		viewMenu.getItems().add(resetSize);
		MenuItem showMoveHistory = new MenuItem("Show Move History (M)");
		showMoveHistory.setOnAction(showMoveHistoryEvent);
		viewMenu.getItems().add(showMoveHistory);
		MenuItem showHoldings = new MenuItem("Show Holdings (H)");
		showHoldings.setOnAction(showHoldingsEvent);
		viewMenu.getItems().add(showHoldings);
		MenuItem setColors = new MenuItem("Colors...");
		setColors.setOnAction(setColorsEvent);
		viewMenu.getItems().add(setColors);
		MenuItem setHighlights = new MenuItem("Highlights...");
		setHighlights.setOnAction(setHighlightsEvent);
		viewMenu.getItems().add(setHighlights);
		boardMenu.getMenus().add(viewMenu);

		Menu modeMenu = new Menu("Mode");
		modeMenu.setDisable(true);
		boardMenu.getMenus().add(modeMenu);

		Menu helpMenu = new Menu("Help");
		MenuItem keyBindings = new MenuItem("Key Bindings");
		keyBindings.setOnAction(e -> {
			showKeyBindings();
		});
		helpMenu.getItems().add(keyBindings);
		MenuItem fenCodeHelp = new MenuItem("FEN Code");
		fenCodeHelp.setOnAction(e -> {
			showFENCodeHelp();
		});
		helpMenu.getItems().add(fenCodeHelp);
		MenuItem about = new MenuItem("About");
		about.setOnAction(e -> {
			showAboutDialog();
		});
		helpMenu.getItems().add(about);
		MenuItem license = new MenuItem("License");
		license.setOnAction(e -> {
			showLicenseDialog();
		});
		helpMenu.getItems().add(license);
		MenuItem pieceCredits = new MenuItem("Piece Set Credits");
		pieceCredits.setOnAction(e -> {
			showPieceCreditsDialog();
		});
		helpMenu.getItems().add(pieceCredits);
		if(!Modifications.getModificationsText().equals(""))
		{
			MenuItem modifications = new MenuItem("Modifications");
			modifications.setOnAction(e -> {
				showModsDialog();
			});
			helpMenu.getItems().add(modifications);
		}
		boardMenu.getMenus().add(helpMenu);
		
		Button goToBeginning = new Button("<<");
		goToBeginning.setPrefHeight(boardMenu.getHeight());
		goToBeginning.setOnAction(e -> {
			goToBeginning();
		});
		
		Button goOneBack = new Button("<");
		goOneBack.setPrefHeight(boardMenu.getHeight());
		goOneBack.setOnAction(e -> {
			goOneBack();
		});
		
		Button goOneForward = new Button(">");
		goOneForward.setPrefHeight(boardMenu.getHeight());
		goOneForward.setOnAction(e -> {
			goOneForward();
		});
		
		Button goToEnd = new Button(">>");
		goToEnd.setPrefHeight(boardMenu.getHeight());
		goToEnd.setOnAction(e -> {
			goToEnd();
		});
		
		Button undoMove = new Button("Undo Move");
		undoMove.setPrefHeight(boardMenu.getHeight());
		undoMove.setOnAction(e -> {
			undoMove();
		});

		menuHBox = new HBox(boardMenu, goToBeginning, goOneBack, goOneForward, goToEnd, undoMove);
	}
	
	// Keyboard Shortcuts

	// Custom Board

	private void createBoard(int files, int ranks, int nPieces, String pieceDir, String wPrefix, String bPrefix,
			boolean useGIFImages) {
		board = new Board(files, ranks, nPieces);
		shades = new boolean[ranks][files];
		board.createPieceList(pieceDir, wPrefix, bPrefix, useGIFImages);
		pieceList = board.getPieceList();
		nFiles = board.getNFiles() + 1;
		nRanks = board.getNRanks() + 1;
		shades = new boolean[nRanks][nFiles];
		createBoardDisplay();
	}

	// Default Board

	/**
	 * Creates a new board with the default settings.
	 */
	private void createBoard() {
		board = new Board();
		shades = new boolean[8][8];
		board.createPieceList();
		pieceList = board.getPieceList();
		nFiles = board.getNFiles() + 1;
		nRanks = board.getNRanks() + 1;
		board.setPromoChoices();
		createBoardDisplay();
		defineShades("");
		Display(false);
	}

	/**
	 * Creates the board displayed in the GUI
	 */
	private void createBoardDisplay() {

		GridPane newBoardDisplay = new GridPane();
		newBoardDisplay.setAlignment(Pos.CENTER);
		newBoardDisplay.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		newBoardDisplay.setMinSize(squareSize * nFiles + 2, squareSize * nRanks + 2);
		newBoardDisplay.setMaxSize(squareSize * nFiles + 2, squareSize * nRanks + 2);
		newBoardDisplay.setPadding(new Insets(0));
		newBoardDisplay.setHgap(0);
		newBoardDisplay.setVgap(0);

		for (int i = 0; i < (nFiles * nRanks); ++i) {
			StackPane boardSquare = new StackPane();
			boardSquare.setAlignment(Pos.CENTER);
			boardSquare.setMinSize(squareSize, squareSize);
			boardSquare.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;"); // add to board display
			boardSquare.addEventHandler(MouseEvent.MOUSE_CLICKED, movePieceEvent);
			newBoardDisplay.add(boardSquare, ((int) i % nFiles), ((int) i / nFiles));
		}
		newBoardDisplay.setPrefSize(squareSize * nFiles, squareSize * nRanks);
		boardDisplay = newBoardDisplay;
		scrollPane = new ScrollPane();
		scrollPane.fitToWidthProperty().set(true);
		scrollPane.fitToHeightProperty().set(true);
		scrollPane.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		scrollPane.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		scrollPane.setPadding(new Insets(0));
		scrollPane.setContent(boardDisplay);
		boardPane = new StackPane(scrollPane);
		boardPane.setPadding(new Insets(0));
		createHoldings();
	}

	/**
	 * Defines the shades of the board based on a specialized FEN String</br>
	 * consisting of ones, zeroes, and slashes. 0 means a light square,</br>
	 * 1 means a dark square. Sets shades to the default pattern</br>
	 * (a checkerboard) if the string is invalid or empty.
	 * @param shadeString the shade string defining the desired pattern.
	 */
	public void defineShades(String shadeString) {
		if (shadeString == "") {
			boolean useDarkShade = false; // flags for shading the board squares
			boolean switchShade = false;
			for (int i = 0; i < nRanks; ++i) {
				if (nFiles % 2 == 0) {
					if (useDarkShade) {
						useDarkShade = false;
					} else {
						useDarkShade = true;
					}
				}
				for (int j = 0; j < nFiles; ++j) {
					if (switchShade) {
						switchShade = false;
					} else {
						switchShade = true;
					}
					try {
						if (useDarkShade) {
							if (switchShade) {
								shades[i][j] = true;
							}
						} else {
							if (!switchShade) {
								shades[i][j] = true;
							}
						}
					} catch (ArrayIndexOutOfBoundsException aioobe) {
						break;
					}
				}
			}
		} else {
			for (int i = 0; i < shadeString.length(); ++i) {
				if (Character.compare(shadeString.charAt(i), '0') != 0
						&& Character.compare(shadeString.charAt(i), '1') != 0
						&& Character.compare(shadeString.charAt(i), '/') != 0) {
					defineShades("");
					return;
				}
			}
			String[] lines = shadeString.split("/");
			for (int i = Math.min(nRanks - 1, lines.length - 1); i >= 0; --i) {
				for (int j = 0; j < Math.min(nFiles, lines[i].length()); ++j) {
					if (Character.compare(lines[i].charAt(j), '1') == 0) {
						try {
							shades[i][j] = true;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							break;
						}
					}
				}
			}
		}
	}

	/**
	 * Updates the board display.
	 * @param preserveHighlights whether to preserve the board highlights
	 */
	public void Display(boolean preserveHighlights) {
		if(preserveHighlights)
		{
			ResetEvents(false);
		}
		else
		{
			ResetEvents(true);
		}
		for (int i = 0; i < nRanks; ++i) {
			for (int j = 0; j < nFiles; ++j) {
				int pieceOnSquare = board.getPieceOnSquare(j, i);
				StackPane boardSquare = getBoardSquare(j, i);
				if (boardSquare == null) {
					continue;
				}
				String squareID = j + "," + i;
				boardSquare.setId(squareID);

				if (pieceOnSquare == -1) {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(holeColor.toString()), CornerRadii.EMPTY, Insets.EMPTY)));
					boardSquare.getChildren().clear();
					String holeBorderString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + holeBorderColor.toString() + ";";
					boardSquare.setStyle(holeBorderString);
				} else if (pieceOnSquare == 0) {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(getShadeColor(j, i)), CornerRadii.EMPTY, Insets.EMPTY)));
					boardSquare.getChildren().clear();

					// if(preserveHighlights) { if(i < (nRanks / 2)) { Highlight(j, i, moveColor.toString()); } else { Highlight(j, i, captureColor.toString()); } }
				} else if (pieceOnSquare >= 1 && pieceOnSquare <= board.getMaxPieces()) {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(getShadeColor(j, i)), CornerRadii.EMPTY, Insets.EMPTY)));
					String[] squareCoords = boardSquare.getId().split(",");
					if(preserveHighlights)
					{
						if(originX == Integer.parseInt(squareCoords[0]) && originY == Integer.parseInt(squareCoords[1]))
						{
							boardSquare.setBackground(new Background(new BackgroundFill(Color.web(selectedPieceColor.toString()), CornerRadii.EMPTY, Insets.EMPTY)));
							//selectPiece(originX, originY, false);
						}
					}
					boardSquare.getChildren().clear();

					ImageView piece = pieceList.getPieceImage(pieceOnSquare);
					if (flipPiecesOnBoardFlip && flipView) {
						piece.setRotate(180);
					} else {
						piece.setRotate(0);
					}
					boardSquare.getChildren().add(piece);
				} else {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(getShadeColor(j, i)), CornerRadii.EMPTY, Insets.EMPTY)));
					boardSquare.getChildren().clear();
				}
				//boardSquare.getChildren().add(new Label(boardSquare.getId()));
			}
		}
		
		for(int i = 1; i <= board.getMaxPieces(); ++i)
		{
			StackPane handImage = getHandImage(i);
			StackPane handIndicator = getHandIndicator(i);
			handImage.getChildren().clear();
			ImageView piece = pieceList.getPieceImage(i);
			if (flipPiecesOnBoardFlip && flipView) {
				piece.setRotate(180);
			} else {
				piece.setRotate(0);
			}
			handImage.getChildren().add(piece);
			handImage.setBackground(new Background(new BackgroundFill(Color.web("#F0F0F0"), CornerRadii.EMPTY, Insets.EMPTY)));
			if(originX == i && originY == -1)
			{
				handImage.setBackground(new Background(new BackgroundFill(Color.web(selectedPieceColor.toString()), CornerRadii.EMPTY, Insets.EMPTY)));
				//selectPiece(originX, originY, false);
			}
			
			handIndicator.getChildren().clear();
			Label handLabel;
			if(board.getNPiecesInHand(i) > 0)
			{
				handLabel = new Label(Integer.toString(board.getNPiecesInHand(i)));
			}
			else
			{
				handLabel = new Label("-");
			}
			handIndicator.getChildren().add(handLabel);
		}
		moveHistory.setText(getGameMoves());
	}

	private String getShadeColor(int x, int y) {
		String color;
		if (shades[y][x]) {
			color = darkShade.toString();
		} else {
			color = lightShade.toString();
		}
		return color;
	}

	/**
	 * Gets the square on the board display corresponding to the</br>
	 * coordinate (x,y). Returns null if coordinates are invalid.
	 * 
	 * @param x the x-coordinate of this square. Cannot be < 0 or >= nFiles.
	 * @param y the y-coordinate of this square. Cannot be < 0 or >= nRanks.
	 * @return
	 */
	public StackPane getBoardSquare(int x, int y) {
		int nSquares = boardDisplay.getChildren().size() - 1;
		int squareIndex = x + (nRanks - 1 - y) * nFiles;
		if (x < 0 || x >= nFiles || y < 0 || y >= nRanks) {
			return null;
		}
		if (flipView) {
			return (StackPane) boardDisplay.getChildren().get(nSquares - squareIndex);
		} else {
			return (StackPane) boardDisplay.getChildren().get(squareIndex);
		}
	}
	
	/**
	 * Gets the part on the holdings display holding the image corresponding to the</br>
	 * piece numbered piece. Returns null if coordinates are invalid.
	 * @param piece the piece number. Cannot be < 1 or > maxPieceValue.
	 * @return the corresponding part of the holdings display
	 */
	public StackPane getHandImage(int piece) {
		int x;
		int y;
		int handIndicator;
		if(piece < 1 || piece > board.getMaxPieces())
		{
			return null;
		}
		if(piece > board.getNPieceTypes())
		{
			x = 3;
			handIndicator = piece - board.getNPieceTypes();
		}
		else
		{
			x = 1;
			handIndicator = piece;
		}
		y = board.getNPieceTypes() - handIndicator - 1;
		
		int squareIndex = x + (board.getNPieceTypes() - 1 - y) * 7;
		return (StackPane)holdingsDisplay.getChildren().get(squareIndex);
	}
	
	/**
	 * Gets the part on the holdings display holding the number of pieces</br>
	 * in the hand corresponding to the piece numbered piece.</br>
	 * Returns null if coordinates are invalid.
	 * @param piece the piece number. Cannot be < 1 or > maxPieceValue.
	 * @return the corresponding part of the holdings display
	 */
	public StackPane getHandIndicator(int piece) {
		int x;
		int y;
		int handIndicator;
		if(piece < 1 || piece > board.getMaxPieces())
		{
			return null;
		}
		if(piece > board.getNPieceTypes())
		{
			x = 4;
			handIndicator = piece - board.getNPieceTypes();
		}
		else
		{
			x = 2;
			handIndicator = piece;
		}
		y = board.getNPieceTypes() - handIndicator - 1;
		
		int squareIndex = x + (board.getNPieceTypes() - 1 - y) * 7;
		return (StackPane) holdingsDisplay.getChildren().get(squareIndex);
	}

	/**
	 * Highlights the selected square with a circle with a black border and a given color.
	 * @param x x-coordinate of square
	 * @param y x-coordinate of square
	 * @param color color of the circle
	 */
	public void Highlight(int x, int y, String color) {
		if (x < 0 || x >= nFiles || y < 0 || y >= nRanks) {
			return;
		}
		StackPane boardSquare = getBoardSquare(x, y);
		if (boardSquare == null) {
			return;
		}

		int nChildren = boardSquare.getChildren().size();
		boolean hasChildren = (nChildren > 0);

		Circle squareHighlight = new Circle();
		squareHighlight.setCenterX(boardSquare.getWidth() / 2);
		squareHighlight.setCenterY(boardSquare.getHeight() / 2);
		int radius = squareSize / 5;
		squareHighlight.setRadius(radius);
		squareHighlight.setFill(Color.web(color));
		squareHighlight.setStroke(Color.web("#000000"));
		squareHighlight.setStrokeWidth(1.0);

		if (hasChildren) {
			if (nChildren == 1) {
				if (boardSquare.getChildren().get(0) instanceof Circle) {
					boardSquare.getChildren().set(0, squareHighlight);
				} else {
					boardSquare.getChildren().add(squareHighlight);
				}
			}
			if (nChildren == 2) {
				if (boardSquare.getChildren().get(1) instanceof Circle) {
					boardSquare.getChildren().set(1, squareHighlight);
				} else {
					boardSquare.getChildren().add(squareHighlight);
				}
			}
		} else {
			squareHighlight.setFill(Color.web(color));
			boardSquare.getChildren().add(squareHighlight);
		}
	}

	/**
	 * Gets the rank ID based on its name and whether Shogi Mode is active
	 * @param fileName name of the file
	 * @param shogiMode	whether to use Shogi coordinates instead of SAN coordinates
	 * @return the integer representation of this file in the internal board
	 */
	public int fileID(String fileName, boolean shogiMode) {
		if(shogiMode)
		{
			try
			{
				int fileID = Integer.parseInt(fileName);
				return nFiles - fileID;
			}
			catch(NumberFormatException e)
			{
				return -1;
			}
		}
		else
		{
			if(fileName.length() < 1)
			{
				return -1;
			}
			else if(fileName.length() == 1)
			{
				return fileName.charAt(0) - 97;
			}
			else
			{
				for(int i = 1; i < fileName.length(); ++i)
				{
					if(fileName.charAt(i) != fileName.charAt(0))
					{
						return -1;
					}
				}
				int fileID = 0;
				for(int i = 0; i < fileName.length() - 1; ++i)
				{
					fileID += 26;
				}
				fileID += fileName.charAt(fileName.length() - 1) - 97;
				return fileID;
			}
		}
	}

	/**
	 * Gets the rank ID based on its name and whether Shogi Mode is active
	 * @param rankName name of the rank
	 * @param shogiMode	whether to use Shogi coordinates instead of SAN coordinates
	 * @return the integer representation of this rank in the internal board
	 */
	public int rankID(String rankName, boolean shogiMode) {
		if(shogiMode)
		{
			if(rankName.length() < 1)
			{
				return -1;
			}
			else if(rankName.length() == 1)
			{
				return nRanks - 1 - (rankName.charAt(0) - 97);
			}
			else
			{
				for(int i = 1; i < rankName.length(); ++i)
				{
					if(rankName.charAt(i) != rankName.charAt(0))
					{
						return -1;
					}
				}
				int rankID = 0;
				for(int i = 0; i < rankName.length() - 1; ++i)
				{
					rankID += 26;
				}
				rankID += rankName.charAt(rankName.length() - 1) - 97;
				return nRanks - 1 - rankID;
			}
		}
		else
		{
			try {
				return Integer.parseInt(rankName) - 1;
			} catch (NumberFormatException nfe) {
				return -1;
			}
		}
	}
	
	/**
	 * Gets the loading scene. Dialogs should be set to this</br>
	 * scene
	 * @return
	 */
	public void setToLoadingScene(Stage stage)
	{
		Label loadingLabel = new Label("Loading...");
		ImageView loadingImage = new ImageView("/icon/universal_chessboard_icon.png");
		VBox loadingVBox = new VBox(loadingLabel, loadingImage);
		loadingVBox.setAlignment(Pos.CENTER);
		loadingVBox.setSpacing(10);
		loadingVBox.setPadding(new Insets(10));
		Scene scene = new Scene(loadingVBox, 175, 100);
		stage.setScene(scene);
		stage.setTitle("");
		stage.sizeToScene();
		stage.centerOnScreen();
	}

	// Menu Event Methods

	public void newGame(boolean askForConfirmation)
	{
		if((board.getGame().size() - 1) == 0)
		{
			return;
		}
		else
		{
			if(askForConfirmation)
			{
				disableBoardEvents = true;
				int confirmNewGame = showConfirmDialog("Confirm New Game", "This will clear the game that is currently loaded. Are you sure?");
				if(confirmNewGame != 1)
				{
					disableBoardEvents = false;
					return;
				}
			}
			board.newGame();
			updateLastMoveSquares(-1, -1, null, null, -1, -1);
			Display(false);
			disableBoardEvents = false;
		}
	}
	
	public int showConfirmDialog(String titleString, String confirmString)
	{
		confirmStage = new Stage();
		confirmStage.setAlwaysOnTop(true);
		confirmOptionChosen = -1;
		Label confirmLabel = new Label(confirmString);
		confirmLabel.setStyle("-fx-text-alignment:center;");
		Button yesButton = new Button("Yes");
		yesButton.setPrefWidth(75);
		yesButton.setOnAction(e -> {
			confirmOptionChosen = 1;
			confirmStage.close();
		});
		Button noButton = new Button("No");
		noButton.setPrefWidth(75);
		noButton.setOnAction(e -> {
			confirmOptionChosen = 0;
			confirmStage.close();
		});
		Button cancelButton = new Button("Cancel");
		cancelButton.setPrefWidth(75);
		cancelButton.setOnAction(e -> {
			confirmOptionChosen = -1;
			confirmStage.close();
		});
		HBox buttonHBox = new HBox(yesButton, noButton, cancelButton);
		buttonHBox.setAlignment(Pos.CENTER);
		buttonHBox.setSpacing(10);
		VBox confirmVBox = new VBox(confirmLabel, buttonHBox);
		confirmVBox.setAlignment(Pos.CENTER);
		confirmVBox.setSpacing(10);
		confirmVBox.setPadding(new Insets(10));
		
		Scene confirmScene = new Scene(confirmVBox);
		confirmStage.setScene(confirmScene);
		confirmStage.setTitle(titleString);
		confirmStage.sizeToScene();
		confirmStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
		confirmStage.showAndWait();
		boardStage.requestFocus();
		return confirmOptionChosen;
	}
	
	public void showGamePresetsDialog()
	{
		if(gamePresetsStage.isShowing())
		{
			gamePresetsStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Press one of the preset buttons to show that preset's text, which can be edited in the text area to the right.\nWhen done, press the Load Preset button to load the preset text. This clears the game you have loaded.");
			instructionsLabel.setStyle("-fx-text-alignment:center;");

			Label classicLabel = new Label("Classic");
			classicLabel.setStyle("-fx-underline:true");
			Button chessButton = new Button("Chess");
			Button xiangqiButton = new Button("Xiangqi");
			Button shogiButton = new Button("Shogi");
			Label miscLabel = new Label("Miscellaneous");
			miscLabel.setStyle("-fx-underline:true");
			Button grandChessButton = new Button("Grand Chess");
			Button omegaChessButton = new Button("Omega Chess");
			Button grossChessButton = new Button("Gross Chess");
			Button manchuChessButton = new Button("Manchu Chess");
			Button microshogiButton = new Button("Microshogi");
			Button minishogiButton = new Button("Minishogi");
			VBox classicVBox = new VBox(classicLabel, chessButton, xiangqiButton, shogiButton, miscLabel, grandChessButton, omegaChessButton, grossChessButton, manchuChessButton, microshogiButton, minishogiButton);
			classicVBox.setAlignment(Pos.TOP_CENTER);
			classicVBox.setSpacing(10);

			Separator categorySeparator1 = new Separator(Orientation.VERTICAL);
			categorySeparator1.setCenterShape(true);

			Label authorGamesLabel = new Label("Author's Games");
			authorGamesLabel.setStyle("-fx-underline:true");
			Button yangsiButton = new Button("Yangsi");
			Button hectochessButton = new Button("Hectochess");
			Button ryugiButton = new Button("Ryugi");
			Button shosuShogiButton = new Button("Shosu Shogi");
			Button cannonShosuShogiButton = new Button("Cannon Shosu Shogi");
			Button futashikanaShogiButton = new Button("Futashikana Shogi");
			Button mitsugumiShogiButton = new Button("Mitsugumi Shogi");
			Button suzumuShogiButton = new Button("Suzumu Shogi");
			Button chushinShogiButton = new Button("Chushin Shogi");
			Button hookShogiButton = new Button("Hook Shogi");
			Button taishinShogiButton = new Button("Taishin Shogi");
			VBox authorGamesVBox = new VBox(authorGamesLabel, yangsiButton, hectochessButton, ryugiButton, shosuShogiButton,
					cannonShosuShogiButton, futashikanaShogiButton, mitsugumiShogiButton, suzumuShogiButton,
					chushinShogiButton, hookShogiButton, taishinShogiButton);
			authorGamesVBox.setAlignment(Pos.TOP_CENTER);
			authorGamesVBox.setSpacing(10);

			Separator categorySeparator2 = new Separator(Orientation.VERTICAL);
			categorySeparator2.setCenterShape(true);

			Label presetTextLabel = new Label("Preset Text");
			presetTextLabel.setStyle("-fx-underline:true");
			TextArea presetText = new TextArea(preset.toString());
			presetText.setPrefHeight(350);
			Button viewCurrentPresetButton = new Button("View Current Preset");
			Button loadPresetButton = new Button("Load Preset");
			HBox buttonHBox = new HBox(viewCurrentPresetButton, loadPresetButton);
			buttonHBox.setAlignment(Pos.TOP_CENTER);
			buttonHBox.setSpacing(10);
			VBox presetTextVBox = new VBox(presetTextLabel, presetText, buttonHBox);
			presetTextVBox.setAlignment(Pos.TOP_CENTER);
			presetTextVBox.setSpacing(10);

			chessButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("chess"));
			});
			xiangqiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("xiangqi"));
			});
			shogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("shogi"));
			});
			grandChessButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("grand_chess"));
			});
			omegaChessButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("omega_chess"));
			});
			grossChessButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("gross_chess"));
			});
			manchuChessButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("manchu_chess"));
			});
			microshogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("microshogi"));
			});
			minishogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("minishogi"));
			});
			yangsiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("yangsi"));
			});
			hectochessButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("hectochess"));
			});
			ryugiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("ryugi"));
			});
			shosuShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("shosu_shogi"));
			});
			cannonShosuShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("cannon_shosu_shogi"));
			});
			futashikanaShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("futashikana_shogi"));
			});
			mitsugumiShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("mitsugumi_shogi"));
			});
			suzumuShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("suzumu_shogi"));
			});
			chushinShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("chushin_shogi"));
			});
			hookShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("hook_shogi"));
			});
			taishinShogiButton.setOnAction(e1 -> {
				presetText.setText(PresetList.getPresetText("taishin_shogi"));
			});
			
			viewCurrentPresetButton.setOnAction(e1 -> {
				presetText.setText(preset.toString());
			});

			loadPresetButton.setOnAction(e1 -> {
				setToLoadingScene(gamePresetsStage);
				holdingsStage.close();
				Init(presetText.getText());
				resetViewingSize();
				gamePresetsStage.close();
				boardStage.requestFocus();
				disableBoardEvents = false;
			});

			HBox gamePresetsHBox = new HBox(classicVBox, categorySeparator1, authorGamesVBox, categorySeparator2,
					presetTextVBox);
			gamePresetsHBox.setAlignment(Pos.CENTER);
			gamePresetsHBox.setSpacing(10);

			VBox gamePresetsVBox = new VBox(instructionsLabel, gamePresetsHBox);
			gamePresetsVBox.setAlignment(Pos.CENTER);
			gamePresetsVBox.setSpacing(10);
			gamePresetsVBox.setPadding(new Insets(10));

			Scene gamePresetsScene = new Scene(gamePresetsVBox);
			loadPresetButton.requestFocus();
			gamePresetsStage.setScene(gamePresetsScene);
			gamePresetsStage.setTitle("Game Presets");
			gamePresetsStage.setOnCloseRequest(e -> {
				disableBoardEvents = false;
			});
			gamePresetsStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			gamePresetsStage.show();
		}
	}

	private void Init(String newPresetText) {
		if (newPresetText.equals("default")) {
			defaultLightShade = new StringBuffer("#FFCC9C");
			defaultDarkShade = new StringBuffer("#CF8948");
			lightShade = new StringBuffer(defaultLightShade.toString());
			darkShade = new StringBuffer(defaultDarkShade.toString());
			this.squareSize = 54;
			flipPiecesOnBoardFlip = false;
			flipView = false;
			createBoard();
			boardStage.setTitle("Universal Chessboard - Chess");
		} else {
			String[] lines = newPresetText.split("\n");

			StringBuffer name = new StringBuffer(); // default keyword values
			StringBuffer author = new StringBuffer();
			int files = 8;
			int ranks = 8;
			int holdingsType = 0;
			boolean demoteOnCapture = true;
			boolean enableDrops = false;
			boolean allowDropPromotions = false;
			int maxPromote = 1;
			int promoZone = 1;
			int promoOffset = 0;
			StringBuffer promoChoice = new StringBuffer("QRBN");
			int forcePromotions = 0;
			boolean allowPromotionOnTurnSkip = false;
			StringBuffer graphicsDir = new StringBuffer("/chess/");
			boolean useGIFImages = false;
			StringBuffer whitePrefix = new StringBuffer("w");
			StringBuffer blackPrefix = new StringBuffer("b");
			StringBuffer lightShade = new StringBuffer("#FFCC9C");
			StringBuffer darkShade = new StringBuffer("#CF8948");
			StringBuffer holeColor = new StringBuffer("#000000");
			StringBuffer holeBorderColor = new StringBuffer("#FFFFFF");
			boolean shogiMode = false;
			boolean flipPiecesOnBoardFlip = false;
			StringBuffer shades = new StringBuffer("");
			StringBuffer symmetry = new StringBuffer("mirror");
			int squareSize = 54;

			StringBuffer selectedPieceColor = new StringBuffer("#80FF80");
			StringBuffer lastMoveColor = new StringBuffer("#00FF00");
			StringBuffer lastLocustCaptureColor = new StringBuffer("#FFC000");
			StringBuffer moveColor = new StringBuffer("#FFFF00");
			StringBuffer captureColor = new StringBuffer("#FF0000");
			StringBuffer destroyColor = new StringBuffer("#0000FF");
			StringBuffer locustCaptureColor = new StringBuffer("#00FFFF");

			int nPieces = lines.length; // initialize piece list length

			for(int i = 0; i < lines.length; ++i) // find number of keywords
			{
				if(lines[i].contains("=")) {
					String[] parts = lines[i].split("=");
					if(parts[0].trim().equals("name") || parts[0].trim().equals("author"))
					{
						parts[0] = parts[0].trim();
						parts[1] = parts[1].trim();
					}
					else
					{
						lines[i] = lines[i].replaceAll("\\s", "");
					}
					--nPieces;
				}
				else if(lines[i].contains(":"))
				{
					String[] lineParts = lines[i].split(":");
					if(lineParts.length == 2 && lineParts[0].equals("hole"))
					{
						--nPieces;
					}
				}
			}

			int[] royal = new int[nPieces];
			boolean[] contagious = new boolean[nPieces];
			boolean[] contagiousPromotion = new boolean[nPieces];
			int[] forceShogiPromotionZones = new int[nPieces];

			String[] names = new String[nPieces];
			String[] ids = new String[nPieces];
			String[] moves = new String[nPieces];
			String[] images = new String[nPieces];
			String[] startSquares = new String[nPieces];
			int[] startHand = new int[nPieces];
			StringBuffer holeSquares = new StringBuffer("");

			int pieceCounter = 0;

			for (int i = 0; i < lines.length; ++i) // keywords
			{
				if (lines[i].contains("=")) // keyword setters always contain "=", but
				{
					String[] keywords = lines[i].split("=");
					if(keywords[0].equals("name")) {
						name = new StringBuffer(keywords[1]);
					} else if(keywords[0].equals("author")) {
						author = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("files")) {
						try {
							files = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							files = 8;
						}
						if (files < 1 || files > 100) {
							Init("default");
							return;
						}
					} else if (keywords[0].equals("ranks")) {
						try {
							ranks = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							ranks = 8;
						}
						if (ranks < 1 || ranks > 100) {
							Init("default");
							return;
						}
					} else if (keywords[0].equals("holdingsType")) {
						try {
							holdingsType = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							holdingsType = 0;
						}
					} else if (keywords[0].equals("demoteOnCapture")) {
						demoteOnCapture = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("enableDrops")) {
						enableDrops = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("allowDropPromotions")) {
						allowDropPromotions = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("maxPromote")) {
						try {
							maxPromote = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							maxPromote = 1;
						}
					} else if (keywords[0].equals("promoZone")) {
						try {
							promoZone = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							promoZone = 1;
						}
					} else if (keywords[0].equals("promoOffset")) {
						try {
							promoOffset = Math.abs(Integer.parseInt(keywords[1]));
						} catch (NumberFormatException nfe) {
							promoOffset = 0;
						}
					} else if (keywords[0].equals("promoChoice")) {
						promoChoice = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("forcePromotions")) {
						try {
							forcePromotions = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							forcePromotions = 0;
						}
					} else if (keywords[0].equals("allowPromotionOnTurnSkip")) {
						allowPromotionOnTurnSkip = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("forceShogiPromotionZone")) {
						String[] zoneParts = keywords[1].split(",");
						try {
							int forceShogiPromotionZonePiece = Integer.parseInt(zoneParts[0]);
							int forceShogiPromotionZone = Integer.parseInt(zoneParts[1]);
							forceShogiPromotionZones[forceShogiPromotionZonePiece - 1] = forceShogiPromotionZone;
						} catch (Exception e) {
							continue;
						}
					} else if (keywords[0].equals("graphicsDir")) {
						graphicsDir = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("useGIFImages")) {
						useGIFImages = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("whitePrefix")) {
						whitePrefix = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("blackPrefix")) {
						blackPrefix = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("lightShade")) {
						if (checkColorFormat(keywords[1])) {
							lightShade = new StringBuffer(keywords[1]);
						} else {
							lightShade = new StringBuffer("#FFCC9C");
						}
					} else if (keywords[0].equals("darkShade")) {
						if (checkColorFormat(keywords[1])) {
							darkShade = new StringBuffer(keywords[1]);
						} else {
							darkShade = new StringBuffer("#CF8948");
						}
					} else if (keywords[0].equals("holeColor")) {
						if (checkColorFormat(keywords[1])) {
							holeColor = new StringBuffer(keywords[1]);
						} else {
							holeColor = new StringBuffer("#000000");
						}
					} else if (keywords[0].equals("holeBorderColor")) {
						if (checkColorFormat(keywords[1])) {
							holeBorderColor = new StringBuffer(keywords[1]);
						} else {
							holeBorderColor = new StringBuffer("#FFFFFF");
						}
					} else if (keywords[0].equals("shades")) {
						shades = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("selectedPieceColor")) {
						if (checkColorFormat(keywords[1])) {
							selectedPieceColor = new StringBuffer(keywords[1]);
						} else {
							selectedPieceColor = new StringBuffer("#80FF80");
						}
					} else if (keywords[0].equals("lastMoveColor")) {
						if (checkColorFormat(keywords[1])) {
							lastMoveColor = new StringBuffer(keywords[1]);
						} else {
							lastMoveColor = new StringBuffer("#00FF00");
						}
					} else if (keywords[0].equals("lastLocustCaptureColor")) {
						if (checkColorFormat(keywords[1])) {
							lastLocustCaptureColor = new StringBuffer(keywords[1]);
						} else {
							lastLocustCaptureColor = new StringBuffer("#FFC000");
						}
					} else if (keywords[0].equals("moveColor")) {
						if (checkColorFormat(keywords[1])) {
							moveColor = new StringBuffer(keywords[1]);
						} else {
							moveColor = new StringBuffer("#FFFF00");
						}
					} else if (keywords[0].equals("captureColor")) {
						if (checkColorFormat(keywords[1])) {
							captureColor = new StringBuffer(keywords[1]);
						} else {
							moveColor = new StringBuffer("#FF0000");
						}
					} else if (keywords[0].equals("destroyColor")) {
						if (checkColorFormat(keywords[1])) {
							destroyColor = new StringBuffer(keywords[1]);
						} else {
							destroyColor = new StringBuffer("#0000FF");
						}
					} else if (keywords[0].equals("locustCaptureColor")) {
						if (checkColorFormat(keywords[1])) {
							locustCaptureColor = new StringBuffer(keywords[1]);
						} else {
							locustCaptureColor = new StringBuffer("#00FFFF");
						}
					} else if (keywords[0].equals("shogiMode")) {
						shogiMode = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("flipPiecesOnBoardFlip")) {
						flipPiecesOnBoardFlip = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("symmetry")) {
						symmetry = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("squareSize")) {
						try {
							squareSize = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							squareSize = 54;
						}
					} else if (keywords[0].equals("royal")) {
						try {
							royal[(Integer.parseInt(keywords[1]) - 1)] = 1;
						} catch (NumberFormatException nfe) {
							continue;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							continue;
						}
					} else if (keywords[0].equals("iron")) {
						try {
							royal[(Integer.parseInt(keywords[1]) - 1)] = 2;
						} catch (NumberFormatException nfe) {
							continue;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							continue;
						}
					} else if (keywords[0].equals("contagiousPromotion")) {
						try {
							contagiousPromotion[(Integer.parseInt(keywords[1]) - 1)] = true;
						} catch (NumberFormatException nfe) {
							continue;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							continue;
						}
					} else if (keywords[0].equals("contagious")) {
						try {
							contagious[(Integer.parseInt(keywords[1]) - 1)] = true;
						} catch (NumberFormatException nfe) {
							continue;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							continue;
						}
					} else {
						continue;
					}
				} else if (lines[i].contains(":")) {
					String[] parts = lines[i].split(":");
					parts[0] = parts[0].trim();
					for(int j = 1; j < parts.length; ++j)
					{
						parts[j] = parts[j].replaceAll("\\s", "");
					}
					if (parts.length < 4 || parts.length > 6) {
						if(parts.length == 2 && parts[0].equals("hole"))
						{
							holeSquares = new StringBuffer(parts[1]);
						}
						else
						{
							Init("default");
							return;
						}
					} else {
						for (int j = 0; j < 4; ++j) {
							if (parts[j] == "") {
								Init("default");
								return;
							}
						}
						
						if(!parts[1].matches(".*[a-zA-Z]+.*"))
						{
							Init("default");
							return;
						}
						
						for(int j = 0; j < nPieces; ++j)
						{
							if(parts[1].equals(ids[j]))
							{
								parts[1] = parts[1] + "*";
								j = -1;
							}
						}
						
						names[pieceCounter] = parts[0];
						ids[pieceCounter] = parts[1];
						moves[pieceCounter] = parts[2];
						images[pieceCounter] = parts[3];
						if(parts.length >= 5)
						{
							if(parts[4] == null) {
								parts[4] = "";
							} else {
								startSquares[pieceCounter] = parts[4];
							}
						}
						if(parts.length == 6)
						{
							if(parts[5] == null) {
								startHand[pieceCounter] = 0;
							} else {
								try {
									startHand[pieceCounter] = Integer.parseInt(parts[5]);
								}
								catch(NumberFormatException nfe)
								{
									startHand[pieceCounter] = 0;
								}
							}
						}
						++pieceCounter;
					}
				} else {
					Init("default");
					return;
				}
			}
			
			defaultSelectedPieceColor = selectedPieceColor;
			defaultLastMoveColor = lastMoveColor;
			defaultLastLocustCaptureColor = lastLocustCaptureColor;
			defaultMoveColor = moveColor;
			defaultCaptureColor = captureColor;
			defaultDestroyColor = destroyColor;
			defaultLocustCaptureColor = locustCaptureColor;
			
			this.selectedPieceColor = selectedPieceColor;
			this.lastMoveColor = lastMoveColor;
			this.lastLocustCaptureColor = lastLocustCaptureColor;
			this.moveColor = moveColor;
			this.captureColor = captureColor;
			this.destroyColor = destroyColor;
			this.locustCaptureColor = locustCaptureColor;

			this.defaultLightShade = new StringBuffer(lightShade.toString());
			this.lightShade = new StringBuffer(lightShade.toString());
			this.defaultDarkShade = new StringBuffer(darkShade.toString());
			this.darkShade = new StringBuffer(darkShade.toString());
			
			this.defaultHoleColor = new StringBuffer(holeColor.toString());
			this.holeColor = new StringBuffer(holeColor.toString());
			this.defaultHoleBorderColor = new StringBuffer(holeBorderColor.toString());
			this.holeBorderColor = new StringBuffer(holeBorderColor.toString());
			
			this.shogiMode = shogiMode;
			this.flipPiecesOnBoardFlip = flipPiecesOnBoardFlip;
			this.squareSize = squareSize;

			createBoard(files, ranks, nPieces, graphicsDir.toString(), whitePrefix.toString(), blackPrefix.toString(),
					useGIFImages);

			for (int i = 0; i < nPieces; ++i) {
				try {
					pieceList.addPiece(i + 1, names[i], ids[i], moves[i], images[i]);
				} catch (NullPointerException npe) {
					continue;
				}
			}

			if (!symmetry.toString().equals("none") && !symmetry.toString().equals("rotate") && !symmetry.toString().equals("mirror")) {
				symmetry = new StringBuffer("none");
			}
			
			if(!holeSquares.toString().equals(""))
			{
				String holeSquaresStr = expandStartCoordRegions(holeSquares.toString());
				String[] holeSquareCoords = holeSquaresStr.split(",");
				for (int i = 0; i < holeSquareCoords.length; ++i) {
					Pattern validHoleCoordFormat1 = Pattern.compile("([a-z]{1}[0-9]{1})");
					Pattern validHoleCoordFormat2 = Pattern.compile("([a-z]{1}[0-9]{2})");
					Matcher m1 = validHoleCoordFormat1.matcher(holeSquareCoords[i]);
					Matcher m2 = validHoleCoordFormat2.matcher(holeSquareCoords[i]);
					if(m1.matches() || m2.matches())
					{
						String file = Character.toString(holeSquareCoords[i].charAt(0));
						String rank = holeSquareCoords[i].substring(1);
						int holeFileID = fileID(file, false);
						int holeRankID = rankID(rank, false);
						board.setVirginPieceOnSquare(holeFileID, holeRankID, -1);
					}
				}
			}

			for (int i = 0; i < nPieces; ++i) {
				board.setNPiecesInHand(i + 1, startHand[i]);
				board.setNPiecesInHand(i + 1 + board.getNPieceTypes(), startHand[i]);
				if (startSquares[i] == null) {
					continue;
				}
				boolean isBlackStartCoords = false;
				String startSquaresStr = expandStartCoordRegions(startSquares[i]);
				String[] startSquareCoords = startSquaresStr.split(",");
				for (int j = 0; j < startSquareCoords.length; ++j) {
					if (startSquareCoords[j].equals("")) {
						isBlackStartCoords = true;
					} else {
						Pattern validCoordFormat1 = Pattern.compile("([a-z]{1}[0-9]{1})");
						Pattern validCoordFormat2 = Pattern.compile("([a-z]{1}[0-9]{2})");
						Matcher m1 = validCoordFormat1.matcher(startSquareCoords[j]);
						Matcher m2 = validCoordFormat2.matcher(startSquareCoords[j]);
						if(m1.matches() || m2.matches())
						{
							String file = Character.toString(startSquareCoords[j].charAt(0));
							String rank = startSquareCoords[j].substring(1);
							int wFileID = fileID(file, false);
							int wRankID = rankID(rank, false);
							int bFileID = files - 1 - fileID(file, false);
							int bRankID = ranks - 1 - rankID(rank, false);
							int wPiece = i + 1;
							int bPiece = i + 1 + nPieces;
							if(symmetry.toString().equals("mirror"))
							{
								board.setVirginPieceOnSquare(wFileID, wRankID, wPiece);
								board.setVirginPieceOnSquare(wFileID, bRankID, bPiece);
							}
							if(symmetry.toString().equals("rotate"))
							{
								board.setVirginPieceOnSquare(wFileID, wRankID, wPiece);
								board.setVirginPieceOnSquare(bFileID, bRankID, bPiece);
							}
							if(symmetry.toString().equals("none"))
							{
								if(isBlackStartCoords)
								{
									board.setVirginPieceOnSquare(wFileID, wRankID, bPiece);
								}
								else
								{
									board.setVirginPieceOnSquare(wFileID, wRankID, wPiece);
								}
							}
						}
					}
				}
			}

			board.setHoldingsType(holdingsType);
			board.setDemoteOnCapture(demoteOnCapture);
			board.setEnableDrops(enableDrops);
			board.setAllowDropPromotions(allowDropPromotions);
			board.setMaxPromotingPieces(maxPromote);
			board.setPromotionZone(promoZone);
			board.setForceShogiPromotionZones(forceShogiPromotionZones);
			board.setPromotionChoice(promoChoice.toString());
			board.setPromotionOffset(promoOffset);
			board.setForcePromotions(forcePromotions);
			board.setAllowPromotionOnTurnSkip(allowPromotionOnTurnSkip);
			board.AddMove();
			createHoldings();

			boolean hasRoyal = false; // flag to determine if board has at least one royal
			for (int i = 0; i < royal.length && hasRoyal == false; ++i) // check if a royal piece exists
			{
				if (royal[i] == 1) {
					hasRoyal = true;
				}
			}
			if (hasRoyal == false) // if no royal pieces are defined, set last non-iron piece as royal piece
			{
				for (int i = royal.length - 1; i > 0 && hasRoyal == false; --i) {
					if (royal[i] == 0) {
						royal[i] = 1;
						hasRoyal = true;
					}
				}
				if (hasRoyal == false) // if all else fails set last piece as royal piece over preset specifications
				{
					royal[royal.length - 1] = 1;
				}
			}
			
			for(int i = 0; i < royal.length; ++i) // set contagious pieces
			{
				pieceList.setRoyalty(i + 1, royal[i]);
			}
			
			for(int i = 0; i < contagiousPromotion.length; ++i) // set contagious pieces
			{
				pieceList.setContagiousPromotion(i + 1, contagiousPromotion[i]);
			}
			
			for(int i = 0; i < contagious.length; ++i) // set contagious pieces
			{
				pieceList.setContagious(i + 1, contagious[i]);
			}

			flipView = false;

			if(!shades.toString().equals(""))
			{
				defineShades(shades.toString());
			}
			else
			{
				defineShades("");
			}
			Display(false);
			
			StringBuffer title = new StringBuffer("Universal Chessboard");
			if(!name.toString().equals("") && author.toString().equals(""))
			{
				title.append(" - " + name);
			}
			else if(name.toString().equals("") && !author.toString().equals(""))
			{
				title.append(" - (Unspecified) by " + author);
			}
			else if(!name.toString().equals("") && !author.toString().equals(""))
			{
				title.append(" - " + name + " by " + author);
			}
			boardStage.setTitle(title.toString());
		}
		ResetEvents(true);
		preset = new StringBuffer(newPresetText);
		mainVBox = new VBox(menuHBox, boardPane);
		mainVBox.setAlignment(Pos.TOP_CENTER);
		mainVBox.setSpacing(0.0);
		boardScene = new Scene(mainVBox);
		createKeyBoardShortcuts();
		boardStage.setScene(boardScene);
	}
	
	public String expandStartCoordRegions(String startCoordsList)
	{
		if(!startCoordsList.contains("-"))
		{
			return startCoordsList;
		}
		String[] startCoords = startCoordsList.split(",");
		for(int i = 0; i < startCoords.length; ++i)
		{
			Pattern validCoordFormat1 = Pattern.compile("([a-z]{1}[0-9]{1})-([a-z]{1}[0-9]{1})");
			Pattern validCoordFormat2 = Pattern.compile("([a-z]{1}[0-9]{1})-([a-z]{1}[0-9]{2})");
			Pattern validCoordFormat3 = Pattern.compile("([a-z]{1}[0-9]{2})-([a-z]{1}[0-9]{1})");
			Pattern validCoordFormat4 = Pattern.compile("([a-z]{1}[0-9]{2})-([a-z]{1}[0-9]{2})");
			Matcher m1 = validCoordFormat1.matcher(startCoords[i]);
			Matcher m2 = validCoordFormat2.matcher(startCoords[i]);
			Matcher m3 = validCoordFormat3.matcher(startCoords[i]);
			Matcher m4 = validCoordFormat4.matcher(startCoords[i]);
			
			if(m1.matches() || m2.matches())
			{
				String startFileChar = Character.toString(startCoords[i].charAt(0));
				String startRankStr = startCoords[i].substring(1, 2);
				
				String endFileChar = Character.toString(startCoords[i].charAt(3));
				String endRankStr = startCoords[i].substring(4);
				
				StringBuffer newStartCoordsBuffer = new StringBuffer();
				
				int startFile = fileID(startFileChar, false);
				int endFile = fileID(endFileChar, false);
				
				int startRank = Integer.parseInt(startRankStr);
				int endRank = Integer.parseInt(endRankStr);
				
				for(int j = startRank; j <= endRank; ++j)
				{
					for(int k = startFile; k <= endFile; ++k)
					{
						int fileNumber = k + 97;
						char file = (char)fileNumber;
						newStartCoordsBuffer.append(String.valueOf(file) + Integer.toString(j));
						if(j != endRank || k != endFile)
						newStartCoordsBuffer.append(",");
					}
				}
				startCoords[i] = newStartCoordsBuffer.toString();
			}
			
			if(m3.matches() || m4.matches())
			{
				String startFileStr = Character.toString(startCoords[i].charAt(0));
				String startRankStr = startCoords[i].substring(1, 3);
				
				String endFileStr = Character.toString(startCoords[i].charAt(4));
				String endRankStr = startCoords[i].substring(5);
				
				StringBuffer newStartCoordsBuffer = new StringBuffer();
				
				int startFile = fileID(startFileStr, false);
				int endFile = fileID(endFileStr, false);
				
				int startRank = Integer.parseInt(startRankStr);
				int endRank = Integer.parseInt(endRankStr);
				
				for(int j = startRank; j <= endRank; ++j)
				{
					for(int k = startFile; k <= endFile; ++k)
					{
						int fileNumber = k + 97;
						char file = (char)fileNumber;
						newStartCoordsBuffer.append(String.valueOf(file) + Integer.toString(j));
						if(j != endRank || k != endFile)
						newStartCoordsBuffer.append(",");
					}
				}
				startCoords[i] = newStartCoordsBuffer.toString();
			}
		}
		
		StringBuffer newStartCoords = new StringBuffer();
		
		for(int i = 0; i < startCoords.length; ++i)
		{
			newStartCoords.append(startCoords[i]);
			if(i < startCoords.length - 1)
			{
				newStartCoords.append(",");
			}
		}
		
		return newStartCoords.toString();
	}
	
	/**
	 * Shows the dialog for editing the board position with FEN Code
	 */
	public void showFENCodeDialog()
	{
		if(fenCodeStage.isShowing())
		{
			fenCodeStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Enter the desired position's FEN Code in the text area to the right.You can view the FEN Code of the current position on the left.\nWhen done, press Load FEN Code to load the position onto the board. This clears the game you have loaded.");
			instructionsLabel.setStyle("-fx-text-alignment:center;");
			
			Label currentFENStringLabel = new Label("Current Position's FEN Code");
			currentFENStringLabel.setStyle("-fx-underline:true");
			TextArea currentFENString = new TextArea();
			currentFENString.setEditable(false);
			currentFENString.setPrefHeight(250);
			currentFENString.setPrefColumnCount(30);
			currentFENString.setWrapText(true);
			currentFENString.setText(getFENCode());
			VBox currentFENStringVBox = new VBox(currentFENStringLabel, currentFENString);
			currentFENStringVBox.setAlignment(Pos.CENTER);
			currentFENStringVBox.setSpacing(10);
			
			Separator categorySeparator = new Separator(Orientation.VERTICAL);
			categorySeparator.setCenterShape(true);
			
			Label newFENStringLabel = new Label("New Position's FEN Code");
			newFENStringLabel.setStyle("-fx-underline:true");
			TextArea newFENString = new TextArea();
			newFENString.setPrefHeight(250);
			newFENString.setPrefColumnCount(30);
			newFENString.setWrapText(true);
			VBox newFENStringVBox = new VBox(newFENStringLabel, newFENString);
			newFENStringVBox.setAlignment(Pos.CENTER);
			newFENStringVBox.setSpacing(10);
			
			HBox fenCodeHBox = new HBox(currentFENStringVBox, categorySeparator, newFENStringVBox);
			fenCodeHBox.setAlignment(Pos.CENTER);
			fenCodeHBox.setSpacing(10);
			
			Label errorLabel = new Label("Error Text");
			errorLabel.setStyle("-fx-underline:true");
			
			TextArea fenCodeErrorText = new TextArea();
			fenCodeErrorText.setEditable(false);
			fenCodeErrorText.setPrefHeight(100);
			fenCodeErrorText.setPrefColumnCount(60);
			fenCodeErrorText.setWrapText(true);
			
			Button helpButton = new Button("Help");
			helpButton.setOnAction(e -> {
				showFENCodeHelp();
			});
			Button showRequirementsButton = new Button("Show FEN Code Requirements");
			showRequirementsButton.setOnAction(e -> {
				showFENCodeRequirements();
			});
			Button loadFENCodeButton = new Button("Load FEN Code");
			loadFENCodeButton.setOnAction(e -> {
				String errorString = loadFENCode(newFENString.getText());
				if(errorString != null)
				{
					fenCodeErrorText.setText(errorString);
				}
				else
				{
					fenCodeStage.close();
					boardStage.requestFocus();
					disableBoardEvents = false;
				}
			});
			
			HBox buttonHBox = new HBox(helpButton, showRequirementsButton, loadFENCodeButton);
			buttonHBox.setAlignment(Pos.CENTER);
			buttonHBox.setSpacing(10);
			
			VBox fenCodeVBox = new VBox(instructionsLabel, fenCodeHBox, errorLabel, fenCodeErrorText, buttonHBox);
			fenCodeVBox.setAlignment(Pos.CENTER);
			fenCodeVBox.setSpacing(10);
			fenCodeVBox.setPadding(new Insets(10));
			
			Scene fenCodeScene = new Scene(fenCodeVBox);
			fenCodeStage = new Stage();
			fenCodeStage.setScene(fenCodeScene);
			fenCodeStage.setTitle("Edit FEN Code");
			fenCodeStage.setOnCloseRequest(e -> {
				disableBoardEvents = false;
				fenCodeRequirementsStage.close();
			});
			fenCodeStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			fenCodeStage.show();
		}
	}
	
	/**
	 * Shows help section for the FEN Code 
	 */
	public void showFENCodeHelp()
	{
		if(fenCodeHelpStage.isShowing())
		{
			fenCodeHelpStage.requestFocus();
		}
		else
		{
			TextArea fenCodeHelpText = new TextArea(HelpText.getFENCode());
			fenCodeHelpText.setWrapText(true);
			fenCodeHelpText.setEditable(false);
			fenCodeHelpText.setPrefHeight(300);
			fenCodeHelpText.setPrefColumnCount(40);
			
			Scene fenCodeHelpScene = new Scene(fenCodeHelpText);
			fenCodeHelpStage = new Stage();
			fenCodeHelpStage.setScene(fenCodeHelpScene);
			fenCodeHelpStage.sizeToScene();
			fenCodeHelpStage.setTitle("Help - FEN Code");
			fenCodeHelpStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			fenCodeHelpStage.show();
		}
	}
	
	/**
	 * Shows the FEN string requirements for the current game.
	 */
	public void showFENCodeRequirements()
	{
		if(fenCodeRequirementsStage.isShowing())
		{
			fenCodeRequirementsStage.requestFocus();
		}
		else
		{
			Label rankRequirement = new Label("Required number of ranks: " + nRanks + "\n(" + (nRanks - 1) + " Slashes (/))");
			rankRequirement.setStyle("-fx-text-alignment:center");
			rankRequirement.setWrapText(true);	
			Label fileRequirement = new Label("Maximum number of squares in each rank: " + nFiles);
			fileRequirement.setStyle("-fx-text-alignment:center");
			fileRequirement.setWrapText(true);	
			
			GridPane pieceMap = new GridPane();
			
			Label pieceMapHeaderLabel1 = new Label(" White ID ");
			StackPane pieceMapHeader1 = new StackPane(pieceMapHeaderLabel1);
			pieceMapHeader1.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			Label pieceMapHeaderLabel2 = new Label(" White Image ");
			StackPane pieceMapHeader2 = new StackPane(pieceMapHeaderLabel2);
			pieceMapHeader2.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			Label pieceMapHeaderLabel3 = new Label(" Black ID ");
			StackPane pieceMapHeader3 = new StackPane(pieceMapHeaderLabel3);
			pieceMapHeader3.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			Label pieceMapHeaderLabel4 = new Label(" Black Image ");
			StackPane pieceMapHeader4 = new StackPane(pieceMapHeaderLabel4);
			pieceMapHeader4.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			
			pieceMap.add(pieceMapHeader1, 0, 0);
			pieceMap.add(pieceMapHeader2, 1, 0);
			pieceMap.add(pieceMapHeader3, 2, 0);
			pieceMap.add(pieceMapHeader4, 3, 0);
			for(int i = 1; i <= board.getNPieceTypes(); ++i)
			{
				StringBuffer pieceID = new StringBuffer(pieceList.getPiece(i).getPieceID());
				String wID;
				String bID;
				if(pieceID.length() > 1)
				{
					pieceID = new StringBuffer("{" + pieceID + "}");
				}
				if(shogiMode)
				{
					wID = pieceID.toString().toLowerCase();
					bID = pieceID.toString().toUpperCase();
				}
				else
				{
					wID = pieceID.toString().toUpperCase();
					bID = pieceID.toString().toLowerCase();
				}
				
				ImageView wPieceImage = pieceList.getPieceImage(i);
				ImageView bPieceImage = pieceList.getPieceImage(i + board.getNPieceTypes());
				
				Label wPieceLabel = new Label(wID);
				StackPane wPieceID = new StackPane(wPieceLabel);
				wPieceID.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				StackPane wPiece = new StackPane(wPieceImage);
				wPiece.setMinSize(squareSize, squareSize);
				wPiece.setPrefSize(squareSize, squareSize);
				wPiece.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				Label bPieceLabel = new Label(bID);
				StackPane bPieceID = new StackPane(bPieceLabel);
				bPieceID.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				StackPane bPiece = new StackPane(bPieceImage);
				bPiece.setMinSize(squareSize, squareSize);
				bPiece.setPrefSize(squareSize, squareSize);
				bPiece.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				pieceMap.add(wPieceID, 0, i);
				pieceMap.add(wPiece, 1, i);
				pieceMap.add(bPieceID, 2, i);
				pieceMap.add(bPiece, 3, i);
			}
			
			pieceMap.setPadding(new Insets(0));
			pieceMap.setHgap(0);
			pieceMap.setVgap(0);
			
			VBox fenCodeRequirementsVBox = new VBox(rankRequirement, fileRequirement, pieceMap);
			fenCodeRequirementsVBox.setAlignment(Pos.CENTER);
			fenCodeRequirementsVBox.setSpacing(10);
			ScrollPane fenScrollPane = new ScrollPane();
			fenScrollPane.fitToWidthProperty().set(true);
			fenScrollPane.fitToHeightProperty().set(true);
			fenScrollPane.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
			fenScrollPane.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
			fenScrollPane.setPadding(new Insets(0));
			fenScrollPane.setContent(fenCodeRequirementsVBox);
			StackPane fenPane = new StackPane(fenScrollPane);
			
			Scene fenCodeRequirementsScene = new Scene(fenPane);
			fenCodeRequirementsStage = new Stage();
			fenCodeRequirementsStage.setScene(fenCodeRequirementsScene);
			
			fenPane.setMaxWidth(screenWidth);
			fenPane.setMaxHeight(screenHeight);
			
			fenCodeRequirementsStage.setTitle("Requirements");
			fenCodeRequirementsStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			fenCodeRequirementsStage.show();
		}
	}
	
	/**
	 * Gets the FEN String of the current position.
	 */
	public String getFENCode()
	{
		StringBuffer fenCode = new StringBuffer();

		for(int i = nRanks - 1; i >= 0; --i)
		{
			int emptySquares = 0;
			for(int j = 0; j < nFiles; ++j)
			{
				int piece = board.getPieceOnSquare(j, i);
				if(piece == -1) {
					if(emptySquares > 0)
					{
						fenCode.append(Integer.toString(emptySquares));
						emptySquares = 0;
			        }
					fenCode.append("-");
					emptySquares = 0;
				}
				else if(piece == 0) {
					++emptySquares;
				}
				else
				{
					if(emptySquares > 0)
					{
						fenCode.append(Integer.toString(emptySquares));
						emptySquares = 0;
			        }
					String pieceID = pieceList.getPiece(piece).getPieceID();
					String fenID;
					if(shogiMode)
					{
						if(piece <= board.getNPieceTypes())
						{
							fenID = pieceID.toLowerCase();
						}
						else
						{
							fenID = pieceID.toUpperCase();
						}
					}
					else
					{
						if(piece > board.getNPieceTypes())
						{
							fenID = pieceID.toLowerCase();
						}
						else
						{
							fenID = pieceID.toUpperCase();
						}
					}
					if(fenID.length() > 1)
					{
						fenCode.append("{" + fenID + "}");
					}
					else
					{
						fenCode.append(fenID);
					}
			    }
			}
		    if(emptySquares > 0) {
		    	fenCode.append(Integer.toString(emptySquares));
		    	emptySquares = 0;
		    }
		    if(i > 0) {
		    	fenCode.append("/");
		    }
		}
		
		if(board.getHoldingsType() != 0)
		{
			fenCode.append("[");
			int[] hand = board.getHand();
			for(int i = 0; i < hand.length; ++i)
			{
				if(hand[i] > 0)
				{
					int piece = i + 1;
					String pieceID = pieceList.getPiece(piece).getPieceID();
					String handID;
					if(shogiMode)
					{
						if(piece <= board.getNPieceTypes())
						{
							handID = pieceID.toLowerCase();
						}
						else
						{
							handID = pieceID.toUpperCase();
						}
					}
					else
					{
						if(piece > board.getNPieceTypes())
						{
							handID = pieceID.toLowerCase();
						}
						else
						{
							handID = pieceID.toUpperCase();
						}
					}
					for(int j = 0; j < hand[i]; ++j)
					{
						if(handID.length() > 1)
						{
							fenCode.append("{" + handID + "}");
						}
						else
						{
							fenCode.append(handID);
						}
					}
				}
			}
			fenCode.append("]");
		}
		return fenCode.toString();
	}
	
	/**
	 * Loads a position on the board from a FEN String and</br>
	 * Clears the game that is currently loaded. This</br>
	 * method performs rigorous error checking before</br>
	 * loading the position on the board. If the FEN String</br>
	 * contains any errors, it instead returns an error</br>
	 * message indicating what when wrong.
	 * @param code the FEN String from which to load the new board position
	 */
	public String loadFENCode(String fenString)
	{
		fenString = fenString.replaceAll("\\s", "");
		if(fenString.equals("")) // exit early if string is empty
		{
			String nullFENError = "NullFENCodeException: Cannot load a null FEN string. Enter " + (nRanks - 1) + " slashes for an empty board.";
			return nullFENError;
		}
		
		StringBuffer fenStringBuffer = new StringBuffer(fenString);
		int fenBufferPos = 0;
		if(fenString.charAt(0) == '/')
		{
			fenStringBuffer.insert(0, Integer.toString(nFiles));
			fenBufferPos += Integer.toString(nFiles).length() + 1;
		}
		else
		{
			++fenBufferPos;
		}
		
		for(int i = 0; i < fenString.length() - 1; ++i)
		{
			if(fenString.charAt(i) == '/' && fenString.charAt(i + 1) == '/')
			{
				fenStringBuffer.insert(fenBufferPos, Integer.toString(nFiles));
				fenBufferPos += Integer.toString(nFiles).length() + 1;
			}
			else
			{
				++fenBufferPos;
			}
		}
		
		if(fenString.charAt(fenString.length() - 1) == '/')
		{
			fenStringBuffer.append(Integer.toString(nFiles));
		}
		
		String fenCode = fenStringBuffer.toString();
		
		String[] ranks = fenCode.split("/"); // split into individual ranks
		if(ranks.length > nRanks) // ensure number of ranks is correct
		{
			return "RanksOutOfBoundsException(0): The given FEN String has too many ranks. Number of ranks required: " + nRanks + ".";
		}
		else if(ranks.length < nRanks)
		{
			return "RanksOutOfBoundsException(1): The given FEN String has too few ranks. Number of ranks required: " + nRanks + ".";
		}
		
		int rankOverflow = 0; // detect if a file is too large
		ArrayList<String> overflowingRanks = new ArrayList<String>();
		
		for(int i = 0; i < ranks.length; ++i) // get all numbers in rank
		{
			if(ranks[i].equals(""))
			{
				continue;
			}
			ArrayList<String> numbers = new ArrayList<String>(); // create ArrayList for numbers
			Pattern p = Pattern.compile("\\d+");
			Matcher m = p.matcher(ranks[i]);
			while(m.find())
			{
				numbers.add(m.group());
			}
			
			int rankLength = 0; // keep track of rank length
			int numberN = 0; // keep track of current number
			int index = 0; // keep track of read position
			
			while(index < ranks[i].length()) // loop through all characters in rank string
			{
				if(ranks[i].charAt(index) >= '0' && ranks[i].charAt(index) <= '9')
				{
					rankLength += Integer.parseInt(numbers.get(numberN)); // add number to rank length
					index += numbers.get(numberN).length(); // advance past the number
					++numberN; // increment counter for next match
				}
				else if(ranks[i].charAt(index) == '-') // hole in board
				{
					++rankLength;
					++index;
				}
				else if(ranks[i].charAt(index) >= 'A' && ranks[i].charAt(index) <= 'Z') // uppercase letters
				{
					++rankLength;
					++index;
				}
				else if(ranks[i].charAt(index) >= 'a' && ranks[i].charAt(index) <= 'z') // lowercase letters
				{
					++rankLength;
					++index;
				}
				else if(ranks[i].charAt(index) == '{') // piece ID enclosed in curly brackets
				{
					++rankLength;
	    			int endPosition = ranks[i].indexOf("}", index);
	    			if(endPosition == -1) // exit if no closing curly bracket is found
	    			{
	    				return "InvalidCurlyBracketException(" + i + ", " + index + "): There must be a closing curly bracket for every opening curly bracket in a FEN rank.";
	    			}
	    			else // exit if unbalanced curly brackets are found
	    			{
	    				for(int j = index + 1; j < endPosition; ++j)
	    				{
	    					if(ranks[i].charAt(j) == '{')
	    					{
	    						return "InvalidCurlyBracketException(" + i + ", " + j + "): Opening curly brackets cannot be used as part of a piece ID.";
	    					}
	    				}
	    			}
	    			String pieceID = ranks[i].substring(index + 1, endPosition);
	    			index += pieceID.length() + 2;
				}
				else if(ranks[i].charAt(index) == '[')
				{
	    			int endPosition = ranks[i].indexOf("]", index);
	    			if(endPosition == -1) // exit if no closing square bracket is found
	    			{
	    				return "InvalidSquareBracketException(" + i + ", " + index + "): There must be a closing square bracket for every opening square bracket in a FEN string.";
	    			}
	    			else // exit if unbalanced square brackets are found
	    			{
	    				for(int j = index + 1; j < endPosition; ++j)
	    				{
	    					if(ranks[i].charAt(j) == '[')
	    					{
	    						return "InvalidSquareBracketException(" + i + ", " + j + "): Opening square brackets cannot be used as part of a piece ID.";
	    					}
	    				}
	    			}
	    			String handID = ranks[i].substring(index + 1, endPosition);
	    			index += handID.length() + 2;
				}
				else if(ranks[i].charAt(index) == '}') // exit if a closing curly brackets is not ending a piece ID with multiple characters
				{
					return "InvalidCurlyBracketException(" + i + ", " + index + "): Closing curly brackets cannot be used as part of a piece ID.";
				}
				else if(ranks[i].charAt(index) == ']') // exit if a closing curly brackets is not ending a piece ID with multiple characters
				{
					return "InvalidSquareBracketException(" + i + ", " + index + "): Closing square brackets cannot be used as part of a piece ID.";
				}
				else // exit if invalid character
				{
					return "InvalidCharException(" + i + ", " + index + "): The character '" + ranks[i].charAt(index) + "' cannot be used in a FEN String without being part of a valid piece ID.";
				}
			}
			if(rankLength > nFiles) // increment fileOverflow if rank is too large
			{
				++rankOverflow;
				overflowingRanks.add(0, Integer.toString(i));
			}
		}
		if(rankOverflow > 0)
		{
			StringBuffer rankOverflows = new StringBuffer();
			for(int i = overflowingRanks.size() - 1; i >= 0; --i)
			{
				rankOverflows.append(overflowingRanks.get(i));
				if(i > 0)
				{
					rankOverflows.append(", ");
				}
			}
			if(rankOverflow == 1)
			{
				return "FileOutOfBoundsException: 1 rank (" + rankOverflows.toString() + ") in the FEN String has too many files. Max. number of files: " + nFiles + ".";
			}
			else
			{
				return "FilesOutOfBoundsException: " + rankOverflow + " ranks (" + rankOverflows.toString() + ") in the FEN String has too many files. Max. number of files: " + nFiles + ".";
			}
		}
		
		int[][] board2 = new int[nRanks][nFiles]; // buffer for new board position
		int[] hand2 = new int[board.getMaxPieces()];
		
		for(int y = nRanks - 1; y >= 0; --y) // loop through ranks (y-coordinate)
		{
			int rankString = nRanks - 1 - y; // corresponding FEN rank
			String fenRank = ranks[rankString];
			
			ArrayList<String> emptyRowsReg = new ArrayList<String>(); // create ArrayList for numbers
			Pattern p = Pattern.compile("\\d+");
			Matcher m = p.matcher(fenRank);
			while(m.find())
			{
				emptyRowsReg.add(m.group());
			}
			
			int x = 0; // x-coordinate
			int emptyRowN = 0; // keep track of number of empty rows
			int index = 0; // keep track of read position
			
			while(index < fenRank.length())
			{
				if(fenRank.charAt(index) >= '0' && fenRank.charAt(index) <= '9')
				{
					x += Integer.parseInt(emptyRowsReg.get(emptyRowN)); // advance past the empty squares
					index += emptyRowsReg.get(emptyRowN).length(); // advance past the number
					++emptyRowN; // increment counter for next match
				}
				else if(fenRank.charAt(index) == '-') // hole in board
				{
					board2[y][x] = -1; // make this square a hole
		            ++x; // advance to the next square in board rank
		            ++index; // advance to the next element in FEN rank
				}
				else if(fenRank.charAt(index) >= 'A' && fenRank.charAt(index) <= 'Z') // uppercase letters
				{
					String ID = Character.toString(fenRank.charAt(index)).toUpperCase(); // ID to search for
					int piece = idToPiece(ID); // search for piece
					if(piece < 0) // exit if piece is not supported
					{
						return "InvalidPieceIDException(0): The piece ID " + fenRank.charAt(index) + " is not supported.";
					}
					else
					{
						piece += (shogiMode) ? board.getNPieceTypes() : 0; // determine color
						board2[y][x] = piece; // put piece on board
						++x; // advance to the next square
						++index; // advance to the next element in FEN rank
					}
				}
				else if(fenRank.charAt(index) >= 'a' && fenRank.charAt(index) <= 'z') // lowercase letters
				{
					String ID = Character.toString(fenRank.charAt(index)).toUpperCase(); // ID to search for
					int piece = idToPiece(ID); // search for piece
					if(piece < 0) // exit if piece is not supported
					{
						return "InvalidPieceIDException(1): The piece ID " + fenRank.charAt(index) + " is not supported.";
					}
					else
					{
						piece += (shogiMode) ? 0 : (board.getNPieceTypes()); // determine color
						board2[y][x] = piece; // put piece on board
						++x; // advance to the next square
						++index; // advance to the next element in FEN rank
					}
				}
				else if(fenRank.charAt(index) == '{') // piece ID enclosed in curly brackets
				{
	    			int endPosition = fenRank.indexOf("}", index);
	    			String pieceID = fenRank.substring(index + 1, endPosition);
	    			if(pieceID.equals(pieceID.toUpperCase()))
	    			{
	    				int piece = idToPiece(pieceID);
						if(piece < 0) // exit if piece is not supported
						{
							return "InvalidPieceIDException(2): The piece ID " + fenRank.charAt(index) + " is not supported.";
						}
						else
						{
							piece += (shogiMode) ? board.getNPieceTypes() : 0; // determine color
							board2[y][x] = piece; // put piece on board
						}
	    			}
	    			else if(pieceID.equals(pieceID.toLowerCase()))
	    			{
	    				int piece = idToPiece(pieceID.toUpperCase());
						if(piece < 0) // exit if piece is not supported
						{
							return "InvalidPieceIDException(3): The piece ID " + fenRank.charAt(index) + " is not supported.";
						}
						else
						{
							piece += (shogiMode) ? 0 : board.getNPieceTypes(); // determine color
							board2[y][x] = piece; // put piece on board
						}
	    			}
	    			else
	    			{
	    				return "InvalidPieceIDException(4): The piece ID " + fenRank.charAt(index) + " is not supported.";
	    			}
					++x; // advance to the next square
					index += pieceID.length() + 2; // advance to the next element in FEN rank
				}
				else if(fenRank.charAt(index) == '[') // pieces in holdings
				{
	    			int endPosition = fenRank.indexOf("]", index);
	    			String handString = fenRank.substring(index + 1, endPosition);
	    			String newHand = loadFENHand(handString, hand2);
	    			if(newHand != null)
	    			{
	    				return newHand;
	    			}
	    			index += handString.length() + 2;
				}
				else // catch if all other tests fail
				{
					return "InvalidPieceIDException(5): The piece ID " + fenRank.charAt(index) + " is not supported.";
				}
			}
		}
		
		for(int y = 0; y < nRanks; ++y)
		{
			for(int x = 0; x < nFiles; ++x)
			{
				board.setVirginPieceOnSquare(x, y, board2[y][x]); // set virgin piece on square
			}
		}
		
		for(int i = 1; i <= board.getMaxPieces(); ++i)
		{
			board.setNPiecesInHand(i, hand2[i - 1]);
		}
		
		board.getGame().get(0).setBoardPosition(board.getBoard());
		board.getGame().get(0).setHoldings(board.getHand());
		newGame(false);
		
		Display(false); // update board display
		ResetEvents(true); // reset board events
		updateLastMoveSquares(-1, -1, null, null, -1, -1);
		return null;
	}
	
	public String loadFENHand(String handString, int[] hand)
	{
		int index = 0;
		while(index < handString.length())
		{
			if(handString.charAt(index) >= 'A' && handString.charAt(index) <= 'Z') // uppercase letters
			{
				String ID = Character.toString(handString.charAt(index)).toUpperCase(); // ID to search for
				int piece = idToPiece(ID); // search for piece
				if(piece < 0) // exit if piece is not supported
				{
					return "InvalidPieceIDException(0): The piece ID " + handString.charAt(index) + " is not supported.";
				}
				else
				{
					piece += (shogiMode) ? board.getNPieceTypes() : 0; // determine color
					++hand[piece - 1]; // put piece in hand
					++index; // advance to the next element in FEN rank
				}
			}
			else if(handString.charAt(index) >= 'a' && handString.charAt(index) <= 'z') // lowercase letters
			{
				String ID = Character.toString(handString.charAt(index)).toUpperCase(); // ID to search for
				int piece = idToPiece(ID); // search for piece
				if(piece < 0) // exit if piece is not supported
				{
					return "InvalidPieceIDException(1): The piece ID " + handString.charAt(index) + " is not supported.";
				}
				else
				{
					piece += (shogiMode) ? 0 : (board.getNPieceTypes()); // determine color
					++hand[piece - 1]; // put piece in hand
					++index; // advance to the next element in FEN hand
				}
			}
			else if(handString.charAt(index) == '{') // piece ID enclosed in curly brackets
			{
    			int endPosition = handString.indexOf("}", index);
    			String pieceID = handString.substring(index + 1, endPosition);
    			if(pieceID.equals(pieceID.toUpperCase()))
    			{
    				int piece = idToPiece(pieceID);
					if(piece < 0) // exit if piece is not supported
					{
						return "InvalidHandIDException(0): The piece ID " + handString.charAt(index) + " is not supported.";
					}
					else
					{
						piece += (shogiMode) ? board.getNPieceTypes() : 0; // determine color
						++hand[piece - 1]; // put piece in hand
					}
    			}
    			else if(pieceID.equals(pieceID.toLowerCase()))
    			{
    				int piece = idToPiece(pieceID.toUpperCase());
					if(piece < 0) // exit if piece is not supported
					{
						return "InvalidHandIDException(1): The piece ID " + handString.charAt(index) + " is not supported.";
					}
					else
					{
						piece += (shogiMode) ? 0 : board.getNPieceTypes(); // determine color
						++hand[piece - 1]; // put piece in hand
					}
    			}
    			else
    			{
    				return "InvalidHandIDException(2): The piece ID " + handString.charAt(index) + " is not supported.";
    			}
				index += pieceID.length() + 2; // advance to the next element in FEN hand
			}
			else
			{
				return "InvalidHandIDException(3): The piece ID " + handString.charAt(index) + " is not supported.";
			}
		}
		return null;
	}
	
	public int idToPiece(String id)
	{
		return board.idToPiece(id);
	}
	
	public void showGameMovesDialog()
	{
		if(gameMovesStage.isShowing())
		{
			gameMovesStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Enter the move sequence to append in the text area to the right.\nYou can view the current game's move sequence by clicking on\nShow Move History in the View Menu. When done, press\nAppend Game Moves to append the move sequence.");
			instructionsLabel.setStyle("-fx-text-alignment:center;");
			Label newGameMovesLabel = new Label("Move Sequence to Append");
			newGameMovesLabel.setStyle("-fx-underline:true");
			TextArea newGameMoves = new TextArea();
			newGameMoves.setPrefHeight(250);
			newGameMoves.setPrefColumnCount(30);
			newGameMoves.setWrapText(true);
			
			Label errorLabel = new Label("Error Text");
			errorLabel.setStyle("-fx-underline:true");
			
			TextArea gameMovesErrorText = new TextArea();
			gameMovesErrorText.setEditable(false);
			gameMovesErrorText.setPrefHeight(100);
			gameMovesErrorText.setPrefColumnCount(30);
			gameMovesErrorText.setWrapText(true);
			
			Button helpButton = new Button("Help");
			helpButton.setOnAction(e -> {
				//showGameMoveHelp();
			});
			Button showRequirementsButton = new Button("Show Game Move Requirements");
			showRequirementsButton.setOnAction(e -> {
				//showGameMoveRequirements();
			});
			Button loadGameMovesButton = new Button("Append Game Moves");
			
			HBox buttonHBox = new HBox(helpButton, showRequirementsButton, loadGameMovesButton);
			buttonHBox.setAlignment(Pos.CENTER);
			buttonHBox.setSpacing(10);
			
			VBox gameMovesVBox = new VBox(instructionsLabel, newGameMovesLabel, newGameMoves, errorLabel, gameMovesErrorText, buttonHBox);
			gameMovesVBox.setAlignment(Pos.CENTER);
			gameMovesVBox.setSpacing(10);
			gameMovesVBox.setPadding(new Insets(10));
			
			Scene gameMovesScene = new Scene(gameMovesVBox);
			gameMovesStage = new Stage();
			gameMovesStage.setScene(gameMovesScene);
			
			loadGameMovesButton.setOnAction(e -> {
			setToLoadingScene(gameMovesStage);
				String errorString = loadGameMoves(newGameMoves.getText(), newGameMoves);
				if(errorString != null)
				{
					gameMovesErrorText.setText(errorString);
				}
				else
				{
					gameMovesErrorText.clear();
					boardStage.requestFocus();
				}
				gameMovesStage.setScene(gameMovesScene);
				gameMovesStage.setTitle("Append Game Moves");
			});
			
			gameMovesStage.setTitle("Append Game Moves");
			gameMovesStage.setOnCloseRequest(e -> {
				disableBoardEvents = false;
				gameMoveRequirementsStage.close();
			});
			gameMovesStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			gameMovesStage.show();
		}
	}
	
	public String getGameMoves()
	{
		StringBuffer moveSequence = new StringBuffer();
		for(int i = 1; i < board.getGame().size(); ++i)
		{
			int originX = board.getGame().get(i).getOriginX();
			int originY = board.getGame().get(i).getOriginY();
			ArrayList<Integer> enPassantX = board.getGame().get(i).getEX();
			ArrayList<Integer> enPassantY = board.getGame().get(i).getEY();
			int destinationX = board.getGame().get(i).getDestX();
			int destinationY = board.getGame().get(i).getDestY();
			int promotion = board.getGame().get(i).getPromotion();
			
			if(originX > 0 && originX <= board.getMaxPieces() && originY == -1)
			{
				String handOrigin = pieceList.getPiece(originX).getPieceID();
				if(shogiMode)
				{
					if(originX <= board.getNPieceTypes())
					{
						handOrigin = handOrigin.toLowerCase();
					}
					else
					{
						handOrigin = handOrigin.toUpperCase();
					}
				}
				else
				{
					if(originX > board.getNPieceTypes())
					{
						handOrigin = handOrigin.toLowerCase();
					}
					else
					{
						handOrigin = handOrigin.toUpperCase();
					}
				}
				moveSequence.append(handOrigin + "-");
			}
			else
			{
				String originFile = fileName(originX);
				String originRank = rankName(originY);
				
				moveSequence.append(originFile + originRank + "-");
			}
			
			int maxIntermediateMoves = Math.min(enPassantX.size(), enPassantY.size());
			
			for(int j = 0; j < maxIntermediateMoves; ++j)
			{
				String enPassantFile = fileName(enPassantX.get(j));
				String enPassantRank = rankName(enPassantY.get(j));
				moveSequence.append(enPassantFile + enPassantRank + "-");
			}
			
			String destFile = fileName(destinationX);
			String destRank = rankName(destinationY);
			
			moveSequence.append(destFile + destRank);
			
			String promotionID;
			if(promotion >= 0)
			{
				if(promotion == 0)
				{
					promotionID = "?";
					moveSequence.append("-" + promotionID);
				}
				else
				{
					promotionID = pieceList.getPiece(promotion).getPieceID();
					moveSequence.append("-" + promotionID);
				}
			}
			
			if(i < board.getGame().size() - 1)
			{
				moveSequence.append(" ");
			}
		}
		return moveSequence.toString();
	}
	
	public String fileName(int id)
	{
		if(shogiMode)
		{
			return Integer.toString(nFiles - id);
		} else {
			return String.valueOf((char)(id + 97));
		}
	}
	
	public String rankName(int id)
	{
		if(shogiMode)
		{
			return String.valueOf((char)((nRanks - 1 - id) + 97));
		} else {
			return Integer.toString(id + 1);
		}
	}
	
	public String loadGameMoves(String moveSequenceText, TextArea textArea)
	{
		moveSequenceText = moveSequenceText.trim();
		String[] moveSequence = moveSequenceText.split(" ");
		
		int originX = -1;
		int originY = -1;
		ArrayList<Integer> ex = new ArrayList<Integer>();
		ArrayList<Integer> ey = new ArrayList<Integer>();
		int destX = -1;
		int destY = -1;
		int promotion = -1;
		Display(false);
		for(int i = 0; i < moveSequence.length; ++i)
		{
			originX = -1;
			originY = -1;
			ex.clear();
			ey.clear();
			destX = -1;
			destY = -1;
			promotion = -1;
			
			String[] moveParts = moveSequence[i].split("-");
			
			if(moveParts.length < 2)
			{
				return "TooFewMoveElementsException: The move '" + moveSequence[i] + "' has too few elements. Minimum number of elements: 2";
			}
			
			if(moveParts.length == 2) // single move or drop
			{
				String[] firstIsCoord = isSquare(moveParts[0]);
				String firstIsPiece = isPiece(moveParts[0]);
				String[] secondIsCoord = isSquare(moveParts[1]);
				
				if(firstIsCoord == null && firstIsPiece == null)
				{
					return "InvalidMoveElementException: Element 1 of the 2-element move '" + moveSequence[i] + "' must be either a valid square coordinate or a valid piece ID  (case-sensitive).";
				}
				else
				{
					if(firstIsCoord != null)
					{
						originX = fileID(firstIsCoord[0], shogiMode);
						originY = rankID(firstIsCoord[1], shogiMode);
					}
					else if(firstIsPiece != null)
					{
						originX = idToPiece(firstIsPiece);
						originY = -1;
					}
				}
				if(secondIsCoord == null)
				{
					return "InvalidMoveElementException: Element 2 of the 2-element move '" + moveSequence[i] + "' must be a valid square coordinate.";
				}
				else
				{
					destX = fileID(secondIsCoord[0], shogiMode);
					destY = rankID(secondIsCoord[1], shogiMode);
				}
			}
			else if(moveParts.length == 3) // single move with promotion or double move
			{
				String[] firstIsCoord = isSquare(moveParts[0]);
				String[] secondIsCoord = isSquare(moveParts[1]);
				String[] thirdIsCoord = isSquare(moveParts[2]);
				String thirdIsPiece = isPiece(moveParts[2]);
				if(firstIsCoord == null)
				{
					return "InvalidMoveElementException: Element 1 of the 3-element move '" + moveSequence[i] + "' must be a valid square coordinate.";
				}
				else
				{
					originX = fileID(firstIsCoord[0], shogiMode);
					originY = rankID(firstIsCoord[1], shogiMode);
				}
				if(secondIsCoord == null)
				{
					return "InvalidMoveElementException: Element 2 of the 3-element move '" + moveSequence[i] + "' must be a valid square coordinate.";
				}
				if(thirdIsCoord == null && thirdIsPiece == null)
				{
					return "InvalidMoveElementException: Element 3 of the 3-element move '" + moveSequence[i] + "' must be either a valid square coordinate or a valid piece ID (case-insensitive).";
				}
				else
				{
					if(thirdIsCoord != null)
					{
						ex.add(fileID(secondIsCoord[0], shogiMode));
						ex.add(rankID(secondIsCoord[1], shogiMode));
						
						destX = fileID(thirdIsCoord[0], shogiMode);
						destY = rankID(thirdIsCoord[1], shogiMode);
					}
					else if(thirdIsPiece != null)
					{
						destX = fileID(secondIsCoord[0], shogiMode);
						destY = rankID(secondIsCoord[1], shogiMode);
						
						promotion = board.getPieceType(idToPiece(thirdIsPiece.toUpperCase()));
						if(board.getPieceType(idToPiece(thirdIsPiece)) > board.getNPieceTypes())
						{
							promotion += board.getNPieceTypes();
						}
					}
				}
			}
			else // multi-move with or without promotion
			{
				String[] firstIsCoord = isSquare(moveParts[0]);
				if(firstIsCoord == null)
				{
					return "InvalidMoveElementException: Element 1 of the " + moveParts.length + "-element move '" + moveSequence[i] + "' must be a valid square coordinate.";
				}
				else
				{
					originX = fileID(firstIsCoord[0], shogiMode);
					originY = rankID(firstIsCoord[1], shogiMode);
				}
				for(int j = 1; j < moveParts.length - 2; ++j)
				{
					String[] intermediateIsCoord = isSquare(moveParts[j]);
					if(intermediateIsCoord == null)
					{
						return "InvalidMoveElementException: Element " + (j + 1) + " of the " + moveParts.length + "-element move '" + moveSequence[i] + "' must be a valid square coordinate.";
					}
					else
					{
						ex.add(fileID(intermediateIsCoord[0], shogiMode));
						ey.add(rankID(intermediateIsCoord[1], shogiMode));
					}
				}
				
				String[] lastIsCoord = isSquare(moveParts[moveParts.length - 1]);
				String lastIsPiece = isPiece(moveParts[moveParts.length - 1]);
				if(lastIsCoord == null && lastIsPiece == null)
				{
					return "InvalidMoveElementException: Element " + moveParts.length + " of the " + moveParts.length + "-element move '" + moveSequence[i] + "' must be either a valid square coordinate or a valid piece ID (case-insensitive).";
				}
				else
				{
					if(lastIsCoord != null)
					{
						String[] penultimateIsCoord = isSquare(moveParts[moveParts.length - 2]);
						ex.add(fileID(penultimateIsCoord[0], shogiMode));
						ey.add(rankID(penultimateIsCoord[1], shogiMode));
					}
					else if(lastIsPiece != null)
					{
						String[] penultimateIsCoord = isSquare(moveParts[moveParts.length - 2]);
						destX = fileID(penultimateIsCoord[0], shogiMode);
						destY = rankID(penultimateIsCoord[1], shogiMode);
						
						promotion = board.getPieceType(idToPiece(lastIsPiece.toUpperCase()));
						if(board.getPieceType(idToPiece(lastIsPiece)) > board.getNPieceTypes())
						{
							promotion += board.getNPieceTypes();
						}
					}
				}
			}
			if(board.getPieceOnSquare(originX, originY) < 1)
			{
				return "NullPieceException(" + moveSequence[i] + "): Cannot move a hole or an empty square.";
			}
			if(board.capturedIronPiece(originX, originY, ex, ey, destX, destY))
			{
				return "IronPieceCapturedException(" + moveSequence[i] + "): Cannot capture an iron piece.";
			}
			if(originX >= 1 && originX <= board.getMaxPieces() && originY == -1 && board.getPieceOnSquare(destX, destY) != 0)
			{
				return "InvalidDropException(" + moveSequence[i] +"): Cannot drop a piece onto a hole or an occupied square.";
			}
			
			if(board.capturedContagiousPiece(originX, originY, ex, ey, destX, destY) != -1 && !board.immuneToContagiousPromotions(board.getPieceOnSquare(originX, originY)))
			{
				int newPiece = board.capturedContagiousPiece(originX, originY, ex, ey, destX, destY);
				if(newPiece > board.getNPieceTypes())
				{
					newPiece -= board.getNPieceTypes();
				}
				else
				{
					newPiece += board.getNPieceTypes();
				}
				promotion = newPiece;
			}
			board.Move(originX, originY, ex, ey, destX, destY, promotion);
			updateLastMoveSquares(originX, originY, ex, ey, destX, destY);
			Display(false);
			StringBuffer trimmedMoveSequence = new StringBuffer();
			for(int j = i + 1; j < moveSequence.length; ++j)
			{
				trimmedMoveSequence.append(moveSequence[j]);
				if(j < moveSequence.length - 1)
				{
					trimmedMoveSequence.append(" ");
				}
			}
			textArea.setText(trimmedMoveSequence.toString());
		}
		return null;
	}
	
	public String[] isSquare(String str)
	{
		Pattern validCoordFormat1;
		Pattern validCoordFormat2;
		if(shogiMode)
		{
			validCoordFormat1 = Pattern.compile("([0-9]{1}[a-z]{1})");
			validCoordFormat2 = Pattern.compile("([0-9]{2}[a-z]{1})");
		}
		else
		{
			validCoordFormat1 = Pattern.compile("([a-z]{1}[0-9]{1})");
			validCoordFormat2 = Pattern.compile("([a-z]{1}[0-9]{2})");
		}
		
		Matcher m1 = validCoordFormat1.matcher(str);
		Matcher m2 = validCoordFormat2.matcher(str);
		
		String[] coordArray = new String[2];
		if(m1.matches())
		{
			coordArray[0] = str.substring(0,1);
			coordArray[1] = str.substring(1);
			return coordArray;
		}
		else if(m2.matches())
		{
			if(shogiMode)
			{
				coordArray[0] = str.substring(0,2);
				coordArray[1] = str.substring(2);
			}
			else
			{
				coordArray[0] = str.substring(0,1);
				coordArray[1] = str.substring(1);
			}
			return coordArray;
		}
		else
		{
			return null;
		}
	}
	
	public String isPiece(String str)
	{
		for(int i = 1; i <= board.getNPieceTypes(); ++i)
		{
			if(pieceList.getPiece(i).getPieceID().equalsIgnoreCase(str))
			{
				return str;
			}
		}
		return null;
	}
	
	/**
	 * Flips the board display, preserving all highlights.
	 */
	public void flipBoard() {
		if (flipView) {
			flipView = false;
		} else {
			flipView = true;
		}
		Display(true);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		boardStage.requestFocus();
	}

	/**
	 * Resets the viewing size and position of the application.
	 */
	public void resetViewingSize() {
		Window window = boardScene.getWindow();
		titleBarSize = window.getHeight() - boardScene.getHeight() - 10;
		viewingScreen = new ViewingScreen();
		screenWidth = viewingScreen.getScreenWidth();
		screenHeight = viewingScreen.getScreenHeight() - titleBarSize;
		
		int boardWidth = squareSize * nFiles + 2;
		int boardHeight = squareSize * nRanks + 2;
		if(boardWidth > screenWidth)
		{
			boardPane.setPrefWidth(screenWidth);
		}
		else
		{
			boardPane.setPrefWidth(boardWidth);
		}
		if(boardHeight > (screenHeight - boardMenu.getHeight()))
		{
			boardPane.setPrefHeight(screenHeight - boardMenu.getHeight());
		}
		else
		{
			boardPane.setPrefHeight(boardHeight);
		}
		
		boardStage.setMaximized(false);
		boardStage.sizeToScene();
		boardStage.centerOnScreen();
		boardStage.requestFocus();
	}
	
	public void showHoldings()
	{
		if(holdingsStage.isShowing())
		{
			holdingsStage.requestFocus();
		}
		else
		{	
			ScrollPane holdingsScrollPane = new ScrollPane();
			holdingsScrollPane.fitToWidthProperty().set(true);
			holdingsScrollPane.fitToHeightProperty().set(true);
			holdingsScrollPane.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
			holdingsScrollPane.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
			holdingsScrollPane.setPadding(new Insets(0));
			holdingsScrollPane.setContent(holdingsDisplay);
			StackPane holdingsPane = new StackPane(holdingsScrollPane);
			Scene holdingsScene = new Scene(holdingsPane);
			
			holdingsStage = new Stage();
			holdingsStage.setScene(holdingsScene);
			
			holdingsPane.setMaxWidth(screenWidth);
			holdingsPane.setMaxHeight(screenHeight);
			
			holdingsStage.sizeToScene();
			holdingsStage.setTitle("Holdings");
			holdingsStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			holdingsStage.show();
		}
	}
	
	public void createHoldings() {
		holdingsDisplay = new GridPane();
		
		Label holdingsHeaderLabel1 = new Label(" ID ");
		StackPane holdingsHeader1 = new StackPane(holdingsHeaderLabel1);
		holdingsHeader1.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		
		Label holdingsHeaderLabel2 = new Label(" White ");
		StackPane holdingsHeader2 = new StackPane(holdingsHeaderLabel2);
		holdingsHeader2.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		
		Label holdingsHeaderLabel3 = new Label(" # ");
		StackPane holdingsHeader3 = new StackPane(holdingsHeaderLabel3);
		holdingsHeader3.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		
		Label holdingsHeaderLabel4 = new Label(" Black ");
		StackPane holdingsHeader4 = new StackPane(holdingsHeaderLabel4);
		holdingsHeader4.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		
		Label holdingsHeaderLabel5 = new Label(" # ");
		StackPane holdingsHeader5 = new StackPane(holdingsHeaderLabel5);
		holdingsHeader5.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		
		Label holdingsHeaderLabel6 = new Label(" Name ");
		StackPane holdingsHeader6 = new StackPane(holdingsHeaderLabel6);
		holdingsHeader6.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		
		Label holdingsHeaderLabel7 = new Label(" XBetza Move ");
		StackPane holdingsHeader7 = new StackPane(holdingsHeaderLabel7);
		holdingsHeader7.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		
		holdingsDisplay.add(holdingsHeader1, 0, 0);
		holdingsDisplay.add(holdingsHeader2, 1, 0);
		holdingsDisplay.add(holdingsHeader3, 2, 0);
		holdingsDisplay.add(holdingsHeader4, 3, 0);
		holdingsDisplay.add(holdingsHeader5, 4, 0);
		holdingsDisplay.add(holdingsHeader6, 5, 0);
		holdingsDisplay.add(holdingsHeader7, 6, 0);
		
		for(int i = 1; i <= board.getNPieceTypes(); ++i)
		{
			StringBuffer ID = new StringBuffer(pieceList.getPiece(i).getPieceID());
			
			ImageView wPieceImage = pieceList.getPieceImage(i);
			ImageView bPieceImage = pieceList.getPieceImage(i + board.getNPieceTypes());
			
			Label pieceIDLabel = new Label(ID.toString());
			StackPane pieceID = new StackPane(pieceIDLabel);
			pieceID.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			
			StackPane wPiece = new StackPane(wPieceImage);
			wPiece.setMinSize(squareSize, squareSize);
			wPiece.setPrefSize(squareSize, squareSize);
			wPiece.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			wPiece.setId(i + ",-1");
			wPiece.addEventHandler(MouseEvent.MOUSE_CLICKED, selectHandEvent);
			
			Label wHandLabel = new Label(Integer.toString(board.getNPiecesInHand(i)));
			StackPane wHand = new StackPane(wHandLabel);
			wHand.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			
			StackPane bPiece = new StackPane(bPieceImage);
			bPiece.setMinSize(squareSize, squareSize);
			bPiece.setPrefSize(squareSize, squareSize);
			bPiece.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			bPiece.setId((i + board.getNPieceTypes()) + ",-1");
			bPiece.addEventHandler(MouseEvent.MOUSE_CLICKED, selectHandEvent);
			
			Label bHandLabel = new Label(Integer.toString(board.getNPiecesInHand(i + board.getNPieceTypes())));
			StackPane bHand = new StackPane(bHandLabel);
			bHand.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			
			Label pieceNameLabel = new Label(pieceList.getPiece(i).getPieceName());
			StackPane pieceName = new StackPane(pieceNameLabel);
			pieceName.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			
			Label pieceMoveLabel = new Label(pieceList.getPiece(i).getPieceBetza());
			StackPane pieceMove = new StackPane(pieceMoveLabel);
			pieceMove.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			
			holdingsDisplay.add(pieceID, 0, i);
			holdingsDisplay.add(wPiece, 1, i);
			holdingsDisplay.add(wHand, 2, i);
			holdingsDisplay.add(bPiece, 3, i);
			holdingsDisplay.add(bHand, 4, i);
			holdingsDisplay.add(pieceName, 5, i);
			holdingsDisplay.add(pieceMove, 6, i);
		}
		
		holdingsDisplay.setPadding(new Insets(0));
		holdingsDisplay.setHgap(0);
		holdingsDisplay.setVgap(0);
	}

	public void showColorsDialog() {
		if(colorsStage.isShowing())
		{
			colorsStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Enter the desired colors for the board squares (Format: #RRGGBB)");
			instructionsLabel.setStyle("-fx-text-alignment:center;");

			Label lightShadeLabel = new Label("Light Squares");
			TextField newLightShade = new TextField(lightShade.toString());
			newLightShade.setPromptText("#RRGGBB");
			Button previewLightShade = new Button("Preview");
			Button resetLightShade = new Button("Reset");
			Rectangle lightShadePreview = new Rectangle();
			lightShadePreview.setWidth(40);
			lightShadePreview.setHeight(20);
			lightShadePreview.setFill(Color.web(lightShade.toString()));
			lightShadePreview.setStroke(Color.web("#000000"));
			lightShadePreview.setStrokeWidth(2);
			HBox lightShadeHBox = new HBox(newLightShade, previewLightShade, resetLightShade, lightShadePreview);
			lightShadeHBox.setSpacing(10);
			previewLightShade.setOnAction(lse -> {
				if (checkColorFormat(newLightShade.getText())) {
					lightShadePreview.setFill(Color.web(newLightShade.getText()));
				}
			});
			resetLightShade.setOnAction(lse -> {
				if (checkColorFormat(defaultLightShade.toString())) {
					lightShadePreview.setFill(Color.web(defaultLightShade.toString()));
					newLightShade.setText(defaultLightShade.toString());
				} else {
					lightShadePreview.setFill(Color.web("#FFCC9C"));
					newLightShade.setText("#FFCC9C");
				}
			});

			Label darkShadeLabel = new Label("Dark Squares");
			TextField newDarkShade = new TextField(darkShade.toString());
			newDarkShade.setPromptText("#RRGGBB");
			Button setDarkShade = new Button("Preview");
			Button resetDarkShade = new Button("Reset");
			Rectangle darkShadePreview = new Rectangle();
			darkShadePreview.setWidth(40);
			darkShadePreview.setHeight(20);
			darkShadePreview.setFill(Color.web(darkShade.toString()));
			darkShadePreview.setStroke(Color.web("#000000"));
			darkShadePreview.setStrokeWidth(2);
			HBox darkShadeHBox = new HBox(newDarkShade, setDarkShade, resetDarkShade, darkShadePreview);
			darkShadeHBox.setSpacing(10);
			setDarkShade.setOnAction(dse -> {
				if (checkColorFormat(newDarkShade.getText())) {
					darkShadePreview.setFill(Color.web(newDarkShade.getText()));
				}
			});
			resetDarkShade.setOnAction(dse -> {
				if (checkColorFormat(defaultDarkShade.toString())) {
					darkShadePreview.setFill(Color.web(defaultDarkShade.toString()));
					newDarkShade.setText(defaultDarkShade.toString());
				} else {
					darkShadePreview.setFill(Color.web("#CF8948"));
					newDarkShade.setText("#CF8948");
				}
			});
			
			Label holeColorLabel = new Label("Holes");
			TextField newHoleColor = new TextField(holeColor.toString());
			newHoleColor.setPromptText("#RRGGBB");
			Button setHoleColor = new Button("Preview");
			Button resetHoleColor = new Button("Reset");
			Rectangle holeColorPreview = new Rectangle();
			holeColorPreview.setWidth(40);
			holeColorPreview.setHeight(20);
			holeColorPreview.setFill(Color.web(holeColor.toString()));
			holeColorPreview.setStroke(Color.web("#000000"));
			holeColorPreview.setStrokeWidth(2);
			HBox holeColorHBox = new HBox(newHoleColor, setHoleColor, resetHoleColor, holeColorPreview);
			holeColorHBox.setSpacing(10);
			setHoleColor.setOnAction(dse -> {
				if (checkColorFormat(newHoleColor.getText())) {
					holeColorPreview.setFill(Color.web(newHoleColor.getText()));
				}
			});
			resetHoleColor.setOnAction(dse -> {
				if (checkColorFormat(defaultHoleColor.toString())) {
					holeColorPreview.setFill(Color.web(defaultHoleColor.toString()));
					newHoleColor.setText(defaultHoleColor.toString());
				} else {
					holeColorPreview.setFill(Color.web("#000000"));
					newHoleColor.setText("#000000");
				}
			});
			
			Label holeBorderColorLabel = new Label("Hole Borders");
			TextField newHoleBorderColor = new TextField(holeBorderColor.toString());
			newHoleBorderColor.setPromptText("#RRGGBB");
			Button setHoleBorderColor = new Button("Preview");
			Button resetHoleBorderColor = new Button("Reset");
			Rectangle holeBorderColorPreview = new Rectangle();
			holeBorderColorPreview.setWidth(40);
			holeBorderColorPreview.setHeight(20);
			holeBorderColorPreview.setFill(Color.web(holeBorderColor.toString()));
			holeBorderColorPreview.setStroke(Color.web("#000000"));
			holeBorderColorPreview.setStrokeWidth(2);
			HBox holeBorderColorHBox = new HBox(newHoleBorderColor, setHoleBorderColor, resetHoleBorderColor, holeBorderColorPreview);
			holeBorderColorHBox.setSpacing(10);
			setHoleBorderColor.setOnAction(dse -> {
				if (checkColorFormat(newHoleColor.getText())) {
					holeBorderColorPreview.setFill(Color.web(newHoleBorderColor.getText()));
				}
			});
			resetHoleBorderColor.setOnAction(dse -> {
				if (checkColorFormat(defaultHoleColor.toString())) {
					holeBorderColorPreview.setFill(Color.web(defaultHoleColor.toString()));
					newHoleBorderColor.setText(defaultHoleColor.toString());
				} else {
					holeColorPreview.setFill(Color.web("#000000"));
					newHoleBorderColor.setText("#000000");
				}
			});

			Button applyColors = new Button("Apply");
			Button restoreDefaultColors = new Button("Restore Defaults");

			HBox buttonHBox = new HBox(applyColors, restoreDefaultColors);
			buttonHBox.setAlignment(Pos.CENTER_RIGHT);
			buttonHBox.setSpacing(10);
			VBox colorsVBox = new VBox(instructionsLabel, lightShadeLabel, lightShadeHBox, darkShadeLabel, darkShadeHBox, holeColorLabel, holeColorHBox, holeBorderColorLabel, holeBorderColorHBox, buttonHBox);
			colorsVBox.setSpacing(10);
			colorsVBox.setPadding(new Insets(10));
			Scene colorsScene = new Scene(colorsVBox);
			applyColors.requestFocus();

			applyColors.setOnAction(ae -> {
				boolean hasValidColor = false;
				if (checkColorFormat(newLightShade.getText())) {
					lightShade = new StringBuffer(newLightShade.getText());
					hasValidColor = true;
				}
				if (checkColorFormat(newDarkShade.getText())) {
					darkShade = new StringBuffer(newDarkShade.getText());
					hasValidColor = true;
				}
				if (checkColorFormat(newHoleColor.getText())) {
					holeColor = new StringBuffer(newHoleColor.getText());
					hasValidColor = true;
				}
				if (checkColorFormat(newHoleBorderColor.getText())) {
					holeBorderColor = new StringBuffer(newHoleBorderColor.getText());
					hasValidColor = true;
				}
				if (hasValidColor) {
					Display(true);
					boardStage.requestFocus();
					colorsStage.close();
				}
			});
			restoreDefaultColors.setOnAction(rde -> {
				if (checkColorFormat(defaultLightShade.toString())) {
					lightShade = new StringBuffer(defaultLightShade.toString());
				} else {
					lightShade = new StringBuffer("#FFCC9C");
				}
				if (checkColorFormat(defaultDarkShade.toString())) {
					darkShade = new StringBuffer(defaultDarkShade.toString());
				} else {
					darkShade = new StringBuffer("#CF8948");
				}
				if (checkColorFormat(defaultHoleColor.toString())) {
					holeColor = new StringBuffer(defaultHoleColor.toString());
				} else {
					holeColor = new StringBuffer("#000000");
				}
				if (checkColorFormat(defaultHoleBorderColor.toString())) {
					holeBorderColor = new StringBuffer(defaultHoleBorderColor.toString());
				} else {
					holeBorderColor = new StringBuffer("#FFFFFF");
				}
				Display(true);
				boardStage.requestFocus();
				colorsStage.close();
			});

			colorsStage.setScene(colorsScene);
			colorsStage.setTitle("Board Colors");
			colorsStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			colorsStage.show();
		}
	}
	
	public void showHighlightsDialog() {
		if(highlightsStage.isShowing())
		{
			highlightsStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Enter the desired colors for the board highlights (Format: #RRGGBB)");
			instructionsLabel.setStyle("-fx-text-alignment:center;");

			Label selectedPieceLabel = new Label("Selected piece");
			TextField newSelectedPieceColor = new TextField(selectedPieceColor.toString());
			newSelectedPieceColor.setPromptText("#RRGGBB");
			Button previewSelectedPieceColor = new Button("Preview");
			Button resetSelectedPieceColor = new Button("Reset");
			Rectangle selectedPieceColorPreview = new Rectangle();
			selectedPieceColorPreview.setWidth(40);
			selectedPieceColorPreview.setHeight(20);
			selectedPieceColorPreview.setFill(Color.web(selectedPieceColor.toString()));
			selectedPieceColorPreview.setStroke(Color.web("#000000"));
			selectedPieceColorPreview.setStrokeWidth(2);
			HBox selectedPieceColorHBox = new HBox(newSelectedPieceColor, previewSelectedPieceColor, resetSelectedPieceColor, selectedPieceColorPreview);
			selectedPieceColorHBox.setSpacing(10);
			previewSelectedPieceColor.setOnAction(spce -> {
				if (checkColorFormat(newSelectedPieceColor.getText())) {
					selectedPieceColorPreview.setFill(Color.web(newSelectedPieceColor.getText()));
				}
			});
			resetSelectedPieceColor.setOnAction(rspce -> {
				if (checkColorFormat(defaultSelectedPieceColor.toString())) {
					selectedPieceColorPreview.setFill(Color.web(defaultSelectedPieceColor.toString()));
					newSelectedPieceColor.setText(defaultSelectedPieceColor.toString());
				} else {
					selectedPieceColorPreview.setFill(Color.web("#80FF80"));
					newSelectedPieceColor.setText("#80FF80");
				}
			});
			
			Label lastMoveLabel = new Label("Last move (origin and destination squares)");
			TextField newLastMoveColor = new TextField(lastMoveColor.toString());
			newLastMoveColor.setPromptText("#RRGGBB");
			Button previewLastMoveColor = new Button("Preview");
			Button resetLastMoveColor = new Button("Reset");
			Rectangle lastMoveColorPreview = new Rectangle();
			lastMoveColorPreview.setWidth(40);
			lastMoveColorPreview.setHeight(20);
			lastMoveColorPreview.setFill(Color.web(lastMoveColor.toString()));
			lastMoveColorPreview.setStroke(Color.web("#000000"));
			lastMoveColorPreview.setStrokeWidth(2);
			HBox lastMoveColorHBox = new HBox(newLastMoveColor, previewLastMoveColor, resetLastMoveColor, lastMoveColorPreview);
			lastMoveColorHBox.setSpacing(10);
			previewLastMoveColor.setOnAction(slmce -> {
				if (checkColorFormat(newLastMoveColor.getText())) {
					lastMoveColorPreview.setFill(Color.web(newLastMoveColor.getText()));
				}
			});
			resetLastMoveColor.setOnAction(rlmce -> {
				if (checkColorFormat(defaultLastMoveColor.toString())) {
					lastMoveColorPreview.setFill(Color.web(defaultLastMoveColor.toString()));
					newLastMoveColor.setText(defaultLastMoveColor.toString());
				} else {
					lastMoveColorPreview.setFill(Color.web("#00FF00"));
					newLastMoveColor.setText("#00FF00");
				}
			});

			Label lastLocustCaptureLabel = new Label("Last locust capture (intermediate square(s))");
			TextField newLastLocustCaptureColor = new TextField(lastLocustCaptureColor.toString());
			newLastLocustCaptureColor.setPromptText("#RRGGBB");
			Button previewLastLocustCaptureColor = new Button("Preview");
			Button resetLastLocustCaptureColor = new Button("Reset");
			Rectangle lastLocustCaptureColorPreview = new Rectangle();
			lastLocustCaptureColorPreview.setWidth(40);
			lastLocustCaptureColorPreview.setHeight(20);
			lastLocustCaptureColorPreview.setFill(Color.web(lastLocustCaptureColor.toString()));
			lastLocustCaptureColorPreview.setStroke(Color.web("#000000"));
			lastLocustCaptureColorPreview.setStrokeWidth(2);
			HBox lastLocustCaptureColorHBox = new HBox(newLastLocustCaptureColor, previewLastLocustCaptureColor, resetLastLocustCaptureColor, lastLocustCaptureColorPreview);
			lastLocustCaptureColorHBox.setSpacing(10);
			previewLastLocustCaptureColor.setOnAction(llcce -> {
				if(checkColorFormat(newLastLocustCaptureColor.getText())) {
					lastLocustCaptureColorPreview.setFill(Color.web(newLastLocustCaptureColor.getText()));
				}
			});
			resetLastLocustCaptureColor.setOnAction(rllcce -> {
				if (checkColorFormat(defaultLastLocustCaptureColor.toString())) {
					lastLocustCaptureColorPreview.setFill(Color.web(defaultLastLocustCaptureColor.toString()));
					newLastLocustCaptureColor.setText(defaultLastLocustCaptureColor.toString());
				} else {
					lastLocustCaptureColorPreview.setFill(Color.web("#FFF000"));
					newLastLocustCaptureColor.setText("#FFF000");
				}
			});

			Label moveLabel = new Label("Move to empty square");
			TextField newMoveColor = new TextField(moveColor.toString());
			newMoveColor.setPromptText("#RRGGBB");
			Button previewMoveColor = new Button("Preview");
			Button resetMoveColor = new Button("Reset");
			Rectangle moveColorPreview = new Rectangle();
			moveColorPreview.setWidth(40);
			moveColorPreview.setHeight(20);
			moveColorPreview.setFill(Color.web(moveColor.toString()));
			moveColorPreview.setStroke(Color.web("#000000"));
			moveColorPreview.setStrokeWidth(2);
			HBox moveColorHBox = new HBox(newMoveColor, previewMoveColor, resetMoveColor, moveColorPreview);
			moveColorHBox.setSpacing(10);
			previewMoveColor.setOnAction(mce -> {
				if(checkColorFormat(newMoveColor.getText())) {
					moveColorPreview.setFill(Color.web(newMoveColor.getText()));
				}
			});
			resetMoveColor.setOnAction(rmce -> {
				if (checkColorFormat(defaultMoveColor.toString())) {
					moveColorPreview.setFill(Color.web(defaultMoveColor.toString()));
					newMoveColor.setText(defaultMoveColor.toString());
				} else {
					moveColorPreview.setFill(Color.web("#FFFF00"));
					newMoveColor.setText("#FFFF00");
				}
			});

			Label captureLabel = new Label("Capture of enemy piece");
			TextField newCaptureColor = new TextField(captureColor.toString());
			newCaptureColor.setPromptText("#RRGGBB");
			Button previewCaptureColor = new Button("Preview");
			Button resetCaptureColor = new Button("Reset");
			Rectangle captureColorPreview = new Rectangle();
			captureColorPreview.setWidth(40);
			captureColorPreview.setHeight(20);
			captureColorPreview.setFill(Color.web(captureColor.toString()));
			captureColorPreview.setStroke(Color.web("#000000"));
			captureColorPreview.setStrokeWidth(2);
			HBox captureColorHBox = new HBox(newCaptureColor, previewCaptureColor, resetCaptureColor, captureColorPreview);
			captureColorHBox.setSpacing(10);
			previewCaptureColor.setOnAction(ce -> {
				if(checkColorFormat(newMoveColor.getText())) {
					captureColorPreview.setFill(Color.web(newCaptureColor.getText()));
				}
			});
			resetCaptureColor.setOnAction(rce -> {
				if (checkColorFormat(defaultCaptureColor.toString().toString())) {
					captureColorPreview.setFill(Color.web(defaultCaptureColor.toString()));
					newCaptureColor.setText(defaultCaptureColor.toString());
				} else {
					captureColorPreview.setFill(Color.web("#FF0000"));
					newCaptureColor.setText("#FF0000");
				}
			});
			
			Label destroyLabel = new Label("Capture of friendly piece");
			TextField newDestroyColor = new TextField(destroyColor.toString());
			newDestroyColor.setPromptText("#RRGGBB");
			Button previewDestroyColor = new Button("Preview");
			Button resetDestroyColor = new Button("Reset");
			Rectangle destroyColorPreview = new Rectangle();
			destroyColorPreview.setWidth(40);
			destroyColorPreview.setHeight(20);
			destroyColorPreview.setFill(Color.web(destroyColor.toString()));
			destroyColorPreview.setStroke(Color.web("#000000"));
			destroyColorPreview.setStrokeWidth(2);
			HBox destroyColorHBox = new HBox(newDestroyColor, previewDestroyColor, resetDestroyColor, destroyColorPreview);
			destroyColorHBox.setSpacing(10);
			previewDestroyColor.setOnAction(dce -> {
				if(checkColorFormat(newDestroyColor.getText())) {
					destroyColorPreview.setFill(Color.web(newDestroyColor.getText()));
				}
			});
			resetDestroyColor.setOnAction(rdce -> {
				if (checkColorFormat(defaultDestroyColor.toString())) {
					destroyColorPreview.setFill(Color.web(defaultDestroyColor.toString()));
					newDestroyColor.setText(defaultDestroyColor.toString());
				} else {
					destroyColorPreview.setFill(Color.web("#0000FF"));
					newDestroyColor.setText("#0000FF");
				}
			});

			Label locustCaptureLabel = new Label("Locust capture (capture and move again)");
			TextField newLocustCaptureColor = new TextField(locustCaptureColor.toString());
			newLocustCaptureColor.setPromptText("#RRGGBB");
			Button previewLocustCaptureColor = new Button("Preview");
			Button resetLocustCaptureColor = new Button("Reset");
			Rectangle locustCaptureColorPreview = new Rectangle();
			locustCaptureColorPreview.setWidth(40);
			locustCaptureColorPreview.setHeight(20);
			locustCaptureColorPreview.setFill(Color.web(locustCaptureColor.toString()));
			locustCaptureColorPreview.setStroke(Color.web("#000000"));
			locustCaptureColorPreview.setStrokeWidth(2);
			HBox locustCaptureColorHBox = new HBox(newLocustCaptureColor, previewLocustCaptureColor, resetLocustCaptureColor, locustCaptureColorPreview);
			locustCaptureColorHBox.setSpacing(10);
			previewLocustCaptureColor.setOnAction(lcce -> {
				if(checkColorFormat(newLocustCaptureColor.getText())) {
					locustCaptureColorPreview.setFill(Color.web(newLocustCaptureColor.getText()));
				}
			});
			resetLocustCaptureColor.setOnAction(rlcce -> {
				if (checkColorFormat(defaultLocustCaptureColor.toString())) {
					locustCaptureColorPreview.setFill(Color.web(defaultLocustCaptureColor.toString()));
					newLocustCaptureColor.setText(defaultLocustCaptureColor.toString());
				} else {
					locustCaptureColorPreview.setFill(Color.web("#00FFFF"));
					newLocustCaptureColor.setText("#00FFFF");
				}
			});
			
			Button applyHighlights = new Button("Apply");
			Button restoreDefaultHighlights = new Button("Restore Defaults");

			HBox buttonHBox = new HBox(applyHighlights, restoreDefaultHighlights);
			buttonHBox.setAlignment(Pos.CENTER_RIGHT);
			buttonHBox.setSpacing(10);
			VBox highlightsVBox = new VBox(instructionsLabel, selectedPieceLabel, selectedPieceColorHBox, lastMoveLabel, lastMoveColorHBox, lastLocustCaptureLabel, lastLocustCaptureColorHBox, moveLabel, moveColorHBox, captureLabel, captureColorHBox, destroyLabel, destroyColorHBox, locustCaptureLabel, locustCaptureColorHBox, buttonHBox);
			highlightsVBox.setSpacing(10);
			highlightsVBox.setPadding(new Insets(10));
			Scene colorsScene = new Scene(highlightsVBox);
			applyHighlights.requestFocus();

			applyHighlights.setOnAction(ahe -> {
				boolean hasValidColor = false;
				if(checkColorFormat(newSelectedPieceColor.getText())) {
					selectedPieceColor = new StringBuffer(newSelectedPieceColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newLastMoveColor.getText())) {
					lastMoveColor = new StringBuffer(newLastMoveColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newLastLocustCaptureColor.getText())) {
					lastLocustCaptureColor = new StringBuffer(newLastLocustCaptureColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newMoveColor.getText())) {
					moveColor = new StringBuffer(newMoveColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newCaptureColor.getText())) {
					captureColor = new StringBuffer(newCaptureColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newDestroyColor.getText())) {
					destroyColor = new StringBuffer(newDestroyColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newLocustCaptureColor.getText())) {
					locustCaptureColor = new StringBuffer(newLocustCaptureColor.getText());
					hasValidColor = true;
				}

				if (hasValidColor) {
					Display(true);
					BoardPosition position = board.getGame().get(board.getDisplayed());
					updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
					boardStage.requestFocus();
					highlightsStage.close();
				}
			});
			restoreDefaultHighlights.setOnAction(rde -> {
				if (checkColorFormat(defaultSelectedPieceColor.toString())) {
					selectedPieceColor = new StringBuffer(defaultSelectedPieceColor.toString());
				} else {
					selectedPieceColor = new StringBuffer("#80FF80");
				}
				if (checkColorFormat(defaultLastMoveColor.toString())) {
					lastMoveColor = new StringBuffer(defaultLastMoveColor.toString());
				} else {
					lastMoveColor = new StringBuffer("#00FF00");
				}
				if (checkColorFormat(defaultLastLocustCaptureColor.toString())) {
					lastLocustCaptureColor = new StringBuffer(defaultLastLocustCaptureColor.toString());
				} else {
					lastLocustCaptureColor = new StringBuffer("#FFF000");
				}
				if (checkColorFormat(defaultMoveColor.toString())) {
					moveColor = new StringBuffer(defaultMoveColor.toString());
				} else {
					moveColor = new StringBuffer("#FFFF00");
				}
				if (checkColorFormat(defaultCaptureColor.toString())) {
					captureColor = new StringBuffer(defaultCaptureColor.toString());
				} else {
					captureColor = new StringBuffer("#FF0000");
				}
				if (checkColorFormat(defaultMoveColor.toString())) {
					destroyColor = new StringBuffer(defaultDestroyColor.toString());
				} else {
					destroyColor = new StringBuffer("#0000FF");
				}
				if (checkColorFormat(defaultMoveColor.toString())) {
					locustCaptureColor = new StringBuffer(defaultLocustCaptureColor.toString());
				} else {
					locustCaptureColor = new StringBuffer("#00FFFF");
				}
				Display(true);
				BoardPosition position = board.getGame().get(board.getDisplayed());
				updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
				boardStage.requestFocus();
				highlightsStage.close();
			});

			highlightsStage.setScene(colorsScene);
			highlightsStage.setTitle("Board Highlights");
			highlightsStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			highlightsStage.show();
		}
	}
	
	public void showKeyBindings()
	{
		if(keyBindingsStage.isShowing())
		{
			keyBindingsStage.requestFocus();
		}
		else
		{
			TextArea keyBindingsText = new TextArea(HelpText.getKeyBindings());
			keyBindingsText.setWrapText(true);
			keyBindingsText.setEditable(false);
			keyBindingsText.setPrefHeight(300);
			keyBindingsText.setPrefColumnCount(40);
			
			Scene aboutScene = new Scene(keyBindingsText);
			aboutStage = new Stage();
			aboutStage.setScene(aboutScene);
			aboutStage.sizeToScene();
			aboutStage.setTitle("Help - Key Bindings");
			aboutStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			aboutStage.show();
		}
	}
	
	public void showAboutDialog()
	{
		if(aboutStage.isShowing())
		{
			aboutStage.requestFocus();
		}
		else
		{
			TextArea aboutText = new TextArea(About.getAboutText());
			aboutText.setWrapText(true);
			aboutText.setEditable(false);
			aboutText.setPrefHeight(300);
			aboutText.setPrefColumnCount(40);
			
			Scene aboutScene = new Scene(aboutText);
			aboutStage = new Stage();
			aboutStage.setScene(aboutScene);
			aboutStage.sizeToScene();
			aboutStage.setTitle("About");
			aboutStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			aboutStage.show();
		}
	}
	
	public void showLicenseDialog()
	{
		if(licenseStage.isShowing())
		{
			licenseStage.requestFocus();
		}
		else
		{
			TextArea licenseText = new TextArea(GPL3.getLicense());
			licenseText.setWrapText(true);
			licenseText.setEditable(false);
			licenseText.setPrefHeight(300);
			licenseText.setPrefColumnCount(40);
			
			Scene licenseScene = new Scene(licenseText);
			licenseStage = new Stage();
			licenseStage.setScene(licenseScene);
			licenseStage.sizeToScene();
			licenseStage.setTitle("GNU General Public License v3.0");
			licenseStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			licenseStage.show();
		}
	}
	
	public void showPieceCreditsDialog()
	{
		if(pieceCreditsStage.isShowing())
		{
			pieceCreditsStage.requestFocus();
		}
		else
		{
			TextArea pieceCreditsText = new TextArea(PieceSetCredits.getPieceSetCredits());
			pieceCreditsText.setWrapText(true);
			pieceCreditsText.setEditable(false);
			pieceCreditsText.setPrefHeight(300);
			pieceCreditsText.setPrefColumnCount(40);
			
			Scene pieceCreditsScene = new Scene(pieceCreditsText);
			pieceCreditsStage = new Stage();
			pieceCreditsStage.setScene(pieceCreditsScene);
			pieceCreditsStage.sizeToScene();
			pieceCreditsStage.setTitle("Piece Set Credits");
			pieceCreditsStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			pieceCreditsStage.show();
		}
	}
	
	public void showModsDialog()
	{
		if(modificationsStage.isShowing())
		{
			modificationsStage.requestFocus();
		}
		else
		{
			TextArea modificationsText = new TextArea(Modifications.getModificationsText());
			modificationsText.setWrapText(true);
			modificationsText.setEditable(false);
			modificationsText.setPrefHeight(300);
			modificationsText.setPrefColumnCount(40);
			
			Scene modificationsScene = new Scene(modificationsText);
			modificationsStage = new Stage();
			modificationsStage.setScene(modificationsScene);
			modificationsStage.sizeToScene();
			modificationsStage.setTitle("3rd-Party Modifications");
			modificationsStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			modificationsStage.show();
		}
	}
	
	public void showMoveHistory()
	{
		if(moveHistoryStage.isShowing())
		{
			moveHistoryStage.requestFocus();
		}
		else
		{
			moveHistory = new TextArea(getGameMoves());
			moveHistory.setWrapText(true);
			moveHistory.setEditable(false);
			moveHistory.setPrefHeight(300);
			moveHistory.setPrefColumnCount(40);
			
			Scene moveHistoryScene = new Scene(moveHistory);
			moveHistoryStage = new Stage();
			moveHistoryStage.setScene(moveHistoryScene);
			moveHistoryStage.sizeToScene();
			moveHistoryStage.setTitle("Move History");
			moveHistoryStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
			moveHistoryStage.show();
		}
	}
	
	
	
	public void goToBeginning()
	{
		if(disableBoardEvents == true)
		{
			return;
		}
		ResetEvents(true);
		board.Seek(0);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void goOneBack()
	{
		if(disableBoardEvents == true)
		{
			return;
		}
		ResetEvents(true);
		board.Seek(1);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void goOneForward()
	{
		if(disableBoardEvents == true)
		{
			return;
		}
		ResetEvents(true);
		board.Seek(2);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void goToEnd()
	{
		if(disableBoardEvents == true)
		{
			return;
		}
		ResetEvents(true);
		board.Seek(3);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void undoMove()
	{
		if(!disableBoardEvents && (board.getGame().size() - 1) >= 1)
		{
			ResetEvents(true);
			board.getGame().remove(board.getGame().size() - 1);
			board.Seek(3);
			BoardPosition position = board.getGame().get(board.getDisplayed());
			updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
			Display(false);
		}
	}
	
	/**
	 * Closes excess open dialogs.</br>
	 * Should be called whenever the dialog opened has</br>
	 * the potential to change board statistics</br>
	 * and used on all dialogs with the potential to</br>
	 * change board statistics.
	 */
	public void closeExcessDialogs()
	{
		gamePresetsStage.close(); // dialog for changing game preset
		fenCodeStage.close(); // dialog for changing board position with FEN Code
		fenCodeRequirementsStage.close();
		gameMovesStage.close();
		//gameMoveRequirementsStage.close();
		colorsStage.close(); // dialog for changing square colors
		highlightsStage.close(); // dialog for changing square colors
	}
	
	// Events and Event Methods for moving pieces
	
	// Select Piece
	private EventHandler<MouseEvent> selectPieceEvent = spe -> {
		if(disableBoardEvents)
		{
			spe.consume();
		}
		else if(!board.isCurrentPosition())
		{
			spe.consume();
		}
		else if(pieceSelected == false)
		{	
			StackPane selectedPiece = (StackPane)spe.getSource(); // get board square
			String[] selectedPieceCoords = selectedPiece.getId().split(","); // get square ID
			int selectedPieceX = Integer.parseInt(selectedPieceCoords[0]); // update origin coords for moving piece
			int selectedPieceY = Integer.parseInt(selectedPieceCoords[1]);
			
			selectPiece(selectedPieceX, selectedPieceY);
		}
	};
	
	// Select Piece in Hand
	private EventHandler<MouseEvent> selectHandEvent = she -> {
		if(disableBoardEvents)
		{
			she.consume();
		}
		else if(board.getEnableDrops() == false)
		{
			she.consume();
		}
		else if(!board.isCurrentPosition())
		{
			she.consume();
		}
		else if(pieceSelected == false)
		{	
			StackPane selectedPiece = (StackPane)she.getSource(); // get board square
			String[] selectedPieceCoords = selectedPiece.getId().split(","); // get square ID
			int selectedPieceInHand = Integer.parseInt(selectedPieceCoords[0]); // update origin coords for moving piece
			
			if(board.getNPiecesInHand(selectedPieceInHand) > 0)
			{
				selectHand(selectedPieceInHand, true);
			}
		}
	};
	
	// Deselect Piece
	private EventHandler<MouseEvent> deselectPieceEvent = dpe -> {
		if(disableBoardEvents)
		{
			dpe.consume();
		}
		else if(!board.isCurrentPosition())
		{
			dpe.consume();
		}
		else
		{
			deselectPiece();
		}
	};
	
	// Deselect Piece in Hand
	private EventHandler<MouseEvent> deselectHandEvent = dhe -> {
		if(disableBoardEvents)
		{
			dhe.consume();
		}
		else if(!board.isCurrentPosition())
		{
			dhe.consume();
		}
		else
		{
			deselectHand();
		}
	};
	
	// Move Piece
	private EventHandler<MouseEvent> movePieceEvent = mpe -> {
		if(disableBoardEvents)
		{
			mpe.consume();
		}
		else if(!board.isCurrentPosition())
		{
			mpe.consume();
		}
		else if(mpe.isControlDown() && !(originX >= 1 && originX <= board.getMaxPieces() && originY == -1))
		{
			StackPane selectedPiece = (StackPane)mpe.getSource();
			String[] selectedPieceCoords = selectedPiece.getId().split(",");
			int epx = Integer.parseInt(selectedPieceCoords[0]);
			int epy = Integer.parseInt(selectedPieceCoords[1]);
			if(board.getPieceOnSquare(epx, epy) == -1)
			{
				mpe.consume();
			}
			else if(epx == lastEX && epy == lastEY)
			{
				mpe.consume();
			}
			else
			{
				ex.add(epx);
				ey.add(epy);
				lastEX = epx;
				lastEY = epy;
				updateSelectedLocustSquares();
				prepareLocustEvents();
			}
		}
		else
		{
			boolean cancelMove = false;
			StackPane selectedPiece = (StackPane)mpe.getSource();
			String[] selectedPieceCoords = selectedPiece.getId().split(",");
			destX = Integer.parseInt(selectedPieceCoords[0]);
			destY = Integer.parseInt(selectedPieceCoords[1]);
			if(destX == originX && destY == originY)
			{
				boolean intermediateCapture = false;
				for(int i = 0; i < Math.min(ex.size(),ey.size()); ++i)
				{
					if(board.getPieceOnSquare(ex.get(i), ey.get(i)) > 0 && (originX != ex.get(i) || originY != ey.get(i)))
					{
						intermediateCapture = true;
					}
				}
				if(!intermediateCapture)
				{
					disableBoardEvents = true;
					int commitMove = showConfirmDialog("Confirm Null Move", "Do you want to commit a null move?\n(Pressing No deselects the piece)");
					disableBoardEvents = false;
					if(commitMove == -1)
					{
						destX = -1;
						destY = -1;
						return;
					}
					if(commitMove == 0)
					{
						deselectPiece();
						updateSelectedLocustSquares();
						updateLastMoveSquares(originX, originY, ex, ey, destX, destY);
						cancelMove = true;
					}
				}
			}
			if(cancelMove == false)
			{
				promotion = -1;
				cancelMove = Promote();
			}
			if(cancelMove == false)
			{
				board.Move(originX, originY, ex, ey, destX, destY, promotion);
				updateLastMoveSquares(originX, originY, ex, ey, destX, destY);
				if(originX >= 1 && originX <= board.getMaxPieces() && originY == -1)
				{
					deselectHand();
				}
				else
				{
					deselectPiece();
				}
			}
			else
			{
				if(originX >= 1 && originX <= board.getMaxPieces() && originY == -1)
				{
					deselectHand();
				}
				else
				{
					deselectPiece();
				}
			}
			Display(false);
		}
	};
	
	public void prepareLocustEvents()
	{
		manageBoardSquareEvents(getBoardSquare(originX, originY), MouseEvent.MOUSE_CLICKED, deselectPieceEvent, true);
		manageBoardSquareEvents(getBoardSquare(originX, originY), MouseEvent.MOUSE_CLICKED, movePieceEvent, false);
	}
	
	public void selectPiece(int x, int y)
	{
		if(x < 0 || x > nFiles || y < 0 || y > nRanks)
		{
			return;
		}
		originX = x;
		originY = y;
		Display(true);
		StackPane pieceSquare = getBoardSquare(x, y);
		updateSelectedPieceEvents(pieceSquare, false);
		updateMovePieceEvents(false);
		pieceSelected = true;
	}
	
	public void selectHand(int piece, boolean updateDisplay)
	{
		if(piece < 1 || piece > board.getMaxPieces())
		{
			return;
		}
		originX = piece;
		originY = -1;
		if(updateDisplay)
		{
			Display(true);
		}
		StackPane handSquare = getHandImage(piece);
		updateSelectedHandEvents(handSquare, false);
		updateMovePieceEvents(false);
		pieceSelected = true;
	}
	
	public void deselectPiece()
	{
		StackPane pieceSquare = getBoardSquare(originX, originY);
		Display(false);
		originX = -1;
		originY = -1;
		ex.clear();
		ey.clear();
		destX = -1;
		destY = -1;
		promotion = -1;
		lastEX = -1;
		lastEY = -1;
		pieceSelected = false;
		updateSelectedPieceEvents(pieceSquare, true);
		updateMovePieceEvents(true);
	}
	
	public void deselectHand()
	{
		StackPane pieceSquare = getHandImage(originX);
		updateSelectedHandEvents(pieceSquare, true);
		updateMovePieceEvents(true);
		Display(false);
		originX = -1;
		originY = -1;
		ex.clear();
		ey.clear();
		destX = -1;
		destY = -1;
		promotion = -1;
		pieceSelected = false;
	}
	
	public void updateSelectedLocustSquares()
	{
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				if(board.getPieceOnSquare(j, i) != -1)
				{
					getBoardSquare(j, i).setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				}
			}
		}
		int maxIntermediateMoves = Math.min(ex.size(), ey.size());
		if(maxIntermediateMoves > 0)
		{
			for(int i = 0; i < maxIntermediateMoves - 1; ++i)
			{
				getBoardSquare(ex.get(i), ey.get(i)).setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + lastLocustCaptureColor + ";");
			}
			int lastElement = maxIntermediateMoves - 1;
			getBoardSquare(ex.get(lastElement), ey.get(lastElement)).setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + locustCaptureColor + ";");
		}
	}
	
	/**
	 * 
	 * @param x1 x-coordinate of origin square
	 * @param y1 y-coordinate of origin square
	 * @param ex array of x-coordinates for intermediate squares
	 * @param ey array of y-coordinates for intermediate squares
	 * @param x2 x-coordinate of destination square
	 * @param y2 y-coordinate of destination square
	 */
	public void updateLastMoveSquares(int x1, int y1, ArrayList<Integer> ex, ArrayList<Integer> ey, int x2, int y2)
	{
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				if(board.getPieceOnSquare(j, i) != -1)
				{
					getBoardSquare(j, i).setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				}
			}
		}
		
		for(int i = 1; i <= board.getMaxPieces(); ++i)
		{
			getHandImage(i).setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		}
		
		String lastMoveStyleString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + lastMoveColor + ";";
		String lastLocustCaptureStyleString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + lastLocustCaptureColor + ";";
		
		if(x1 < 0 || x1 >= nFiles || y1 < 0 || y1 >= nRanks || x2 < 0 || x2 >= nFiles || y2 < 0 || y2 >= nRanks)
		{
			if(x1 >= 1 && x1 <= board.getMaxPieces() && y1 == -1 && x2 >= 0 && x2 < nFiles && y2 >= 0 && y2 < nRanks)
			{
				getBoardSquare(x2, y2).setStyle(lastMoveStyleString);
				getHandImage(x1).setStyle(lastMoveStyleString);
			}
			return;
		}
		
		if(!ex.isEmpty() && !ey.isEmpty()) // exit early if no intermediate squares
		{
			int maxIntermediateSquares = Math.min(ex.size(), ey.size());
			StackPane intermediateSquare;
			for(int i = 0; i < maxIntermediateSquares; ++i) // exit early if piece on square cannot be moved
			{
				intermediateSquare = getBoardSquare(ex.get(i), ey.get(i));
				intermediateSquare.setStyle(lastLocustCaptureStyleString);
			}
		}
		
		StackPane origin = getBoardSquare(x1, y1);
		origin.setStyle(lastMoveStyleString);
		StackPane dest = getBoardSquare(x2, y2);
		dest.setStyle(lastMoveStyleString);
	}

	public void updateHoleBorders()
	{
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				if(board.getPieceOnSquare(j, i) == -1)
				{
					StackPane boardSquare = getBoardSquare(j, i);
					String holeBorderString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + holeBorderColor + ";";
					boardSquare.setStyle(holeBorderString);
				}
			}
		}
	}
	
	// Methods for controlling board events

	/**
	 * Manages the events of a given board square.
	 * @param square board square to manage events on
	 * @param type event type
	 * @param event event
	 * @param remove whether to remove the event rather than add it
	 */
	public void manageBoardSquareEvents(StackPane square, EventType<MouseEvent> type, EventHandler<MouseEvent> event, boolean remove) {
		if (remove) {
			try
			{
				square.removeEventHandler(type, event);
			}
			catch(NullPointerException npe)
			{
				return;
			}
		} else {
			try
			{
				square.addEventHandler(type, event);
			}
			catch(NullPointerException npe)
			{
				return;
			}
		}
	}

	/**
	 * Updates piece selection events on this square.
	 * @param selectedPiece the board square to update selection events on
	 * @param deselect whether to deselect the piece.
	 */
	private void updateSelectedPieceEvents(StackPane selectedPiece, boolean deselect)
	{
		if(deselect)
		{
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, true);
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, selectPieceEvent, false);
		}
		else
		{
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, selectPieceEvent, true);
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, false);
		}
	}
	
	private void updateSelectedHandEvents(StackPane selectedHand, boolean deselect)
	{
		if(deselect)
		{
			manageBoardSquareEvents(selectedHand, MouseEvent.MOUSE_CLICKED, deselectHandEvent, true);
			manageBoardSquareEvents(selectedHand, MouseEvent.MOUSE_CLICKED, selectHandEvent, false);
		}
		else
		{
			manageBoardSquareEvents(selectedHand, MouseEvent.MOUSE_CLICKED, selectHandEvent, true);
			manageBoardSquareEvents(selectedHand, MouseEvent.MOUSE_CLICKED, deselectHandEvent, false);
		}
	}
	
	public void updateMovePieceEvents(boolean remove)
	{
		int pieceColor;
		if(originX >= 1 && originX <= board.getMaxPieces() && originY == -1)
		{
			pieceColor = board.getPieceColor(originX);
		}
		else
		{
			pieceColor = board.getPieceColor(board.getPieceOnSquare(originX, originY));
		}
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				manageBoardSquareEvents(getBoardSquare(j, i), MouseEvent.MOUSE_CLICKED, movePieceEvent, true);
				if(remove == false && board.getPieceOnSquare(j, i) != -1 && pieceColor != board.getPieceColor(board.getPieceOnSquare(j, i)))
				{
					manageBoardSquareEvents(getBoardSquare(j, i), MouseEvent.MOUSE_CLICKED, movePieceEvent, false);
				}
			}
		}
	}

	/**
	 * Resets the board display to its state when no piece is selected.
	 * @param resetCoords whether to reset the coordinates for moving pieces on the board
	 */
	public void ResetEvents(boolean resetCoords)
	{
		if(resetCoords)
		{
			originX = -1;
			originY = -1;
			ex.clear();
			ey.clear();
			destX = -1;
			destY = -1;
			promotion = -1;
			pieceSelected = false;
		}
		StackPane boardSquare;
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				boardSquare = getBoardSquare(j, i);
				
				manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, selectPieceEvent, true);
				manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, true);
				manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, movePieceEvent, true);

				if(board.getPieceOnSquare(j, i) > 0 && board.getPieceOnSquare(j, i) <= board.getMaxPieces())
				{
					manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, selectPieceEvent, false);
					manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, true);
				}
			}
		}
	}
	
	public boolean confirmShogiPromotion(boolean demote, boolean isDrop)
	{
		preventBoardEventToggling = true;
		boolean cancelMove = false;
		String confirmActionTitle;
		String confirmActionString;
		if(demote == false)
		{
			confirmActionTitle = "Confirm Promotion";
			confirmActionString = "Will you promote this piece?";
		}
		else
		{
			confirmActionTitle = "Confirm Demotion";
			confirmActionString = "Will you demote this piece?";
		}
		int promotionOption = showConfirmDialog(confirmActionTitle, confirmActionString);
		
		if(promotionOption == -1)
		{
			cancelMove = true;
		}
		else if(promotionOption == 1)
		{
			if(demote == false)
			{
				if(isDrop == false)
				{
					promotion = board.shogiPromotion(board.getPieceOnSquare(originX, originY));
				}
				else
				{
					promotion = board.shogiPromotion(originX);
				}
			}
			else
			{
				if(isDrop == false)
				{
					promotion = board.shogiDemotion(board.getPieceOnSquare(originX, originY));
				}
				else
				{
					promotion = board.shogiDemotion(originX);
				}
			}
		}
		preventBoardEventToggling = false;
		return cancelMove;
	}
	
	public boolean Promote()
	{
		boolean cancelMove = false;
		boolean originEligible;
		boolean destEligible;
		boolean isPromotable;
		boolean isDemotable;
		int forcePromotion = board.getForcePromotions();
		boolean isDrop = originX > 0 && originX <= board.getMaxPieces() && originY == -1;
		if(board.capturedIronPiece(originX, originY, ex, ey, destX, destY))
		{
			cancelMove = true;
			return cancelMove;
		}
		else if(isDrop && board.getPieceOnSquare(destX, destY) != 0)
		{
			cancelMove = true;
			return cancelMove;
		}
		else if(board.capturedContagiousPiece(originX, originY, ex, ey, destX, destY) != -1 && !board.immuneToContagiousPromotions(board.getPieceOnSquare(originX, originY)))
		{
			int newPiece = board.capturedContagiousPiece(originX, originY, ex, ey, destX, destY);
			if(newPiece > board.getNPieceTypes())
			{
				newPiece -= board.getNPieceTypes();
			}
			else
			{
				newPiece += board.getNPieceTypes();
			}
			promotion = newPiece;
			return cancelMove;
		}
		else if(board.getPromotionChoice().equals("shogi"))
		{
			originEligible = board.isInsidePromotionZone(originY, board.getPieceOnSquare(originX, originY));
			destEligible = board.isInsidePromotionZone(destY, board.getPieceOnSquare(originX, originY));
			isPromotable = board.isPromotable(board.getPieceOnSquare(originX, originY));
			if(board.getAllowDropPromotions() == true)
			{
				if(isDrop)
				{
					destEligible = true;
					isPromotable = board.isPromotable(originX);
					forcePromotion = 0;
				}
			}
			if(isPromotable == true && (originEligible == true || destEligible == true))
			{
				if(board.getForceShogiPromotionZone(board.getPieceType(board.getPieceOnSquare(originX, originY)) - 1) > 0 && board.isInsidePromotionZone(destY, board.getPieceOnSquare(originX, originY), board.getForceShogiPromotionZone(board.getPieceType(board.getPieceOnSquare(originX, originY)) - 1)))
				{
					forcePromotion = 2;
				}
				boolean intermediateCapture = false;
				for(int i = 0; i < Math.min(ex.size(),ey.size()); ++i)
				{
					if(board.getPieceOnSquare(ex.get(i), ey.get(i)) > 0 && (originX != ex.get(i) || originY != ey.get(i)))
					{
						intermediateCapture = true;
					}
				}
				if(destX == originX && destY == originY && !intermediateCapture)
				{
					if(board.getAllowPromotionOnTurnSkip())
					{
						if(forcePromotion == 2)
						{
							promotion = board.shogiPromotion(board.getPieceOnSquare(originX, originY));
						}
						else
						{
							disableBoardEvents = true;
							disableMenuEvents = true;
							closeExcessDialogs();
							cancelMove = confirmShogiPromotion(false, isDrop);
							disableMenuEvents = false;
							disableBoardEvents = false;
						}
					}
				}
				else
				{
					if(forcePromotion == 2)
					{
						promotion = board.shogiPromotion(board.getPieceOnSquare(originX, originY));
					}
					else
					{
						disableBoardEvents = true;
						disableMenuEvents = true;
						closeExcessDialogs();
						cancelMove = confirmShogiPromotion(false, isDrop);
						disableMenuEvents = false;
						disableBoardEvents = false;
					}
				}
			}
		}
		else if(board.getPromotionChoice().equals("capture"))
		{
			destEligible = board.capturedPiece(originX, originY, ex, ey, destX, destY);
			isPromotable = board.isPromotable(board.getPieceOnSquare(originX, originY));
			if(board.getAllowDropPromotions() == true)
			{
				if(isDrop)
				{
					destEligible = true;
					isPromotable = board.isPromotable(originX);
					forcePromotion = 0;
				}
			}
			if(destEligible == true && isPromotable == true)
			{
				if(forcePromotion == 2)
				{
					promotion = board.shogiPromotion(board.getPieceOnSquare(originX, originY));
				}
				else if(forcePromotion == 1)
				{
					if(board.capturedPromotedPiece(originX, originY, ex, ey, destX, destY))
					{
						promotion = board.shogiPromotion(board.getPieceOnSquare(originX, originY));
					}
					else
					{
						disableBoardEvents = true;
						disableMenuEvents = true;
						closeExcessDialogs();
						cancelMove = confirmShogiPromotion(false, isDrop);
						disableMenuEvents = false;
						disableBoardEvents = false;
					}
				}
				else
				{
					disableBoardEvents = true;
					disableMenuEvents = true;
					closeExcessDialogs();
					cancelMove = confirmShogiPromotion(false, isDrop);
					disableMenuEvents = false;
					disableBoardEvents = false;
				}
			}
		}
		else if(board.getPromotionChoice().equals("microshogi"))
		{
			destEligible = board.capturedPiece(originX, originY, ex, ey, destX, destY);
			isPromotable = board.isPromotable(board.getPieceOnSquare(originX, originY));
			isDemotable = board.isDemotable(board.getPieceOnSquare(originX, originY));
			if(board.getAllowDropPromotions() == true)
			{
				if(isDrop)
				{
					destEligible = true;
					isPromotable = board.isPromotable(originX);
					isDemotable = board.isDemotable(originX);
					forcePromotion = 0;
				}
			}
			if(destEligible == true && isPromotable == true)
			{
				if(forcePromotion == 2)
				{
					promotion = board.shogiPromotion(board.getPieceOnSquare(originX, originY));
				}
				else
				{
					disableBoardEvents = true;
					disableMenuEvents = true;
					closeExcessDialogs();
					cancelMove = confirmShogiPromotion(false, isDrop);
					disableMenuEvents = false;
					disableBoardEvents = false;
				}
			}
			else if(destEligible == true && isDemotable == true)
			{
				if(forcePromotion == 2)
				{
					promotion = board.shogiDemotion(board.getPieceOnSquare(originX, originY));
				}
				else
				{
					disableBoardEvents = true;
					disableMenuEvents = true;
					closeExcessDialogs();
					cancelMove = confirmShogiPromotion(true, isDrop);
					disableMenuEvents = false;
					disableBoardEvents = false;
				}
			}
		}
		else
		{
			originEligible = board.isInsidePromotionZone(originY, board.getPieceOnSquare(originX, originY));
			destEligible = board.isInsidePromotionZone(destY, board.getPieceOnSquare(originX, originY));
			isPromotable = board.isPromotable(board.getPieceOnSquare(originX, originY));
			if(isPromotable == true && (originEligible == true || destEligible == true))
			{
				boolean intermediateCapture = false;
				for(int i = 0; i < Math.min(ex.size(),ey.size()); ++i)
				{
					if(board.getPieceOnSquare(ex.get(i), ey.get(i)) > 0 && (originX != ex.get(i) || originY != ey.get(i)))
					{
						intermediateCapture = true;
					}
				}
				if(destX == originX && destY == originY && !intermediateCapture)
				{
					if(board.getAllowPromotionOnTurnSkip())
					{
						boolean[] promoChoices = board.getPromoChoices(destY, board.getPieceOnSquare(originX, originY));
						boolean[] takeFromHoldings = board.getTakeFromHoldings();
						int color = board.getPieceColor(board.getPieceOnSquare(originX, originY));
						disableBoardEvents = true;
						disableMenuEvents = true;
						closeExcessDialogs();
						promotion = showPromotionsDialog(promoChoices, color);
						disableMenuEvents = false;
						disableBoardEvents = false;
						if(promotion == -1)
						{
							cancelMove = true;
							return cancelMove;
						}
						int takeFromHoldingsIndex;
						if(promotion > board.getNPieceTypes())
						{
							takeFromHoldingsIndex = promotion - 1 - board.getNPieceTypes();
						}
						else
						{
							takeFromHoldingsIndex = promotion - 1;
						}
						if(takeFromHoldings[takeFromHoldingsIndex] == true)
						{
							board.Hold(promotion, true);
						}
					}
				}
				else
				{
					boolean[] promoChoices = board.getPromoChoices(destY, board.getPieceOnSquare(originX, originY));
					boolean[] takeFromHoldings = board.getTakeFromHoldings();
					int color = board.getPieceColor(board.getPieceOnSquare(originX, originY));
					disableBoardEvents = true;
					disableMenuEvents = true;
					closeExcessDialogs();
					promotion = showPromotionsDialog(promoChoices, color);
					disableMenuEvents = false;
					disableBoardEvents = false;
					if(promotion == -1)
					{
						cancelMove = true;
						return cancelMove;
					}
					int takeFromHoldingsIndex;
					if(promotion > board.getNPieceTypes())
					{
						takeFromHoldingsIndex = promotion - 1 - board.getNPieceTypes();
					}
					else
					{
						takeFromHoldingsIndex = promotion - 1;
					}
					if(takeFromHoldings[takeFromHoldingsIndex] == true)
					{
						board.Hold(promotion, true);
					}
				}
			}
		}
		return cancelMove;
	}
	
	public int showPromotionsDialog(boolean[] options, int color)
	{
		if(color == -1)
		{
			return -1;
		}
		
		promotionOption = -1;
		boolean hasOption = false;
		VBox promotionVBox;
		
		for(int i = 0; i < options.length; ++i)
		{
			if(options[i] == true)
			{
				hasOption = true;
			}
		}
		
		if(hasOption == false)
		{
			Label failedPromotion = new Label("No piece to choose!");
			promotionVBox = new VBox(failedPromotion);
			promotionVBox.setPrefWidth(250);
			promotionVBox.setSpacing(10);
			promotionVBox.setPadding(new Insets(10));
			promotionVBox.setAlignment(Pos.CENTER);
		}
		else
		{
			Label promotionLabel = new Label("Which piece will you promote to (Close this window to cancel)?");
			promotionLabel.setStyle("-fx-text-alignment:center");
			
			VBox optionsVBox = new VBox();
			optionsVBox.setSpacing(0);
			optionsVBox.setPadding(new Insets(0));
			
			int index = 0;
			
			GridPane promotionOptionsPane = new GridPane();
			
			for(int i = 0; i < options.length; ++i)
			{
				if(options[i] == true)
				{
					int optionNumber;
					if(color == 0)
					{
						optionNumber = i + 1 + board.getNPieceTypes();
					}
					else
					{
						optionNumber = i + 1;
					}
					StackPane optionPane = new StackPane(pieceList.getPieceImage(optionNumber));
					optionPane.setPrefSize(squareSize, squareSize);
					optionPane.setId(Integer.toString(optionNumber));
					optionPane.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
					optionPane.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
						StackPane pane = (StackPane)e.getSource();
						int paneID = Integer.parseInt(pane.getId());
						promotionOption = paneID;
						promotionStage.close();
					});
					promotionOptionsPane.add(optionPane, 0, index);
					++index;
				}
			}
			
			promotionVBox = new VBox(promotionLabel, promotionOptionsPane);
			promotionVBox.setSpacing(10);
			promotionVBox.setPadding(new Insets(10));
			promotionVBox.setAlignment(Pos.CENTER);
		}
		
		ScrollPane promotionScrollPane = new ScrollPane();
		promotionScrollPane.fitToWidthProperty().set(true);
		promotionScrollPane.fitToHeightProperty().set(true);
		promotionScrollPane.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		promotionScrollPane.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		promotionScrollPane.setPadding(new Insets(0));
		promotionScrollPane.setContent(promotionVBox);
		StackPane promotionPane = new StackPane(promotionScrollPane);
		Scene promotionScene = new Scene(promotionPane); 
		promotionStage = new Stage();
		promotionStage.setScene(promotionScene);
		
		promotionPane.setMaxWidth(screenWidth);
		promotionPane.setMaxHeight(screenHeight);
		
		promotionStage.setAlwaysOnTop(true);
		promotionStage.setTitle("Promotion");
		promotionStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
		promotionStage.showAndWait();
		return promotionOption;
	}
	
	public void createKeyBoardShortcuts()
	{
		KeyCombination newGameBindings = new KeyCodeCombination(KeyCode.N, KeyCombination.CONTROL_DOWN);
		Runnable newGameShortcut = () -> {
			if(!disableMenuEvents) newGame(true);
		};
		boardScene.getAccelerators().put(newGameBindings, newGameShortcut);
		
		KeyCombination loadGamePresetBindings = new KeyCodeCombination(KeyCode.N, KeyCombination.CONTROL_DOWN, KeyCombination.SHIFT_DOWN);
		Runnable loadGamePresetShortcut = () -> {
			if(!disableMenuEvents) showGamePresetsDialog();
		};
		boardScene.getAccelerators().put(loadGamePresetBindings, loadGamePresetShortcut);
		
		KeyCombination editFENCodeBindings = new KeyCodeCombination(KeyCode.O, KeyCombination.CONTROL_DOWN);
		Runnable editFENCodeShortcut = () -> {
			if(!disableMenuEvents) showFENCodeDialog();
		};
		boardScene.getAccelerators().put(editFENCodeBindings, editFENCodeShortcut);
		
		KeyCombination editGameMovesBindings = new KeyCodeCombination(KeyCode.I, KeyCombination.CONTROL_DOWN);
		Runnable editGameMovesShortcut = () -> {
			if(!disableMenuEvents) showGameMovesDialog();
		};
		boardScene.getAccelerators().put(editGameMovesBindings, editGameMovesShortcut);
		
		KeyCombination flipViewBindings = new KeyCodeCombination(KeyCode.F2);
		Runnable flipViewShortcut = () -> flipBoard();
		boardScene.getAccelerators().put(flipViewBindings, flipViewShortcut);
		
		KeyCombination resetSizeBindings = new KeyCodeCombination(KeyCode.DIGIT0, KeyCombination.CONTROL_DOWN);
		Runnable resetSizeShortcut = () -> resetViewingSize();
		boardScene.getAccelerators().put(resetSizeBindings, resetSizeShortcut);
		
		KeyCombination showMoveHistoryBindings = new KeyCodeCombination(KeyCode.M);
		Runnable showMoveHistoryShortcut = () -> {
			showMoveHistory();
		};
		boardScene.getAccelerators().put(showMoveHistoryBindings, showMoveHistoryShortcut);
		
		KeyCombination showHoldingsBindings = new KeyCodeCombination(KeyCode.H);
		Runnable showHoldingsShortcut = () -> {
			showHoldings();
		};
		boardScene.getAccelerators().put(showHoldingsBindings, showHoldingsShortcut);
		
		KeyCombination goToBeginningBindings = new KeyCodeCombination(KeyCode.UP, KeyCombination.CONTROL_DOWN);
		Runnable goToBeginningShortcut = () -> {
			goToBeginning();
		};
		boardScene.getAccelerators().put(goToBeginningBindings, goToBeginningShortcut);
		
		KeyCombination goOneBackBindings = new KeyCodeCombination(KeyCode.LEFT, KeyCombination.CONTROL_DOWN);
		Runnable goOneBackShortcut = () -> {
			goOneBack();
		};
		boardScene.getAccelerators().put(goOneBackBindings, goOneBackShortcut);
		
		KeyCombination goOneForwardBindings = new KeyCodeCombination(KeyCode.RIGHT, KeyCombination.CONTROL_DOWN);
		Runnable goOneForwardShortcut = () -> {
			goOneForward();
		};
		boardScene.getAccelerators().put(goOneForwardBindings, goOneForwardShortcut);
		
		KeyCombination goToEndBindings = new KeyCodeCombination(KeyCode.DOWN, KeyCombination.CONTROL_DOWN);
		Runnable goToEndShortcut = () -> {
			goToEnd();
		};
		boardScene.getAccelerators().put(goToEndBindings, goToEndShortcut);
		
		KeyCombination undoMoveBindings = new KeyCodeCombination(KeyCode.Z, KeyCombination.CONTROL_DOWN);
		Runnable undoMoveShortcut = () -> {
			undoMove();
		};
		boardScene.getAccelerators().put(undoMoveBindings, undoMoveShortcut);
	}
}