package defaults;

public class PieceSetCredits {
	private static String credits = "Chess, Yangsi, Xiangqi, Shogi sets - musketeerchess.com\n\n" + 
			"Mnemonic sets (Futashikana, Taishin) for large Shogi variants - H.G. Muller, expanded by the author, Adam DeWitt\n\n" + 
			"Shogi pieces for large Shogi variants - the author, Adam DeWitt, with Special Thanks to pixilart.com";
	
	public static String getPieceSetCredits()
	{
		return credits;
	}
}
