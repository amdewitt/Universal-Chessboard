package main;

import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;

public class ViewingScreen {
	private int screenWidth;
	private int screenHeight;
	
	public ViewingScreen()
	{
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice graphicsDevice = graphicsEnvironment.getDefaultScreenDevice();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	    Insets screenInsets = toolkit.getScreenInsets(graphicsDevice.getDefaultConfiguration());
	    Rectangle availableScreenBounds = new Rectangle(screenSize);
	    
	    screenWidth = availableScreenBounds.width - (screenInsets.left + screenInsets.right);
	    screenHeight = availableScreenBounds.height - (screenInsets.top + screenInsets.bottom);
	}
	
	public int getScreenWidth()
	{
		return screenWidth;
	}
	
	public int getScreenHeight()
	{
		return screenHeight;
	}
}
