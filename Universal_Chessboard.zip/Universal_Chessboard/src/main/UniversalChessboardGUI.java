package main;
import board.*;
import piece.*;

import java.io.*;
import java.util.*;
import java.util.regex.*;

import javafx.application.Application;
import javafx.event.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.geometry.*;
import javafx.scene.input.*;

/**
 * The UniversalChessboardGUI class is the main class of the Universal</br>
 * Chessboard.
 * @author Adam
 *
 */
public class UniversalChessboardGUI extends Application {
	private Stage boardStage = new Stage(); // board stage
	private Scene boardScene; // board scene

	// Dialog Objects

	private Stage confirmStage = new Stage();
	private int confirmOptionChosen = -1;
	private Stage gamePresetsStage = new Stage(); // dialog for changing square colors
	private Stage fenCodeStage = new Stage(); // dialog for changing square colors
	private Stage fenCodeHelpStage = new Stage();
	private Stage fenCodeRequirementsStage = new Stage();
	private Stage colorsStage = new Stage(); // dialog for changing square colors
	private Stage highlightsStage = new Stage(); // dialog for changing square colors
	
	// Board GUI Objects
	
	private MenuBar boardMenu; // board menu
	private GridPane boardDisplay; // visual representation of board
	private ScrollPane scrollPane;
	private StackPane boardPane;
	private VBox mainVBox;
	private HBox menuHBox;
	// private BorderPane coordinateLabels; // pane to include boardLabels
	private Board board; // internal board
	private boolean[][] shades; // controls shading of squares. true equals dark shade.
	private PieceList pieceList;
	private int nFiles;
	private int nRanks;
	
	private StringBuffer defaultSelectedPieceColor = new StringBuffer("#80FF80"); // default selected piece color
	private StringBuffer defaultLastMoveColor = new StringBuffer("#00FF00"); // highlight for last move (origin and destination squares)
	private StringBuffer defaultLastLocustCaptureColor = new StringBuffer("#FFC000"); // highlight for last move (intermediate squares)
	private StringBuffer defaultMoveColor = new StringBuffer("#FFFF00"); // highlight for move to empty square
	private StringBuffer defaultCaptureColor = new StringBuffer("#FF0000"); // highlight for capturing enemy pieces
	private StringBuffer defaultDestroyColor = new StringBuffer("#0000FF"); // highlight for destroying friendly pieces
	private StringBuffer defaultLocustCaptureColor = new StringBuffer("#00FFFF"); // highlight for locust captures
	
	private StringBuffer defaultHoleColor = new StringBuffer("#000000");
	private StringBuffer defaultHoleBorderColor = new StringBuffer("#FFFFFF");
	
	private StringBuffer selectedPieceColor = new StringBuffer("#80FF80"); // default selected piece color
	private StringBuffer lastMoveColor = new StringBuffer("#00FF00"); // highlight for last move (origin and destination squares)
	private StringBuffer lastLocustCaptureColor = new StringBuffer("#FFC000"); // highlight for last move (intermediate squares)
	private StringBuffer moveColor = new StringBuffer("#FFFF00"); // highlight for move to empty square
	private StringBuffer captureColor = new StringBuffer("#FF0000"); // highlight for capturing enemy pieces
	private StringBuffer destroyColor = new StringBuffer("#0000FF"); // highlight for destroying friendly pieces
	private StringBuffer locustCaptureColor = new StringBuffer("#00FFFF"); // highlight for locust captures
	
	private StringBuffer holeColor = new StringBuffer("#000000");
	private StringBuffer holeBorderColor = new StringBuffer("#FFFFFF");

	private ViewingScreen viewingScreen; // screen size
	
	private StringBuffer preset = new StringBuffer("default");

	// Board Display Properties

	// Default color of light squares
	private StringBuffer defaultLightShade = new StringBuffer("#FFCC9C");
	// Default color of dark squares
	private StringBuffer defaultDarkShade = new StringBuffer("#CF8948");
	// Color of light squares
	private StringBuffer lightShade = new StringBuffer("#FFCC9C");
	// Color of dark squares
	private StringBuffer darkShade = new StringBuffer("#CF8948");
	// Size of board squares
	private int squareSize = 54;
	// Whether piece images should be flipped when the board is flipped.
	private boolean flipPiecesOnBoardFlip = false;
	// Whether to flip the board.
	private boolean flipView = false;
	/*
	 * Whether to use Shogi-style coordinates and piece IDs. Affects move
	 * coordinates and piece IDs in moves and FEN Strings.
	 */
	private boolean shogiMode = false;
	
	// Variables for moving pieces
	
	/*
	 * Whether to disable board events.
	 * Set to true whenever something could change vital board statistics and
	 * set to false when that something is gone.
	 */
	private boolean disableBoardEvents = false;
	
	// Whether a piece is selected. Set to true if a piece is selected
	private boolean pieceSelected = false;
	
	// Move Parts
	private int originX = -1; // origin
	private int originY = -1;
	private ArrayList<Integer> ex = new ArrayList<Integer>(); // intermediate squares, if present
	private ArrayList<Integer> ey = new ArrayList<Integer>();
	private int destX = -1; // destination
	private int destY = -1;
	private int promotion = -1; // promotion, if present

	// Initialize Application

	public static void main(String[] args) {
		launch(args);
	}

	/**
	 * GUI
	 */
	public void start(Stage primaryStage) {
		createMenu();
		//createKeyboardShortcuts();
		createBoard();
		ResetEvents(true);
		// createCoordinateLabels();
		boardStage = primaryStage;
		mainVBox = new VBox(menuHBox, boardPane);
		mainVBox.setAlignment(Pos.TOP_CENTER);
		mainVBox.setSpacing(0.0);
		mainVBox.setPadding(new Insets(0));
		boardScene = new Scene(mainVBox);
		boardStage.setScene(boardScene);
		boardStage.setTitle("Universal Chessboard");
		
		boardStage.setOnCloseRequest(e -> {
			closeAllDialogs();
		});
		boardStage.getIcons().add(new Image("/icon/universal_chessboard_icon.png"));
		boardStage.show();
		resetViewingSize();
	}

	// Menu Event Handlers

	// File Menu
	
	// New Game
	private EventHandler<ActionEvent> newGameEvent = e -> {
		closeExcessDialogs();
		newGame(true);
	};
	
	// Load Game Preset...
	private EventHandler<ActionEvent> loadGamePresetEvent = e -> {
		closeExcessDialogs();
		disableBoardEvents = true;
		showGamePresetsDialog();
	};

	// Edit Menu

	// Load FEN Code
	private EventHandler<ActionEvent> loadFENCodeEvent = e -> {
		closeExcessDialogs();
		disableBoardEvents = true;
		showFENCodeDialog();
	};
	
	// View Menu
	
	// Flip View
	private EventHandler<ActionEvent> flipBoardViewEvent = e -> {
		flipBoard();
	};

	// Reset Viewing Size/Position
	private EventHandler<ActionEvent> resetSizeEvent = e -> {
		resetViewingSize();
	};

	// Colors...
	private EventHandler<ActionEvent> setColorsEvent = e -> {
		closeExcessDialogs();
		disableBoardEvents = false;
		showColorsDialog();
	};
	
	// Colors...
	private EventHandler<ActionEvent> setHighlightsEvent = e -> {
		closeExcessDialogs();
		disableBoardEvents = false;
		showHighlightsDialog();
	};

	private boolean checkColorFormat(String colorString) {
		Pattern validFormat1 = Pattern.compile("#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})");
		Pattern validFormat2 = Pattern.compile("([0-9a-fA-F]{3}|[0-9a-fA-F]{6})");
		Matcher m1 = validFormat1.matcher(colorString);
		Matcher m2 = validFormat2.matcher(colorString);
		boolean isValidFormat = m1.matches() || m2.matches();
		return isValidFormat;
	}

	// Mode Menu
	
	// Help Menu

	// ----------------------------------------------------------------------------------------

	// Initialize Stage

	/**
	 * Creates the menu at the top of the application.
	 */
	public void createMenu() {
		boardMenu = new MenuBar();
		boardMenu.setPrefHeight(20);
		
		Menu fileMenu = new Menu("File");
		MenuItem newGame = new MenuItem("New Game");
		newGame.setOnAction(newGameEvent);
		fileMenu.getItems().add(newGame);
		MenuItem loadGamePreset = new MenuItem("Load Game Preset...");
		loadGamePreset.setOnAction(loadGamePresetEvent);
		fileMenu.getItems().add(loadGamePreset);
		boardMenu.getMenus().add(fileMenu);

		Menu editMenu = new Menu("Edit");
		MenuItem loadFENCode = new MenuItem("Load FEN Code...");
		loadFENCode.setOnAction(loadFENCodeEvent);
		editMenu.getItems().add(loadFENCode);
		boardMenu.getMenus().add(editMenu);

		Menu viewMenu = new Menu("View");
		MenuItem flipBoard = new MenuItem("Flip View");
		flipBoard.setOnAction(flipBoardViewEvent);
		viewMenu.getItems().add(flipBoard);
		MenuItem resetSize = new MenuItem("Reset Viewing Size/Position");
		resetSize.setOnAction(resetSizeEvent);
		viewMenu.getItems().add(resetSize);
		MenuItem setColors = new MenuItem("Colors...");
		setColors.setOnAction(setColorsEvent);
		viewMenu.getItems().add(setColors);
		MenuItem setHighlights = new MenuItem("Highlights...");
		setHighlights.setOnAction(setHighlightsEvent);
		viewMenu.getItems().add(setHighlights);
		boardMenu.getMenus().add(viewMenu);

		Menu modeMenu = new Menu("Mode");
		modeMenu.setDisable(true);
		boardMenu.getMenus().add(modeMenu);

		Menu helpMenu = new Menu("Help");
		MenuItem fenCodeHelp = new MenuItem("FEN Code");
		fenCodeHelp.setOnAction(e -> {
			showFENCodeHelp();
		});
		helpMenu.getItems().add(fenCodeHelp);
		boardMenu.getMenus().add(helpMenu);
		
		Button goToBeginning = new Button("<<");
		goToBeginning.setPrefHeight(boardMenu.getHeight());
		goToBeginning.setOnAction(e -> {
			goToBeginning();
		});
		
		Button goOneBack = new Button("<");
		goOneBack.setPrefHeight(boardMenu.getHeight());
		goOneBack.setOnAction(e -> {
			goOneBack();
		});
		
		Button goOneForward = new Button(">");
		goOneForward.setPrefHeight(boardMenu.getHeight());
		goOneForward.setOnAction(e -> {
			goOneForward();
		});
		
		Button goToEnd = new Button(">>");
		goToEnd.setPrefHeight(boardMenu.getHeight());
		goToEnd.setOnAction(e -> {
			goToEnd();
		});
		
		Button undoMove = new Button("Undo Move");
		undoMove.setPrefHeight(boardMenu.getHeight());
		undoMove.setOnAction(e -> {
			undoMove();
		});

		menuHBox = new HBox(boardMenu, goToBeginning, goOneBack, goOneForward, goToEnd, undoMove);
	}
	
	// Keyboard Shortcuts

	// Custom Board, Custom Pieces

	public void createBoard(int files, int ranks, int nPieces, String pieceDir, String wPrefix, String bPrefix,
			boolean useGIFImages) {
		board = new Board(files, ranks, nPieces);
		shades = null;
		shades = new boolean[ranks][files];
		pieceList = new PieceList(nPieces, pieceDir, wPrefix, bPrefix, useGIFImages);
		nFiles = board.getNFiles() + 1;
		nRanks = board.getNRanks() + 1;
		shades = new boolean[nRanks][nFiles];
		createBoardDisplay();
	}

	// Custom Board, Default Pieces

	public void createBoard(int files, int ranks) {
		board = new Board(files, ranks);
		shades = null;
		shades = new boolean[ranks][files];
		pieceList = new PieceList();
		nFiles = board.getNFiles() + 1;
		nRanks = board.getNRanks() + 1;
		shades = new boolean[nRanks][nFiles];
		createBoardDisplay();
		defineShades("");
		Display(false);
	}

	// Default Board

	/**
	 * Creates a new board with the default settings.
	 */
	public void createBoard() {
		board = new Board();
		shades = null;
		shades = new boolean[8][8];
		pieceList = new PieceList();
		nFiles = board.getNFiles() + 1;
		nRanks = board.getNRanks() + 1;
		createBoardDisplay();
		defineShades("");
		Display(false);
	}

	/**
	 * Creates the board displayed in the GUI
	 */
	public void createBoardDisplay() {

		GridPane newBoardDisplay = new GridPane();
		newBoardDisplay.setAlignment(Pos.CENTER);
		newBoardDisplay.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
		newBoardDisplay.setMinSize(squareSize * nFiles + 2, squareSize * nRanks + 2);
		newBoardDisplay.setMaxSize(squareSize * nFiles + 2, squareSize * nRanks + 2);
		newBoardDisplay.setPadding(new Insets(0));
		newBoardDisplay.setHgap(0);
		newBoardDisplay.setVgap(0);

		for (int i = 0; i < (nFiles * nRanks); ++i) {
			StackPane boardSquare = new StackPane();
			boardSquare.setAlignment(Pos.CENTER);
			boardSquare.setMinSize(squareSize, squareSize);
			boardSquare.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;"); // add to board display
			boardSquare.addEventHandler(MouseEvent.MOUSE_CLICKED, movePieceEvent);
			newBoardDisplay.add(boardSquare, ((int) i % nFiles), ((int) i / nFiles));
		}
		newBoardDisplay.setPrefSize(squareSize * nFiles, squareSize * nRanks);
		boardDisplay = newBoardDisplay;
		scrollPane = new ScrollPane();
		scrollPane.fitToWidthProperty().set(true);
		scrollPane.fitToHeightProperty().set(true);
		scrollPane.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		scrollPane.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		scrollPane.setPadding(new Insets(0));
		scrollPane.setContent(boardDisplay);
		boardPane = new StackPane(scrollPane);
		boardPane.setPadding(new Insets(0));
	}

	/**
	 * Defines the shades of the board based on a specialized FEN String</br>
	 * consisting of ones, zeroes, and slashes. 0 means a light square,</br>
	 * 1 means a dark square. Sets shades to the default pattern</br>
	 * (a checkerboard) if the string is invalid or empty.
	 * @param shadeString the shade string defining the desired pattern.
	 */
	public void defineShades(String shadeString) {
		if (shadeString == "") {
			boolean useDarkShade = false; // flags for shading the board squares
			boolean switchShade = false;
			for (int i = 0; i < nRanks; ++i) {
				if (nFiles % 2 == 0) {
					if (useDarkShade) {
						useDarkShade = false;
					} else {
						useDarkShade = true;
					}
				}
				for (int j = 0; j < nFiles; ++j) {
					if (switchShade) {
						switchShade = false;
					} else {
						switchShade = true;
					}
					try {
						if (useDarkShade) {
							if (switchShade) {
								shades[i][j] = true;
							}
						} else {
							if (!switchShade) {
								shades[i][j] = true;
							}
						}
					} catch (ArrayIndexOutOfBoundsException aioobe) {
						break;
					}
				}
			}
		} else {
			for (int i = 0; i < shadeString.length(); ++i) {
				if (Character.compare(shadeString.charAt(i), '0') != 0
						&& Character.compare(shadeString.charAt(i), '1') != 0
						&& Character.compare(shadeString.charAt(i), '/') != 0) {
					defineShades("");
					return;
				}
			}
			String[] lines = shadeString.split("/");
			for (int i = Math.min(nRanks - 1, lines.length - 1); i >= 0; --i) {
				for (int j = 0; j < Math.min(nFiles, lines[i].length()); ++j) {
					if (Character.compare(lines[i].charAt(j), '1') == 0) {
						try {
							shades[i][j] = true;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							break;
						}
					}
				}
			}
		}
	}

	/**
	 * Updates the board display.
	 * @param preserveHighlights whether to preserve the board highlights
	 */
	public void Display(boolean preserveHighlights) {
		if(preserveHighlights)
		{
			ResetEvents(false);
		}
		else
		{
			ResetEvents(true);
		}
		for (int i = 0; i < nRanks; ++i) {
			for (int j = 0; j < nFiles; ++j) {
				int pieceOnSquare = board.getPieceOnSquare(j, i);
				StackPane boardSquare = getBoardSquare(j, i);
				if (boardSquare == null) {
					continue;
				}
				String squareID = j + "," + i;
				boardSquare.setId(squareID);

				if (pieceOnSquare == -1) {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(holeColor.toString()), CornerRadii.EMPTY, Insets.EMPTY)));
					boardSquare.getChildren().clear();
					String holeBorderString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + holeBorderColor.toString() + ";";
					boardSquare.setStyle(holeBorderString);
				} else if (pieceOnSquare == 0) {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(getShadeColor(j, i)), CornerRadii.EMPTY, Insets.EMPTY)));
					boardSquare.getChildren().clear();

					// if(preserveHighlights) { if(i < (nRanks / 2)) { Highlight(j, i, moveColor.toString()); } else { Highlight(j, i, captureColor.toString()); } }
				} else if (pieceOnSquare >= 1 && pieceOnSquare <= board.getMaxPieces()) {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(getShadeColor(j, i)), CornerRadii.EMPTY, Insets.EMPTY)));
					String[] squareCoords = boardSquare.getId().split(",");
					if(preserveHighlights)
					{
						if(originX == Integer.parseInt(squareCoords[0]) && originY == Integer.parseInt(squareCoords[1]))
						{
							boardSquare.setBackground(new Background(new BackgroundFill(Color.web(selectedPieceColor.toString()), CornerRadii.EMPTY, Insets.EMPTY)));
							selectPiece(originX, originY, false);
						}
					}
					boardSquare.getChildren().clear();

					ImageView piece = pieceList.getPieceImage(pieceOnSquare);
					if (flipPiecesOnBoardFlip && flipView) {
						piece.setRotate(180);
					} else {
						piece.setRotate(0);
					}
					boardSquare.getChildren().add(piece);
				} else {
					boardSquare.setBackground(new Background(new BackgroundFill(Color.web(getShadeColor(j, i)), CornerRadii.EMPTY, Insets.EMPTY)));
					boardSquare.getChildren().clear();
				}
				//boardSquare.getChildren().add(new Label(boardSquare.getId()));
			}
		}
	}

	private String getShadeColor(int x, int y) {
		String color;
		if (shades[y][x]) {
			color = darkShade.toString();
		} else {
			color = lightShade.toString();
		}
		return color;
	}

	/**
	 * Gets the square on the board display corresponding to the</br>
	 * coordinate (x,y). Returns null if coordinates are invalid.
	 * 
	 * @param x the x-coordinate of this square. Cannot be < 0 or >= nFiles.
	 * @param y the y-coordinate of this square. Cannot be < 0 or >= nRanks.
	 * @return
	 */
	public StackPane getBoardSquare(int x, int y) {
		int nSquares = boardDisplay.getChildren().size() - 1;
		int squareIndex = x + (nRanks - 1 - y) * nFiles;
		if (x < 0 || x >= nFiles || y < 0 || y >= nRanks) {
			return null;
		}
		if (flipView) {
			return (StackPane) boardDisplay.getChildren().get(nSquares - squareIndex);
		} else {
			return (StackPane) boardDisplay.getChildren().get(squareIndex);
		}
	}

	/**
	 * Highlights the selected square with a circle with a black border and a given color.
	 * @param x x-coordinate of square
	 * @param y x-coordinate of square
	 * @param color color of the circle
	 */
	public void Highlight(int x, int y, String color) {
		if (x < 0 || x >= nFiles || y < 0 || y >= nRanks) {
			return;
		}
		StackPane boardSquare = getBoardSquare(x, y);
		if (boardSquare == null) {
			return;
		}

		int nChildren = boardSquare.getChildren().size();
		boolean hasChildren = (nChildren > 0);

		Circle squareHighlight = new Circle();
		squareHighlight.setCenterX(boardSquare.getWidth() / 2);
		squareHighlight.setCenterY(boardSquare.getHeight() / 2);
		int radius = squareSize / 5;
		squareHighlight.setRadius(radius);
		squareHighlight.setFill(Color.web(color));
		squareHighlight.setStroke(Color.web("#000000"));
		squareHighlight.setStrokeWidth(1.0);

		if (hasChildren) {
			if (nChildren == 1) {
				if (boardSquare.getChildren().get(0) instanceof Circle) {
					boardSquare.getChildren().set(0, squareHighlight);
				} else {
					boardSquare.getChildren().add(squareHighlight);
				}
			}
			if (nChildren == 2) {
				if (boardSquare.getChildren().get(1) instanceof Circle) {
					boardSquare.getChildren().set(1, squareHighlight);
				} else {
					boardSquare.getChildren().add(squareHighlight);
				}
			}
		} else {
			squareHighlight.setFill(Color.web(color));
			boardSquare.getChildren().add(squareHighlight);
		}
	}

	/**
	 * Gets the rank ID based on its name and whether Shogi Mode is active
	 * @param fileName name of the file
	 * @param shogiMode	whether to use Shogi coordinates instead of SAN coordinates
	 * @return the integer representation of this file in the internal board
	 */
	public int fileID(char fileName, boolean shogiMode) {
		try {
			return fileName - 97;
		} catch (NumberFormatException nfe) {
			return -1;
		}
	}

	/**
	 * Gets the rank ID based on its name and whether Shogi Mode is active
	 * @param rankName name of the rank
	 * @param shogiMode	whether to use Shogi coordinates instead of SAN coordinates
	 * @return the integer representation of this rank in the internal board
	 */
	public int rankID(String rankName, boolean shogiMode) {
		try {
			return Integer.parseInt(rankName) - 1;
		} catch (NumberFormatException nfe) {
			return -1;
		}
	}
	
	/**
	 * Gets the loading scene. Dialogs should be set to this</br>
	 * scene
	 * @return
	 */
	public void setToLoadingScene(Stage stage)
	{
		Label loadingLabel = new Label("Loading...");
		ImageView loadingImage = new ImageView("/icon/universal_chessboard_icon.png");
		VBox loadingVBox = new VBox(loadingLabel, loadingImage);
		loadingVBox.setAlignment(Pos.CENTER);
		loadingVBox.setSpacing(10);
		loadingVBox.setPadding(new Insets(10));
		Scene scene = new Scene(loadingVBox, 175, 100);
		stage.setScene(scene);
		stage.setTitle("");
		stage.sizeToScene();
		stage.centerOnScreen();
	}

	// Menu Event Methods

	public void newGame(boolean askForConfirmation)
	{
		if((board.getGame().size() - 1) == 0)
		{
			return;
		}
		else
		{
			if(askForConfirmation)
			{
				disableBoardEvents = true;
				int confirmNewGame = showConfirmDialog("Confirm New Game", "This will clear the game that is currently loaded. Are you sure?");
				if(confirmNewGame != 1)
				{
					disableBoardEvents = false;
					return;
				}
			}
			/*while((board.getGame().size() - 1) >= 1)
			{
				ResetEvents(true);
				board.getGame().remove(board.getGame().size() - 1);
				board.Seek(3);
			}*/
			board.getGame().clear();
			board.startPosition();
			board.AddMove(-1, -1, null, null, -1, -1, -1);
			board.Seek(0);
			updateLastMoveSquares(-1, -1, null, null, -1, -1);
			Display(false);
			disableBoardEvents = false;
		}
	}
	
	public int showConfirmDialog(String titleString, String confirmString)
	{
		confirmStage = new Stage();
		confirmStage.setAlwaysOnTop(true);
		confirmOptionChosen = -1;
		Label confirmLabel = new Label(confirmString);
		Button yesButton = new Button("Yes");
		yesButton.setPrefWidth(75);
		yesButton.setOnAction(e -> {
			confirmOptionChosen = 1;
			confirmStage.close();
		});
		Button noButton = new Button("No");
		noButton.setPrefWidth(75);
		noButton.setOnAction(e -> {
			confirmOptionChosen = 0;
			confirmStage.close();
		});
		Button cancelButton = new Button("Cancel");
		cancelButton.setPrefWidth(75);
		cancelButton.setOnAction(e -> {
			confirmOptionChosen = -1;
			confirmStage.close();
		});
		HBox buttonHBox = new HBox(yesButton, noButton, cancelButton);
		buttonHBox.setAlignment(Pos.CENTER);
		buttonHBox.setSpacing(10);
		VBox confirmVBox = new VBox(confirmLabel, buttonHBox);
		confirmVBox.setAlignment(Pos.CENTER);
		confirmVBox.setSpacing(10);
		confirmVBox.setPadding(new Insets(10));
		
		Scene confirmScene = new Scene(confirmVBox);
		confirmStage.setScene(confirmScene);
		confirmStage.setTitle(titleString);
		confirmStage.sizeToScene();
		confirmStage.showAndWait();
		return confirmOptionChosen;
	}
	
	public void showGamePresetsDialog()
	{
		if(gamePresetsStage.isShowing())
		{
			gamePresetsStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label(
					"Press one of the preset buttons to show that preset's text, which can be edited in the text area to the right.\nWhen done, press the Load Preset button to load the preset text. This clears the game you have loaded.");

			Label classicLabel = new Label("Classic");
			classicLabel.setStyle("-fx-underline:true");
			Button chessButton = new Button("Chess");
			Button xiangqiButton = new Button("Xiangqi");
			Button shogiButton = new Button("Shogi");
			VBox classicVBox = new VBox(classicLabel, chessButton, xiangqiButton, shogiButton);
			classicVBox.setAlignment(Pos.TOP_CENTER);
			classicVBox.setSpacing(10);

			Separator categorySeparator1 = new Separator(Orientation.VERTICAL);
			categorySeparator1.setCenterShape(true);

			Label authorGamesLabel = new Label("Author's Games");
			authorGamesLabel.setStyle("-fx-underline:true");
			Button yangsiButton = new Button("Yangsi");
			Button hectochessButton = new Button("Hectochess");
			Button ryugiButton = new Button("Ryugi");
			Button shosuShogiButton = new Button("Shosu Shogi");
			Button cannonShosuShogiButton = new Button("Cannon Shosu Shogi");
			Button futashikanaShogiButton = new Button("Futashikana Shogi");
			Button mitsugumiShogiButton = new Button("Mitsugumi Shogi");
			Button suzumuShogiButton = new Button("Suzumu Shogi");
			Button chushinShogiButton = new Button("Chushin Shogi");
			Button hookShogiButton = new Button("Hook Shogi");
			Button taishinShogiButton = new Button("Taishin Shogi");
			VBox authorGamesVBox = new VBox(authorGamesLabel, yangsiButton, hectochessButton, ryugiButton, shosuShogiButton,
					cannonShosuShogiButton, futashikanaShogiButton, mitsugumiShogiButton, suzumuShogiButton,
					chushinShogiButton, hookShogiButton, taishinShogiButton);
			authorGamesVBox.setAlignment(Pos.TOP_CENTER);
			authorGamesVBox.setSpacing(10);

			Separator categorySeparator2 = new Separator(Orientation.VERTICAL);
			categorySeparator2.setCenterShape(true);

			Label presetTextLabel = new Label("Preset Text");
			presetTextLabel.setStyle("-fx-underline:true");
			TextArea presetText = new TextArea(preset.toString());
			presetText.setPrefHeight(350);
			Button viewCurrentPresetButton = new Button("View Current Preset");
			Button loadPresetButton = new Button("Load Preset");
			HBox buttonHBox = new HBox(viewCurrentPresetButton, loadPresetButton);
			buttonHBox.setAlignment(Pos.TOP_CENTER);
			buttonHBox.setSpacing(10);
			VBox presetTextVBox = new VBox(presetTextLabel, presetText, buttonHBox);
			presetTextVBox.setAlignment(Pos.TOP_CENTER);
			presetTextVBox.setSpacing(10);

			chessButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/chess.txt"));
			});
			xiangqiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/xiangqi.txt"));
			});
			shogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/shogi.txt"));
			});
			yangsiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/yangsi.txt"));
			});
			hectochessButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/hectochess.txt"));
			});
			ryugiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/ryugi.txt"));
			});
			shosuShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/shosu_shogi.txt"));
			});
			cannonShosuShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/cannon_shosu_shogi.txt"));
			});
			futashikanaShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/futashikana_shogi.txt"));
			});
			mitsugumiShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/mitsugumi_shogi.txt"));
			});
			suzumuShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/suzumu_shogi.txt"));
			});
			chushinShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/chushin_shogi.txt"));
			});
			hookShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/hook_shogi.txt"));
			});
			taishinShogiButton.setOnAction(e1 -> {
				presetText.setText(getPresetText("default_presets/taishin_shogi.txt"));
			});
			
			viewCurrentPresetButton.setOnAction(e1 -> {
				presetText.setText(preset.toString());
			});

			loadPresetButton.setOnAction(e1 -> {
				setToLoadingScene(gamePresetsStage);
				Init(presetText.getText());
				resetViewingSize();
				gamePresetsStage.close();
				disableBoardEvents = false;
			});

			HBox gamePresetsHBox = new HBox(classicVBox, categorySeparator1, authorGamesVBox, categorySeparator2,
					presetTextVBox);
			gamePresetsHBox.setAlignment(Pos.CENTER);
			gamePresetsHBox.setSpacing(10);

			VBox gamePresetsVBox = new VBox(instructionsLabel, gamePresetsHBox);
			gamePresetsVBox.setAlignment(Pos.CENTER);
			gamePresetsVBox.setSpacing(10);
			gamePresetsVBox.setPadding(new Insets(10));

			Scene gamePresetsScene = new Scene(gamePresetsVBox);
			loadPresetButton.requestFocus();
			gamePresetsStage.setScene(gamePresetsScene);
			gamePresetsStage.setTitle("Game Presets");
			gamePresetsStage.setOnCloseRequest(e -> {
				disableBoardEvents = false;
			});
			gamePresetsStage.show();
		}
	}
	

	private String getPresetText(String filename) {
		try {
			File presetFile = new File(filename);
			if (presetFile.exists()) {
				Scanner presetFileScanner = new Scanner(presetFile);
				StringBuffer presetText = new StringBuffer();
				while (presetFileScanner.hasNextLine()) {
					presetText.append(presetFileScanner.nextLine());
					if (presetFileScanner.hasNextLine()) {
						presetText.append("\n");
					}
				}
				presetFileScanner.close();
				return presetText.toString();
			} else {
				return "";
			}
		} catch (NullPointerException npe) {
			return "";
		} catch (FileNotFoundException fnfe) {
			return "";
		}
	}

	private void Init(String newPresetText) {
		if (newPresetText.equals("default")) {
			defaultLightShade = new StringBuffer("#FFCC9C");
			defaultDarkShade = new StringBuffer("#CF8948");
			lightShade = new StringBuffer(defaultLightShade.toString());
			darkShade = new StringBuffer(defaultDarkShade.toString());
			this.squareSize = 54;
			flipPiecesOnBoardFlip = false;
			flipView = false;
			createBoard();
		} else {
			String[] lines = newPresetText.split("\n");
			for (int i = 0; i < lines.length; ++i) {
				lines[i] = lines[i].replaceAll("\\s", "");
			}

			int files = 8; // default keyword values
			int ranks = 8;
			int holdingsType = 0;
			boolean enableDrops = false;
			int maxPromote = 1;
			int promoZone = 1;
			int promoOffset = 0;
			StringBuffer promoChoice = new StringBuffer("QRBN");
			int forcePromotions = 0;
			StringBuffer graphicsDir = new StringBuffer("/chess/");
			boolean useGIFImages = false;
			StringBuffer whitePrefix = new StringBuffer("w");
			StringBuffer blackPrefix = new StringBuffer("b");
			StringBuffer lightShade = new StringBuffer("#FFCC9C");
			StringBuffer darkShade = new StringBuffer("#CF8948");
			StringBuffer holeColor = new StringBuffer("#000000");
			StringBuffer holeBorderColor = new StringBuffer("#FFFFFF");
			boolean shogiMode = false;
			boolean flipPiecesOnBoardFlip = false;
			StringBuffer shades = new StringBuffer("");
			StringBuffer symmetry = new StringBuffer("mirror");
			int squareSize = 54;

			StringBuffer selectedPieceColor = new StringBuffer("#80FF80");
			StringBuffer lastMoveColor = new StringBuffer("#00FF00");
			StringBuffer lastLocustCaptureColor = new StringBuffer("#FFC000");
			StringBuffer moveColor = new StringBuffer("#FFFF00");
			StringBuffer captureColor = new StringBuffer("#FF0000");
			StringBuffer destroyColor = new StringBuffer("#0000FF");
			StringBuffer locustCaptureColor = new StringBuffer("#00FFFF");

			int nPieces = lines.length; // initialize piece list length

			for (int i = 0; i < lines.length; ++i) // find number of keywords
			{
				if (lines[i].contains("=")) {
					--nPieces;
				}
			}

			int[] royal = new int[nPieces];
			boolean[] contagious = new boolean[nPieces];

			String[] names = new String[nPieces];
			String[] ids = new String[nPieces];
			String[] moves = new String[nPieces];
			String[] images = new String[nPieces];
			String[] startSquares = new String[nPieces];
			StringBuffer holeSquares = new StringBuffer("");

			int pieceCounter = 0;

			for (int i = 0; i < lines.length; ++i) // keywords
			{
				if (lines[i].contains("=")) // keyword setters always contain "=", but
				{
					String[] keywords = lines[i].split("=");
					if (keywords[0].equals("files")) {
						try {
							files = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							files = 8;
						}
						if (files < 1 || files > 26) {
							Init("default");
							return;
						}
					} else if (keywords[0].equals("ranks")) {
						try {
							ranks = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							ranks = 8;
						}
						if (ranks < 1 || ranks > 26) {
							Init("default");
							return;
						}
					} else if (keywords[0].equals("holdingsType")) {
						try {
							holdingsType = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							holdingsType = 0;
						}
					} else if (keywords[0].equals("enableDrops")) {
						enableDrops = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("maxPromote")) {
						try {
							maxPromote = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							maxPromote = 1;
						}
					} else if (keywords[0].equals("promoZone")) {
						try {
							promoZone = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							promoZone = 1;
						}
					} else if (keywords[0].equals("promoOffset")) {
						try {
							promoOffset = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							promoOffset = 0;
						}
					} else if (keywords[0].equals("promoChoice")) {
						promoChoice = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("forcePromotions")) {
						try {
							forcePromotions = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							forcePromotions = 0;
						}
					} else if (keywords[0].equals("graphicsDir")) {
						graphicsDir = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("useGIFImages")) {
						useGIFImages = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("whitePrefix")) {
						whitePrefix = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("blackPrefix")) {
						blackPrefix = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("lightShade")) {
						if (checkColorFormat(keywords[1])) {
							lightShade = new StringBuffer(keywords[1]);
						} else {
							lightShade = new StringBuffer("#FFCC9C");
						}
					} else if (keywords[0].equals("darkShade")) {
						if (checkColorFormat(keywords[1])) {
							darkShade = new StringBuffer(keywords[1]);
						} else {
							darkShade = new StringBuffer("#CF8948");
						}
					} else if (keywords[0].equals("holeColor")) {
						if (checkColorFormat(keywords[1])) {
							holeColor = new StringBuffer(keywords[1]);
						} else {
							holeColor = new StringBuffer("#000000");
						}
					} else if (keywords[0].equals("holeBorderColor")) {
						if (checkColorFormat(keywords[1])) {
							holeBorderColor = new StringBuffer(keywords[1]);
						} else {
							holeBorderColor = new StringBuffer("#FFFFFF");
						}
					} else if (keywords[0].equals("shades")) {
						shades = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("selectedPieceColor")) {
						if (checkColorFormat(keywords[1])) {
							selectedPieceColor = new StringBuffer(keywords[1]);
						} else {
							selectedPieceColor = new StringBuffer("#80FF80");
						}
					} else if (keywords[0].equals("lastMoveColor")) {
						if (checkColorFormat(keywords[1])) {
							lastMoveColor = new StringBuffer(keywords[1]);
						} else {
							lastMoveColor = new StringBuffer("#00FF00");
						}
					} else if (keywords[0].equals("lastLocustCaptureColor")) {
						if (checkColorFormat(keywords[1])) {
							lastLocustCaptureColor = new StringBuffer(keywords[1]);
						} else {
							lastLocustCaptureColor = new StringBuffer("#FFC000");
						}
					} else if (keywords[0].equals("moveColor")) {
						if (checkColorFormat(keywords[1])) {
							moveColor = new StringBuffer(keywords[1]);
						} else {
							moveColor = new StringBuffer("#FFFF00");
						}
					} else if (keywords[0].equals("captureColor")) {
						if (checkColorFormat(keywords[1])) {
							captureColor = new StringBuffer(keywords[1]);
						} else {
							moveColor = new StringBuffer("#FF0000");
						}
					} else if (keywords[0].equals("destroyColor")) {
						if (checkColorFormat(keywords[1])) {
							destroyColor = new StringBuffer(keywords[1]);
						} else {
							destroyColor = new StringBuffer("#0000FF");
						}
					} else if (keywords[0].equals("locustCaptureColor")) {
						if (checkColorFormat(keywords[1])) {
							locustCaptureColor = new StringBuffer(keywords[1]);
						} else {
							locustCaptureColor = new StringBuffer("#00FFFF");
						}
					} else if (keywords[0].equals("shogiMode")) {
						shogiMode = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("flipPiecesOnBoardFlip")) {
						flipPiecesOnBoardFlip = Boolean.parseBoolean(keywords[1]);
					} else if (keywords[0].equals("symmetry")) {
						symmetry = new StringBuffer(keywords[1]);
					} else if (keywords[0].equals("squareSize")) {
						try {
							squareSize = Integer.parseInt(keywords[1]);
						} catch (NumberFormatException nfe) {
							squareSize = 54;
						}
					} else if (keywords[0].equals("royal")) {
						try {
							royal[(Integer.parseInt(keywords[1]) - 1)] = 1;
						} catch (NumberFormatException nfe) {
							continue;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							continue;
						}
					} else if (keywords[0].equals("iron")) {
						try {
							royal[(Integer.parseInt(keywords[1]) - 1)] = 2;
						} catch (NumberFormatException nfe) {
							continue;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							continue;
						}
					} else if (keywords[0].equals("contagious")) {
						try {
							contagious[(Integer.parseInt(keywords[1]) - 1)] = true;
						} catch (NumberFormatException nfe) {
							continue;
						} catch (ArrayIndexOutOfBoundsException aioobe) {
							continue;
						}
					} else {
						continue;
					}
				} else if (lines[i].contains(":")) {
					String[] parts = lines[i].split(":");
					if (parts.length < 4 || parts.length > 5) {
						if(parts.length == 2 && parts[0].equals("hole"))
						{
							holeSquares = new StringBuffer(parts[1]);
						}
						else
						{
							Init("default");
							return;
						}
					} else {
						for (int j = 0; j < 4; ++j) {
							if (parts[j] == "") {
								Init("default");
								return;
							}
						}
						
						if(!parts[1].matches(".*[a-zA-Z]+.*"))
						{
							Init("default");
							return;
						}
						
						for(int j = 0; j < nPieces; ++j)
						{
							if(parts[1].equals(ids[j]))
							{
								parts[1] = parts[1] + "*";
								j = -1;
							}
						}
						
						names[pieceCounter] = parts[0];
						ids[pieceCounter] = parts[1];
						moves[pieceCounter] = parts[2];
						images[pieceCounter] = parts[3];
						if(parts.length == 5)
						{
							if(parts[4] == null) {
								parts[4] = "";
							} else {
								startSquares[pieceCounter] = parts[4];
							}
						}
						++pieceCounter;
					}
				} else {
					Init("default");
					return;
				}
			}
			
			defaultSelectedPieceColor = selectedPieceColor;
			defaultLastMoveColor = lastMoveColor;
			defaultLastLocustCaptureColor = lastLocustCaptureColor;
			defaultMoveColor = moveColor;
			defaultCaptureColor = captureColor;
			defaultDestroyColor = destroyColor;
			defaultLocustCaptureColor = locustCaptureColor;
			
			this.selectedPieceColor = selectedPieceColor;
			this.lastMoveColor = lastMoveColor;
			this.lastLocustCaptureColor = lastLocustCaptureColor;
			this.moveColor = moveColor;
			this.captureColor = captureColor;
			this.destroyColor = destroyColor;
			this.locustCaptureColor = locustCaptureColor;

			this.defaultLightShade = new StringBuffer(lightShade.toString());
			this.lightShade = new StringBuffer(lightShade.toString());
			this.defaultDarkShade = new StringBuffer(darkShade.toString());
			this.darkShade = new StringBuffer(darkShade.toString());
			
			this.defaultHoleColor = new StringBuffer(holeColor.toString());
			this.holeColor = new StringBuffer(holeColor.toString());
			this.defaultHoleBorderColor = new StringBuffer(holeBorderColor.toString());
			this.holeBorderColor = new StringBuffer(holeBorderColor.toString());
			
			this.shogiMode = shogiMode;
			this.flipPiecesOnBoardFlip = flipPiecesOnBoardFlip;
			this.squareSize = squareSize;

			createBoard(files, ranks, nPieces, graphicsDir.toString(), whitePrefix.toString(), blackPrefix.toString(),
					useGIFImages);
			board.startPosition();

			for (int i = 0; i < nPieces; ++i) {
				try {
					pieceList.addPiece(i + 1, names[i], ids[i], moves[i], images[i]);
				} catch (NullPointerException npe) {
					continue;
				}
			}

			if (!symmetry.toString().equals("none") && !symmetry.toString().equals("rotate") && !symmetry.toString().equals("mirror")) {
				symmetry = new StringBuffer("none");
			}
			
			if(!holeSquares.toString().equals(""))
			{
				String holeSquaresStr = expandStartCoordRegions(holeSquares.toString());
				String[] holeSquareCoords = holeSquaresStr.split(",");
				for (int i = 0; i < holeSquareCoords.length; ++i) {
					Pattern validHoleCoordFormat1 = Pattern.compile("([a-z]{1}[0-9]{1})");
					Pattern validHoleCoordFormat2 = Pattern.compile("([a-z]{1}[0-9]{2})");
					Matcher m1 = validHoleCoordFormat1.matcher(holeSquareCoords[i]);
					Matcher m2 = validHoleCoordFormat2.matcher(holeSquareCoords[i]);
					if(m1.matches() || m2.matches())
					{
						char file = holeSquareCoords[i].charAt(0);
						String rank = holeSquareCoords[i].substring(1);
						int holeFileID = fileID(file, false);
						int holeRankID = rankID(rank, false);
						board.setVirginPieceOnSquare(holeFileID, holeRankID, -1);
					}
				}
			}

			for (int i = 0; i < nPieces; ++i) {
				if (startSquares[i] == null) {
					continue;
				}
				boolean isBlackStartCoords = false;
				String startSquaresStr = expandStartCoordRegions(startSquares[i]);
				String[] startSquareCoords = startSquaresStr.split(",");
				for (int j = 0; j < startSquareCoords.length; ++j) {
					if (startSquareCoords[j].equals("")) {
						isBlackStartCoords = true;
					} else {
						Pattern validCoordFormat1 = Pattern.compile("([a-z]{1}[0-9]{1})");
						Pattern validCoordFormat2 = Pattern.compile("([a-z]{1}[0-9]{2})");
						Matcher m1 = validCoordFormat1.matcher(startSquareCoords[j]);
						Matcher m2 = validCoordFormat2.matcher(startSquareCoords[j]);
						if(m1.matches() || m2.matches())
						{
							char file = startSquareCoords[j].charAt(0);
							String rank = startSquareCoords[j].substring(1);
							int wFileID = fileID(file, false);
							int wRankID = rankID(rank, false);
							int bFileID = files - 1 - fileID(file, false);
							int bRankID = ranks - 1 - rankID(rank, false);
							int wPiece = i + 1;
							int bPiece = i + 1 + nPieces;
							if(symmetry.toString().equals("mirror"))
							{
								board.setVirginPieceOnSquare(wFileID, wRankID, wPiece);
								board.setVirginPieceOnSquare(wFileID, bRankID, bPiece);
							}
							if(symmetry.toString().equals("rotate"))
							{
								board.setVirginPieceOnSquare(wFileID, wRankID, wPiece);
								board.setVirginPieceOnSquare(bFileID, bRankID, bPiece);
							}
							if(symmetry.toString().equals("none"))
							{
								if(isBlackStartCoords)
								{
									board.setVirginPieceOnSquare(wFileID, wRankID, bPiece);
								}
								else
								{
									board.setVirginPieceOnSquare(wFileID, wRankID, wPiece);
								}
							}
						}
					}
				}
			}

			board.setHoldingsType(holdingsType);
			board.setEnableDrops(enableDrops);
			board.setMaxPromotingPieces(maxPromote);
			board.setPromotionZone(promoZone);
			board.setPromotionOffset(promoOffset);
			board.setPromotionChoice(promoChoice.toString());
			board.setForcePromotions(forcePromotions);
			board.setStartPosition();
			board.AddMove(-1, -1, null, null, -1, -1, -1);

			boolean hasRoyal = false; // flag to determine if board has at least one royal
			for (int i = 0; i < royal.length && hasRoyal == false; ++i) // check if a royal piece exists
			{
				if (royal[i] == 1) {
					hasRoyal = true;
				}
			}
			if (hasRoyal == false) // if no royal pieces are defined, set last non-iron piece as royal piece
			{
				for (int i = royal.length - 1; i > 0 && hasRoyal == false; --i) {
					if (royal[i] == 0) {
						royal[i] = 1;
						hasRoyal = true;
					}
				}
				if (hasRoyal == false) // if all else fails set last piece as royal piece over preset specifications
				{
					royal[royal.length - 1] = 1;
				}
			}
			
			for(int i = 0; i < contagious.length; ++i) // set contagious pieces
			{
				pieceList.setContagious(i + 1, contagious[i]);
			}

			flipView = false;

			if(!shades.toString().equals(""))
			{
				defineShades(shades.toString());
			}
			else
			{
				defineShades("");
			}
			Display(false);
		}
		ResetEvents(true);
		preset = new StringBuffer(newPresetText);
		mainVBox = new VBox(menuHBox, boardPane);
		mainVBox.setAlignment(Pos.TOP_CENTER);
		mainVBox.setSpacing(0.0);
		boardScene = new Scene(mainVBox);
		boardStage.setScene(boardScene);
	}
	
	public String expandStartCoordRegions(String startCoordsList)
	{
		if(!startCoordsList.contains("-"))
		{
			return startCoordsList;
		}
		String[] startCoords = startCoordsList.split(",");
		for(int i = 0; i < startCoords.length; ++i)
		{
			Pattern validCoordFormat1 = Pattern.compile("([a-z]{1}[0-9]{1})-([a-z]{1}[0-9]{1})");
			Pattern validCoordFormat2 = Pattern.compile("([a-z]{1}[0-9]{1})-([a-z]{1}[0-9]{2})");
			Pattern validCoordFormat3 = Pattern.compile("([a-z]{1}[0-9]{2})-([a-z]{1}[0-9]{1})");
			Pattern validCoordFormat4 = Pattern.compile("([a-z]{1}[0-9]{2})-([a-z]{1}[0-9]{2})");
			Matcher m1 = validCoordFormat1.matcher(startCoords[i]);
			Matcher m2 = validCoordFormat2.matcher(startCoords[i]);
			Matcher m3 = validCoordFormat3.matcher(startCoords[i]);
			Matcher m4 = validCoordFormat4.matcher(startCoords[i]);
			
			if(m1.matches() || m2.matches())
			{
				char startFileChar = startCoords[i].charAt(0);
				String startRankStr = startCoords[i].substring(1, 2);
				
				char endFileChar = startCoords[i].charAt(3);
				String endRankStr = startCoords[i].substring(4);
				
				StringBuffer newStartCoordsBuffer = new StringBuffer();
				
				int startFile = fileID(startFileChar, false);
				int endFile = fileID(endFileChar, false);
				
				int startRank = Integer.parseInt(startRankStr);
				int endRank = Integer.parseInt(endRankStr);
				
				for(int j = startRank; j <= endRank; ++j)
				{
					for(int k = startFile; k <= endFile; ++k)
					{
						int fileNumber = k + 97;
						char file = (char)fileNumber;
						newStartCoordsBuffer.append(String.valueOf(file) + Integer.toString(j));
						if(j != endRank || k != endFile)
						newStartCoordsBuffer.append(",");
					}
				}
				startCoords[i] = newStartCoordsBuffer.toString();
			}
			
			if(m3.matches() || m4.matches())
			{
				char startFileChar = startCoords[i].charAt(0);
				String startRankStr = startCoords[i].substring(1, 3);
				
				char endFileChar = startCoords[i].charAt(4);
				String endRankStr = startCoords[i].substring(5);
				
				StringBuffer newStartCoordsBuffer = new StringBuffer();
				
				int startFile = fileID(startFileChar, false);
				int endFile = fileID(endFileChar, false);
				
				int startRank = Integer.parseInt(startRankStr);
				int endRank = Integer.parseInt(endRankStr);
				
				for(int j = startRank; j <= endRank; ++j)
				{
					for(int k = startFile; k <= endFile; ++k)
					{
						int fileNumber = k + 97;
						char file = (char)fileNumber;
						newStartCoordsBuffer.append(String.valueOf(file) + Integer.toString(j));
						if(j != endRank || k != endFile)
						newStartCoordsBuffer.append(",");
					}
				}
				startCoords[i] = newStartCoordsBuffer.toString();
			}
		}
		
		StringBuffer newStartCoords = new StringBuffer();
		
		for(int i = 0; i < startCoords.length; ++i)
		{
			newStartCoords.append(startCoords[i]);
			if(i < startCoords.length - 1)
			{
				newStartCoords.append(",");
			}
		}
		
		return newStartCoords.toString();
	}
	
	/**
	 * Shows the dialog for editing the board position with FEN Code
	 */
	public void showFENCodeDialog()
	{
		if(fenCodeStage.isShowing())
		{
			fenCodeStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Enter the desired position's FEN Code in the text area to the right.You can view the FEN Code of the current position on the left.\nWhen done, press Load FEN Code to load the position onto the board. This clears the game you have loaded.");
			
			Label currentFENStringLabel = new Label("Current Position's FEN Code");
			currentFENStringLabel.setStyle("-fx-underline:true");
			TextArea currentFENString = new TextArea();
			currentFENString.setEditable(false);
			currentFENString.setPrefHeight(250);
			currentFENString.setPrefColumnCount(30);
			currentFENString.setWrapText(true);
			currentFENString.setText(getFENCode());
			VBox currentFENStringVBox = new VBox(currentFENStringLabel, currentFENString);
			currentFENStringVBox.setAlignment(Pos.CENTER);
			currentFENStringVBox.setSpacing(10);
			
			Separator categorySeparator = new Separator(Orientation.VERTICAL);
			categorySeparator.setCenterShape(true);
			
			Label newFENStringLabel = new Label("New Position's FEN Code");
			newFENStringLabel.setStyle("-fx-underline:true");
			TextArea newFENString = new TextArea();
			newFENString.setPrefHeight(250);
			newFENString.setPrefColumnCount(30);
			newFENString.setWrapText(true);
			VBox newFENStringVBox = new VBox(newFENStringLabel, newFENString);
			newFENStringVBox.setAlignment(Pos.CENTER);
			newFENStringVBox.setSpacing(10);
			
			HBox fenCodeHBox = new HBox(currentFENStringVBox, categorySeparator, newFENStringVBox);
			fenCodeHBox.setAlignment(Pos.CENTER);
			fenCodeHBox.setSpacing(10);
			
			Label errorLabel = new Label("Error Text");
			errorLabel.setStyle("-fx-underline:true");
			
			TextArea errorText = new TextArea();
			errorText.setEditable(false);
			errorText.setPrefHeight(100);
			errorText.setPrefColumnCount(60);
			
			Button helpButton = new Button("Help");
			helpButton.setOnAction(e -> {
				showFENCodeHelp();
			});
			Button showRequirementsButton = new Button("Show FEN Code Requirements");
			showRequirementsButton.setOnAction(e -> {
				showFENCodeRequirements();
			});
			Button loadFENCodeButton = new Button("Load FEN Code");
			loadFENCodeButton.setOnAction(e -> {
				String errorString = loadFENCode(newFENString.getText());
				if(errorString != null)
				{
					errorText.setText(errorString);
				}
				else
				{
					fenCodeStage.close();
					disableBoardEvents = false;
				}
			});
			
			HBox buttonHBox = new HBox(helpButton, showRequirementsButton, loadFENCodeButton);
			buttonHBox.setAlignment(Pos.CENTER);
			buttonHBox.setSpacing(10);
			
			VBox fenCodeVBox = new VBox(instructionsLabel, fenCodeHBox, errorLabel, errorText, buttonHBox);
			fenCodeVBox.setAlignment(Pos.CENTER);
			fenCodeVBox.setSpacing(10);
			fenCodeVBox.setPadding(new Insets(10));
			
			Scene fenCodeScene = new Scene(fenCodeVBox);
			fenCodeStage = new Stage();
			fenCodeStage.setScene(fenCodeScene);
			fenCodeStage.setTitle("Load Position from FEN String");
			fenCodeStage.setOnCloseRequest(e -> {
				disableBoardEvents = false;
				fenCodeRequirementsStage.close();
			});
			fenCodeStage.show();
		}
	}
	
	/**
	 * Shows help section for the FEN Code 
	 */
	public void showFENCodeHelp()
	{
		if(fenCodeHelpStage.isShowing())
		{
			fenCodeHelpStage.requestFocus();
		}
		else
		{
			StringBuffer fenHelp = new StringBuffer();
			
			String newLine = "\n\n";
			
			String intro = "FEN Code";
			fenHelp.append(intro + newLine);
			
			String expo = "Forsythe-Edwards Notation (FEN for short) is a system that provides a way to store board positions in a compact string (called a FEN code or FEN string). Although it was originally designed to describe positions in chess games, the system can naturally be expanded to describe positions for many more games as well. In fact, FEN can be used to support any chess variant with any number of pieces and a finite board size, so long as each piece has a unique ID. The Universal Chessboard uses a FEN system similar to the original, but with a few tweaks that allow it to support as many chess variants as possible.";
			fenHelp.append(expo + newLine);

			String fenWorkingsTitle = "How FEN Code Works";
			fenHelp.append(fenWorkingsTitle + newLine);
			
			String fenWorkings = "The extended FEN Code used by the Universal Chessboard works with any finite board size, not just an 8x8 board. However, FEN strings are unique to the game they came from, and cannot be used for other games unless they have the same board size, the same number of piece types, and the same collection of piece IDs. The piece type that an ID points to is irrelevant, but it must be unique, point to a specific (color-independent) piece type, and have at least one English letter. Additionally, all letters in an ID must have the same case. The case of the letter determines the piece's color. Usually, uppercase IDs point to white pieces, and lowercase to black pieces. However, having the line 'shogiMode=true' in the preset file makes the opposite true.";
			fenHelp.append(fenWorkings + newLine);
			
			String fenIDs = "This FEN system also allows for more pieces than those found in chess. Aside from the 26 piece types possible with single English letters, IDs consisting of multiple characters are also supported. The parser treats such IDs are implemented by enclosing them in a set of curly brackets (Ex. {+P}). Because of this, curly brackets cannot be used as part of a piece ID. Any other character may be used, and IDs inside the curly brackets can have any number of characters, as long as one of them is an English letter.";
			fenHelp.append(fenIDs + newLine);
			
			String fenParser = "The Universal Chessboard's FEN Parser";
			fenHelp.append(fenParser + newLine);
			
			String boardToFEN = "As a whole, the FEN string describing each position is in a left-to-right, top-to-bottom order from White's perspective. When getting a FEN string from the current board position, the parser begins by describing the leftmost square in rank (number of ranks - 1). This is the top left space on a rectangular board. It then continues to describe the board one rank at a time, separating each rank in the string with slashes, until it finishes with rank 0. For example, the parser describes the starting position in a chess game like this:\nrnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";
			fenHelp.append(boardToFEN + newLine);
			
			String fenToBoard = "Loading a board position from a FEN String is a much more complicated process. When doing this, the parser creates a specialized buffer and stores the new position there as it is created, performing rigorous error checks on every part of the FEN string. The position on the actual board does not change unless there are no errors in the FEN string. If no errors are detected, the new position is copied from the buffer to the string. The game log for currently loaded game is cleared afterward to prevent it from being corrupted by the position change.";
			fenHelp.append(fenToBoard + newLine);
			
			String fenSystem = "The Universal Chessboard's FEN System";
			fenHelp.append(fenSystem + newLine);
			
			String fenChars = "Here is a summary of the characters used in the FEN Code:";
			fenHelp.append(fenChars + newLine);
			
			String slashes = "Slashes: / - These separate individual ranks in the FEN string. In order to be considered valid, the FEN String must contain (number of ranks - 1) slashes that aren't part of an ID enclosed in curly brackets.";
			fenHelp.append(slashes + newLine);
			
			String numbers = "Any base-10 number N - represents a series of N empty squares. Minus signs (-) are not treated as part of the number.";
			fenHelp.append(numbers + newLine);
			
			String letters = "Any English letter: a-z or A-Z -> These are the key ingredients of any piece ID. Single letters by themselves can be used as piece IDs in the FEN string, or they can be joined with other characters in an ID enclosed in curly brackets.";
			fenHelp.append(letters + newLine);
			
			String minusSign = "Minus Sign: - -> Indicates a hole in the board. Holes are spaces on the board that do not exist. Because of this, they cannot be moved to, nor can they be moved through unless the moving piece is jumping over the hole.";
			fenHelp.append(minusSign + newLine);
			
			String curlyBrackets = "Curly Brackets: {} -> These enclose a piece ID that contains multiple characters. They are not considered a part of the ID itself, and because of this, they cannot be used as part of a piece ID. Note that there must be a closing curly bracket for every opening curly bracket in a FEN rank. An InvalidCurlyBracketException is thrown if unbalanced curly brackets are found or a curly bracket is used as part of a piece ID.";
			fenHelp.append(curlyBrackets + newLine);
			
			String emptyString = "Empty String -> This is a shortcut for indicating an empty rank regardless of the number of files the board has. Note that an empty string has no characters in it. so if you wanted an empty board, you could simply enter a series of slashes (\"///////\" for chess).";
			fenHelp.append(emptyString + newLine);
			
			String fenRulesTitle = "Rules";
			fenHelp.append(fenRulesTitle + newLine);
			
			String fenRules = "The Universal Chessboard's FEN system has a few rules that every FEN string must follow:";
			fenHelp.append(fenRules + newLine);
			
			String fenRule1 = "1. The FEN string cannot be an empty string. The parser throws a NullFENCodeException when this rule is violated.";
			fenHelp.append(fenRule1 + newLine);
			
			String fenRule2 = "2. The number of ranks in the FEN string must be equal to the number of ranks on the board (nRanks). Because of this, at the very least, it must have exactly (nRanks - 1) slashes that aren't part of a piece ID. Otherwise, a RanksOutOfBoundsException is thrown.";
			fenHelp.append(fenRule2 + newLine);
			
			String fenRule3 = "3. No rank in the FEN string can have a square count less than or equal to the number of files on the board (nFiles). No rank can have a square count greater than that number. The square count is the sum of all (positive) numbers, the number of piece IDs, and the number of minus signs in the FEN rank (Ex. The square count for the FEN rank \"-2p{+p}p2-\" is 2 + 2 + (2 * '-') + (2 * 'p') + (1 * '{+p}') = 9). If one rank violates this rule, a FileOutOfBoundsException is thrown. If multiple ranks violate this rule, a FilesOutOfBoundsException is thrown.";
			fenHelp.append(fenRule3 + newLine);
			
			String fenRule4 = "4. Slashes, base-10 numbers, English Letters, and minus signs are the only characters that can appear by themselves. All other characters must either enclose a piece ID (curly brackets) or be used as part of a piece ID with multiple characters. An InvalidCharException is thrown if this rule is broken.";
			fenHelp.append(fenRule4 + newLine);
			
			String fenRule5 = "5. All piece IDs that appear in the FEN string must be valid piece IDs for the game the FEN string is being used for, and IDs with multiple characters must be enclosed in a set of curly brackets. If an invalid ID is found, an InvalidPieceIDException is thrown.";
			fenHelp.append(fenRule5 + newLine);
			
			String fenExceptions = "FEN Code Exceptions";
			fenHelp.append(fenExceptions + newLine);
			
			String fenExceptionsIntro = "FEN Code Exceptions are 'exceptions' thrown by the parser when it detects an error in the FEN string it is trying to load. (Note that these are not programming exceptions, but rather strings that the parser uses to populate the error text box). They give a brief explanation of what went wrong. Some exceptions also show which instances of themselves were trigger or where the error occurs in the FEN String. The parser always exits the loading process without doing anything whenever an exception occurs. This means that if you fix one area of your code, you may encounter other errors that need to be fixed before the code can be successfully loaded. Below is a summary of all exceptions thrown by the parser.";
			fenHelp.append(fenExceptionsIntro + newLine);
			
			String fenExceptionsLegend = "Legend for Values in Parentheses\nInstance - The instance number of this exception, ranging from 0 to (number of identical exceptions - 1). Larger numbers occur later on in the loading process, and vice versa.\nRank N - The Nth FEN rank from the beginning (top-left) of the FEN string contains this error.\nCharacter N - The Nth character from the left of the FEN rank is causing this error.";
			fenHelp.append(fenExceptionsLegend + newLine);
			
			String fenException1 = "NullFENCodeException - Occurs when an empty string is passed to the parser.";
			fenHelp.append(fenException1 + newLine);
			
			String fenException2 = "RanksOutOfBoundsException(Instance) - Occurs when the number of ranks in the FEN String isn't the same as the number of ranks on the board.";
			fenHelp.append(fenException2 + newLine);
			
			String fenException3 = "FileOutOfBoundsException - Occurs when a single rank in the FEN String has more files than the number of files on the board. This exception indicates the erronous rank with the Rank N value from the Legend for Values in Parentheses.";
			fenHelp.append(fenException3 + newLine);
			
			String fenException4 = "FilesOutOfBoundsException - Occurs when multiple ranks have more files than the number of files on the board. This exception indicates the erronous ranks with a comma-separated list of Rank N values from the Legend for Values in Parentheses.";
			fenHelp.append(fenException4 + newLine);
			
			String fenException5 = "InvalidCurlyBracketException(Rank N, Character N) - Occurs when a curly bracket ({ or }) isn't being used in the way it should be.";
			fenHelp.append(fenException5 + newLine);
			
			String fenException6 = "InvalidCharException(Rank N, Character N) - Occurs when a character other than a slash, English letter of either case, base-10 digit, or minus sign appears in the FEN string without being part of a valid piece ID, indicating the character that caused this error.";
			fenHelp.append(fenException6 + newLine);
			
			String fenException7 = "InvalidPieceIDException(Instance) - Occurs when an invalid piece ID is encountered, indicating the piece ID that caused this error.";
			fenHelp.append(fenException7);
			
			TextArea fenCodeHelpText = new TextArea(fenHelp.toString());
			fenCodeHelpText.setWrapText(true);
			fenCodeHelpText.setEditable(false);
			fenCodeHelpText.setPrefHeight(300);
			fenCodeHelpText.setPrefColumnCount(40);
			
			Scene fenCodeHelpScene = new Scene(fenCodeHelpText);
			fenCodeHelpStage = new Stage();
			fenCodeHelpStage.setScene(fenCodeHelpScene);
			fenCodeHelpStage.sizeToScene();
			fenCodeHelpStage.setTitle("Help - FEN Code");
			fenCodeHelpStage.show();
		}
	}
	
	/**
	 * Shows the FEN string requirements for the current game.
	 */
	public void showFENCodeRequirements()
	{
		if(fenCodeRequirementsStage.isShowing())
		{
			fenCodeRequirementsStage.requestFocus();
		}
		else
		{
			Label rankRequirement = new Label("Required number of ranks: " + nRanks);
			rankRequirement.setWrapText(true);	
			Label fileRequirement = new Label("Maximum number of squares in each rank: " + nFiles);
			fileRequirement.setWrapText(true);	
			
			GridPane pieceMap = new GridPane();
			
			Label pieceMapHeaderLabel1 = new Label(" White ID ");
			StackPane pieceMapHeader1 = new StackPane(pieceMapHeaderLabel1);
			pieceMapHeader1.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			Label pieceMapHeaderLabel2 = new Label(" White Image ");
			StackPane pieceMapHeader2 = new StackPane(pieceMapHeaderLabel2);
			pieceMapHeader2.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			Label pieceMapHeaderLabel3 = new Label(" Black ID ");
			StackPane pieceMapHeader3 = new StackPane(pieceMapHeaderLabel3);
			pieceMapHeader3.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			Label pieceMapHeaderLabel4 = new Label(" Black Image ");
			StackPane pieceMapHeader4 = new StackPane(pieceMapHeaderLabel4);
			pieceMapHeader4.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
			
			pieceMap.add(pieceMapHeader1, 0, 0);
			pieceMap.add(pieceMapHeader2, 1, 0);
			pieceMap.add(pieceMapHeader3, 2, 0);
			pieceMap.add(pieceMapHeader4, 3, 0);
			for(int i = 1; i <= pieceList.getNPieceTypes(); ++i)
			{
				StringBuffer pieceID = new StringBuffer(pieceList.getPiece(i).getPieceID());
				String wID;
				String bID;
				if(pieceID.length() > 1)
				{
					pieceID = new StringBuffer("{" + pieceID + "}");
				}
				if(shogiMode)
				{
					wID = pieceID.toString().toLowerCase();
					bID = pieceID.toString().toUpperCase();
				}
				else
				{
					wID = pieceID.toString().toUpperCase();
					bID = pieceID.toString().toLowerCase();
				}
				
				ImageView wPieceImage = pieceList.getPieceImage(i);
				ImageView bPieceImage = pieceList.getPieceImage(i + pieceList.getNPieceTypes());
				
				Label wPieceLabel = new Label(wID);
				StackPane wPieceID = new StackPane(wPieceLabel);
				wPieceID.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				StackPane wPiece = new StackPane(wPieceImage);
				wPiece.setMinSize(squareSize, squareSize);
				wPiece.setPrefSize(squareSize, squareSize);
				wPiece.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				Label bPieceLabel = new Label(bID);
				StackPane bPieceID = new StackPane(bPieceLabel);
				bPieceID.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				StackPane bPiece = new StackPane(bPieceImage);
				bPiece.setMinSize(squareSize, squareSize);
				bPiece.setPrefSize(squareSize, squareSize);
				bPiece.setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				
				pieceMap.add(wPieceID, 0, i);
				pieceMap.add(wPiece, 1, i);
				pieceMap.add(bPieceID, 2, i);
				pieceMap.add(bPiece, 3, i);
			}
			
			pieceMap.setPadding(new Insets(0));
			pieceMap.setHgap(0);
			pieceMap.setVgap(0);
			
			VBox fencodeRequirementsVBox = new VBox(rankRequirement, fileRequirement, pieceMap);
			fencodeRequirementsVBox.setAlignment(Pos.CENTER);
			fencodeRequirementsVBox.setSpacing(10);
			ScrollPane fenScrollPane = new ScrollPane();
			fenScrollPane.fitToWidthProperty().set(true);
			fenScrollPane.fitToHeightProperty().set(true);
			fenScrollPane.hbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
			fenScrollPane.vbarPolicyProperty().setValue(ScrollPane.ScrollBarPolicy.AS_NEEDED);
			fenScrollPane.setPadding(new Insets(0));
			fenScrollPane.setContent(fencodeRequirementsVBox);
			StackPane fenPane = new StackPane(fenScrollPane); //!-!
			Window window = boardScene.getWindow();
			double titleBarSize = window.getHeight() - boardScene.getHeight() - 10;
			viewingScreen = new ViewingScreen();
			double fenReqWidth = Math.min(Math.min(rankRequirement.getPrefWidth(), rankRequirement.getPrefWidth()), pieceMap.getPrefWidth());
			double fenReqHeight = squareSize * nRanks + 2;
			double width = viewingScreen.getScreenWidth();
			double height = viewingScreen.getScreenHeight() - boardMenu.getHeight() - titleBarSize;
			if(fenReqWidth > width)
			{
				fenPane.setPrefWidth(width);
			}
			else
			{
				fenPane.setPrefWidth(fenReqWidth);
			}
			if(fenReqHeight > height)
			{
				fenPane.setPrefHeight(height);
			}
			else
			{
				fenPane.setPrefHeight(fenReqHeight);
			}
			Scene fenCodeRequirementsScene = new Scene(fenPane);
			
			fenCodeRequirementsStage = new Stage();
			fenCodeRequirementsStage.setScene(fenCodeRequirementsScene);
			fenCodeRequirementsStage.setTitle("FEN Code Requirements");
			fenCodeRequirementsStage.show();
		}
	}
	
	/**
	 * Gets the FEN String of the current position.
	 */
	public String getFENCode()
	{
		StringBuffer fenCode = new StringBuffer();

		for(int i = nRanks - 1; i >= 0; --i)
		{
			int emptySquares = 0;
			for(int j = 0; j < nFiles; ++j)
			{
				int piece = board.getPieceOnSquare(j, i);
				if(piece == -1) {
					if(emptySquares > 0)
					{
						fenCode.append(Integer.toString(emptySquares));
						emptySquares = 0;
			        }
					fenCode.append("-");
					emptySquares = 0;
				}
				else if(piece == 0) {
					++emptySquares;
				}
				else
				{
					if(emptySquares > 0)
					{
						fenCode.append(Integer.toString(emptySquares));
						emptySquares = 0;
			        }
					String pieceID = pieceList.getPiece(piece).getPieceID();
					String fenID;
					if(shogiMode)
					{
						if(piece <= board.getNPieceTypes())
						{
							fenID = pieceID.toLowerCase();
						}
						else
						{
							fenID = pieceID.toUpperCase();
						}
					}
					else
					{
						if(piece > board.getNPieceTypes())
						{
							fenID = pieceID.toLowerCase();
						}
						else
						{
							fenID = pieceID.toUpperCase();
						}
					}
					if(fenID.length() > 1)
					{
						fenCode.append("{" + fenID + "}");
					}
					else
					{
						fenCode.append(fenID);
					}
			    }
			}
		    if(emptySquares > 0) {
		    	fenCode.append(Integer.toString(emptySquares));
		    	emptySquares = 0;
		    }
		    if(i > 0) {
		    	fenCode.append("/");
		    }
		}
		return fenCode.toString();
	}
	
	/**
	 * Loads a position on the board from a FEN String and</br>
	 * Clears the game that is currently loaded. This</br>
	 * method performs rigorous error checking before</br>
	 * loading the position on the board. If the FEN String</br>
	 * contains any errors, it instead returns an error</br>
	 * message indicating what when wrong.
	 * @param code the FEN String from which to load the new board position
	 */
	public String loadFENCode(String fenString)
	{
		fenString = fenString.replaceAll("\\s", "");
		if(fenString.equals("")) // exit early if string is empty
		{
			String nullFENError = "NullFENCodeException: Cannot load a null FEN string. Enter " + (nRanks - 1) + " slashes for an empty board.";
			return nullFENError;
		}
		
		StringBuffer fenStringBuffer = new StringBuffer(fenString);
		int fenBufferPos = 0;
		if(fenString.charAt(0) == '/')
		{
			fenStringBuffer.insert(0, Integer.toString(nFiles));
			fenBufferPos += Integer.toString(nFiles).length() + 1;
		}
		else
		{
			++fenBufferPos;
		}
		
		for(int i = 0; i < fenString.length() - 1; ++i)
		{
			if(fenString.charAt(i) == '/' && fenString.charAt(i + 1) == '/')
			{
				fenStringBuffer.insert(fenBufferPos, Integer.toString(nFiles));
				fenBufferPos += Integer.toString(nFiles).length() + 1;
			}
			else
			{
				++fenBufferPos;
			}
		}
		
		if(fenString.charAt(fenString.length() - 1) == '/')
		{
			fenStringBuffer.append(Integer.toString(nFiles));
		}
		
		String fenCode = fenStringBuffer.toString();
		
		String[] ranks = fenCode.split("/"); // split into individual ranks
		if(ranks.length > nRanks) // ensure number of ranks is correct
		{
			return "RanksOutOfBoundsException(0): The given FEN String has too many ranks. Number of ranks required: " + nRanks + ".";
		}
		else if(ranks.length < nRanks)
		{
			return "RanksOutOfBoundsException(1): The given FEN String has too few ranks. Number of ranks required: " + nRanks + ".";
		}
		
		int rankOverflow = 0; // detect if a file is too large
		ArrayList<String> overflowingRanks = new ArrayList<String>();
		
		for(int i = 0; i < ranks.length; ++i) // get all numbers in rank
		{
			if(ranks[i].equals(""))
			{
				continue;
			}
			ArrayList<String> numbers = new ArrayList<String>(); // create ArrayList for numbers
			Pattern p = Pattern.compile("\\d+");
			Matcher m = p.matcher(ranks[i]);
			while(m.find())
			{
				numbers.add(m.group());
			}
			
			int rankLength = 0; // keep track of rank length
			int numberN = 0; // keep track of current number
			int index = 0; // keep track of read position
			
			while(index < ranks[i].length()) // loop through all characters in rank string
			{
				if(ranks[i].charAt(index) >= '0' && ranks[i].charAt(index) <= '9')
				{
					rankLength += Integer.parseInt(numbers.get(numberN)); // add number to rank length
					index += numbers.get(numberN).length(); // advance past the number
					++numberN; // increment counter for next match
				}
				else if(ranks[i].charAt(index) == '-') // hole in board
				{
					++rankLength;
					++index;
				}
				else if(ranks[i].charAt(index) >= 'A' && ranks[i].charAt(index) <= 'Z') // uppercase letters
				{
					++rankLength;
					++index;
				}
				else if(ranks[i].charAt(index) >= 'a' && ranks[i].charAt(index) <= 'z') // lowercase letters
				{
					++rankLength;
					++index;
				}
				else if(ranks[i].charAt(index) == '{') // piece ID enclosed in curly brackets
				{
					++rankLength;
	    			int endPosition = ranks[i].indexOf("}", index);
	    			if(endPosition == -1) // exit if no closing curly bracket is found
	    			{
	    				return "InvalidCurlyBracketException(" + i + ", " + index + "): There must be a closing curly bracket for every opening curly bracket in a FEN rank.";
	    			}
	    			else // exit if unbalanced curly brackets are found
	    			{
	    				for(int j = index + 1; j < endPosition; ++j)
	    				{
	    					if(ranks[i].charAt(j) == '{')
	    					{
	    						return "InvalidCurlyBracketException(" + i + ", " + j + "): Opening curly brackets cannot be used as part of a piece ID.";
	    					}
	    				}
	    			}
	    			String pieceID = ranks[i].substring(index + 1, endPosition);
	    			index += pieceID.length() + 2;
				}
				else if(ranks[i].charAt(index) == '}') // exit if a closing curly brackets is not ending a piece ID with multiple characters
				{
					return "InvalidCurlyBracketException(" + i + ", " + index + "): Closing curly brackets cannot be used as part of a piece ID.";
				}
				else // exit if invalid character
				{
					return "InvalidCharException(" + i + ", " + index + "): The character '" + ranks[i].charAt(index) + "' cannot be used in a FEN String without being part of a valid piece ID.";
				}
			}
			if(rankLength > nFiles) // increment fileOverflow if rank is too large
			{
				++rankOverflow;
				overflowingRanks.add(0, Integer.toString(i));
			}
		}
		if(rankOverflow > 0)
		{
			StringBuffer rankOverflows = new StringBuffer();
			for(int i = overflowingRanks.size() - 1; i >= 0; --i)
			{
				rankOverflows.append(overflowingRanks.get(i));
				if(i > 0)
				{
					rankOverflows.append(", ");
				}
			}
			if(rankOverflow == 1)
			{
				return "FileOutOfBoundsException: 1 rank (" + rankOverflows.toString() + ") in the FEN String has too many files. Max. number of files: " + nFiles + ".";
			}
			else
			{
				return "FilesOutOfBoundsException: " + rankOverflow + " ranks (" + rankOverflows.toString() + ") in the FEN String has too many files. Max. number of files: " + nFiles + ".";
			}
		}
		
		int[][] board2 = new int[nRanks][nFiles]; // buffer for new board position
		
		for(int y = nRanks - 1; y >= 0; --y) // loop through ranks (y-coordinate)
		{
			int rankString = nRanks - 1 - y; // corresponding FEN rank
			String fenRank = ranks[rankString];
			
			ArrayList<String> emptyRowsReg = new ArrayList<String>(); // create ArrayList for numbers
			Pattern p = Pattern.compile("\\d+");
			Matcher m = p.matcher(fenRank);
			while(m.find())
			{
				emptyRowsReg.add(m.group());
			}
			
			int x = 0; // x-coordinate
			int emptyRowN = 0; // keep track of number of empty rows
			int index = 0; // keep track of read position
			
			while(index < fenRank.length())
			{
				if(fenRank.charAt(index) >= '0' && fenRank.charAt(index) <= '9')
				{
					x += Integer.parseInt(emptyRowsReg.get(emptyRowN)); // advance past the empty squares
					index += emptyRowsReg.get(emptyRowN).length(); // advance past the number
					++emptyRowN; // increment counter for next match
				}
				else if(fenRank.charAt(index) == '-') // hole in board
				{
					board2[y][x] = -1; // make this square a hole
		            ++x; // advance to the next square in board rank
		            ++index; // advance to the next element in FEN rank
				}
				else if(fenRank.charAt(index) >= 'A' && fenRank.charAt(index) <= 'Z') // uppercase letters
				{
					String ID = Character.toString(fenRank.charAt(index)).toUpperCase(); // ID to search for
					int piece = idToPiece(ID); // search for piece
					if(piece < 0) // exit if piece is not supported
					{
						return "InvalidPieceIDException(0): The piece ID " + fenRank.charAt(index) + " is not supported.";
					}
					else
					{
						piece += (shogiMode) ? board.getNPieceTypes() : 0; // determine color
						board2[y][x] = piece; // put piece on board
						++x; // advance to the next square
						++index; // advance to the next element in FEN rank
					}
				}
				else if(fenRank.charAt(index) >= 'a' && fenRank.charAt(index) <= 'z') // lowercase letters
				{
					String ID = Character.toString(fenRank.charAt(index)).toUpperCase(); // ID to search for
					int piece = idToPiece(ID); // search for piece
					if(piece < 0) // exit if piece is not supported
					{
						return "InvalidPieceIDException(1): The piece ID " + fenRank.charAt(index) + " is not supported.";
					}
					else
					{
						piece += (shogiMode) ? 0 : (board.getNPieceTypes()); // determine color
						board2[y][x] = piece; // put piece on board
						++x; // advance to the next square
						++index; // advance to the next element in FEN rank
					}
				}
				else if(fenRank.charAt(index) == '{') // piece ID enclosed in curly brackets
				{
	    			int endPosition = fenRank.indexOf("}", index);
	    			String pieceID = fenRank.substring(index + 1, endPosition);
	    			if(pieceID.equals(pieceID.toUpperCase()))
	    			{
	    				int piece = idToPiece(pieceID);
						if(piece < 0) // exit if piece is not supported
						{
							return "InvalidPieceIDException(2): The piece ID " + fenRank.charAt(index) + " is not supported.";
						}
						else
						{
							piece += (shogiMode) ? board.getNPieceTypes() : 0; // determine color
							board2[y][x] = piece; // put piece on board
						}
	    			}
	    			else if(pieceID.equals(pieceID.toLowerCase()))
	    			{
	    				int piece = idToPiece(pieceID.toUpperCase());
						if(piece < 0) // exit if piece is not supported
						{
							return "InvalidPieceIDException(3): The piece ID " + fenRank.charAt(index) + " is not supported.";
						}
						else
						{
							piece += (shogiMode) ? 0 : board.getNPieceTypes(); // determine color
							board2[y][x] = piece; // put piece on board
						}
	    			}
	    			else
	    			{
	    				return "InvalidPieceIDException(4): The piece ID " + fenRank.charAt(index) + " is not supported.";
	    			}
					++x; // advance to the next square
					index += pieceID.length() + 2; // advance to the next element in FEN rank
				}
				else // catch if all other tests fail
				{
					return "InvalidPieceIDException(5): The piece ID " + fenRank.charAt(index) + " is not supported.";
				}
			}
		}
		
		for(int y = 0; y < nRanks; ++y)
		{
			for(int x = 0; x < nFiles; ++x)
			{
				board.setVirginPieceOnSquare(x, y, board2[y][x]); // set virgin piece on square
			}
		}
		newGame(false);
		
		Display(false); // update board display
		ResetEvents(true); // reset board events
		updateLastMoveSquares(-1, -1, null, null, -1, -1);
		return null;
	}
	
	public int idToPiece(String id)
	{
		String searchID = id.toUpperCase();
		for(int i = 1; i <= pieceList.getNPieceTypes(); ++i)
		{
			if(searchID.equals(pieceList.getPiece(i).getPieceID()))
			{
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * Flips the board display, preserving all highlights.
	 */
	public void flipBoard() {
		if (flipView) {
			flipView = false;
		} else {
			flipView = true;
		}
		Display(true);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
	}

	/**
	 * Resets the viewing size and position of the application.
	 */
	public void resetViewingSize() {
		Window window = boardScene.getWindow();
		double titleBarSize = window.getHeight() - boardScene.getHeight() - 10;
		viewingScreen = new ViewingScreen();
		int boardWidth = squareSize * nFiles + 2;
		int boardHeight = squareSize * nRanks + 2;
		double width = viewingScreen.getScreenWidth();
		double height = viewingScreen.getScreenHeight() - boardMenu.getHeight() - titleBarSize;
		if(boardWidth > width)
		{
			boardPane.setPrefWidth(width);
		}
		else
		{
			boardPane.setPrefWidth(boardWidth);
		}
		if(boardHeight > height)
		{
			boardPane.setPrefHeight(height);
		}
		else
		{
			boardPane.setPrefHeight(boardHeight);
		}
		boardStage.setMaximized(false);
		boardStage.sizeToScene();
		boardStage.centerOnScreen();
	}

	public void showColorsDialog() {
		if(colorsStage.isShowing())
		{
			colorsStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Enter the desired colors for the board squares (Format: #RRGGBB)");

			Label lightShadeLabel = new Label("Light Squares");
			TextField newLightShade = new TextField(lightShade.toString());
			newLightShade.setPromptText("#RRGGBB");
			Button previewLightShade = new Button("Preview");
			Button resetLightShade = new Button("Reset");
			Rectangle lightShadePreview = new Rectangle();
			lightShadePreview.setWidth(40);
			lightShadePreview.setHeight(20);
			lightShadePreview.setFill(Color.web(lightShade.toString()));
			lightShadePreview.setStroke(Color.web("#000000"));
			lightShadePreview.setStrokeWidth(2);
			HBox lightShadeHBox = new HBox(newLightShade, previewLightShade, resetLightShade, lightShadePreview);
			lightShadeHBox.setSpacing(10);
			previewLightShade.setOnAction(lse -> {
				if (checkColorFormat(newLightShade.getText())) {
					lightShadePreview.setFill(Color.web(newLightShade.getText()));
				}
			});
			resetLightShade.setOnAction(lse -> {
				if (checkColorFormat(defaultLightShade.toString())) {
					lightShadePreview.setFill(Color.web(defaultLightShade.toString()));
					newLightShade.setText(defaultLightShade.toString());
				} else {
					lightShadePreview.setFill(Color.web("#FFCC9C"));
					newLightShade.setText("#FFCC9C");
				}
			});

			Label darkShadeLabel = new Label("Dark Squares");
			TextField newDarkShade = new TextField(darkShade.toString());
			newDarkShade.setPromptText("#RRGGBB");
			Button setDarkShade = new Button("Preview");
			Button resetDarkShade = new Button("Reset");
			Rectangle darkShadePreview = new Rectangle();
			darkShadePreview.setWidth(40);
			darkShadePreview.setHeight(20);
			darkShadePreview.setFill(Color.web(darkShade.toString()));
			darkShadePreview.setStroke(Color.web("#000000"));
			darkShadePreview.setStrokeWidth(2);
			HBox darkShadeHBox = new HBox(newDarkShade, setDarkShade, resetDarkShade, darkShadePreview);
			darkShadeHBox.setSpacing(10);
			setDarkShade.setOnAction(dse -> {
				if (checkColorFormat(newDarkShade.getText())) {
					darkShadePreview.setFill(Color.web(newDarkShade.getText()));
				}
			});
			resetDarkShade.setOnAction(dse -> {
				if (checkColorFormat(defaultDarkShade.toString())) {
					darkShadePreview.setFill(Color.web(defaultDarkShade.toString()));
					newDarkShade.setText(defaultDarkShade.toString());
				} else {
					darkShadePreview.setFill(Color.web("#CF8948"));
					newDarkShade.setText("#CF8948");
				}
			});
			
			Label holeColorLabel = new Label("Holes");
			TextField newHoleColor = new TextField(holeColor.toString());
			newHoleColor.setPromptText("#RRGGBB");
			Button setHoleColor = new Button("Preview");
			Button resetHoleColor = new Button("Reset");
			Rectangle holeColorPreview = new Rectangle();
			holeColorPreview.setWidth(40);
			holeColorPreview.setHeight(20);
			holeColorPreview.setFill(Color.web(holeColor.toString()));
			holeColorPreview.setStroke(Color.web("#000000"));
			holeColorPreview.setStrokeWidth(2);
			HBox holeColorHBox = new HBox(newHoleColor, setHoleColor, resetHoleColor, holeColorPreview);
			holeColorHBox.setSpacing(10);
			setHoleColor.setOnAction(dse -> {
				if (checkColorFormat(newHoleColor.getText())) {
					holeColorPreview.setFill(Color.web(newHoleColor.getText()));
				}
			});
			resetHoleColor.setOnAction(dse -> {
				if (checkColorFormat(defaultHoleColor.toString())) {
					holeColorPreview.setFill(Color.web(defaultHoleColor.toString()));
					newHoleColor.setText(defaultHoleColor.toString());
				} else {
					holeColorPreview.setFill(Color.web("#000000"));
					newHoleColor.setText("#000000");
				}
			});
			
			Label holeBorderColorLabel = new Label("Hole Borders");
			TextField newHoleBorderColor = new TextField(holeBorderColor.toString());
			newHoleBorderColor.setPromptText("#RRGGBB");
			Button setHoleBorderColor = new Button("Preview");
			Button resetHoleBorderColor = new Button("Reset");
			Rectangle holeBorderColorPreview = new Rectangle();
			holeBorderColorPreview.setWidth(40);
			holeBorderColorPreview.setHeight(20);
			holeBorderColorPreview.setFill(Color.web(holeBorderColor.toString()));
			holeBorderColorPreview.setStroke(Color.web("#000000"));
			holeBorderColorPreview.setStrokeWidth(2);
			HBox holeBorderColorHBox = new HBox(newHoleBorderColor, setHoleBorderColor, resetHoleBorderColor, holeBorderColorPreview);
			holeBorderColorHBox.setSpacing(10);
			setHoleBorderColor.setOnAction(dse -> {
				if (checkColorFormat(newHoleColor.getText())) {
					holeBorderColorPreview.setFill(Color.web(newHoleBorderColor.getText()));
				}
			});
			resetHoleBorderColor.setOnAction(dse -> {
				if (checkColorFormat(defaultHoleColor.toString())) {
					holeBorderColorPreview.setFill(Color.web(defaultHoleColor.toString()));
					newHoleBorderColor.setText(defaultHoleColor.toString());
				} else {
					holeColorPreview.setFill(Color.web("#000000"));
					newHoleBorderColor.setText("#000000");
				}
			});

			Button applyColors = new Button("Apply");
			Button restoreDefaultColors = new Button("Restore Defaults");

			HBox buttonHBox = new HBox(applyColors, restoreDefaultColors);
			buttonHBox.setAlignment(Pos.CENTER_RIGHT);
			buttonHBox.setSpacing(10);
			VBox colorsVBox = new VBox(instructionsLabel, lightShadeLabel, lightShadeHBox, darkShadeLabel, darkShadeHBox, holeColorLabel, holeColorHBox, holeBorderColorLabel, holeBorderColorHBox, buttonHBox);
			colorsVBox.setSpacing(10);
			colorsVBox.setPadding(new Insets(10));
			Scene colorsScene = new Scene(colorsVBox);
			applyColors.requestFocus();

			applyColors.setOnAction(ae -> {
				boolean hasValidColor = false;
				if (checkColorFormat(newLightShade.getText())) {
					lightShade = new StringBuffer(newLightShade.getText());
					hasValidColor = true;
				}
				if (checkColorFormat(newDarkShade.getText())) {
					darkShade = new StringBuffer(newDarkShade.getText());
					hasValidColor = true;
				}
				if (checkColorFormat(newHoleColor.getText())) {
					holeColor = new StringBuffer(newHoleColor.getText());
					hasValidColor = true;
				}
				if (checkColorFormat(newHoleBorderColor.getText())) {
					holeBorderColor = new StringBuffer(newHoleBorderColor.getText());
					hasValidColor = true;
				}
				if (hasValidColor) {
					Display(true);
					colorsStage.close();
				}
			});
			restoreDefaultColors.setOnAction(rde -> {
				if (checkColorFormat(defaultLightShade.toString())) {
					lightShade = new StringBuffer(defaultLightShade.toString());
				} else {
					lightShade = new StringBuffer("#FFCC9C");
				}
				if (checkColorFormat(defaultDarkShade.toString())) {
					darkShade = new StringBuffer(defaultDarkShade.toString());
				} else {
					darkShade = new StringBuffer("#CF8948");
				}
				if (checkColorFormat(defaultHoleColor.toString())) {
					holeColor = new StringBuffer(defaultHoleColor.toString());
				} else {
					holeColor = new StringBuffer("#000000");
				}
				if (checkColorFormat(defaultHoleBorderColor.toString())) {
					holeBorderColor = new StringBuffer(defaultHoleBorderColor.toString());
				} else {
					holeBorderColor = new StringBuffer("#FFFFFF");
				}
				Display(true);
				colorsStage.close();
			});

			colorsStage.setScene(colorsScene);
			colorsStage.setTitle("Board Colors");
			colorsStage.show();
		}
	}
	
	public void showHighlightsDialog() {
		if(highlightsStage.isShowing())
		{
			highlightsStage.requestFocus();
		}
		else
		{
			Label instructionsLabel = new Label("Enter the desired colors for the board highlights (Format: #RRGGBB)");

			Label selectedPieceLabel = new Label("Selected piece");
			TextField newSelectedPieceColor = new TextField(selectedPieceColor.toString());
			newSelectedPieceColor.setPromptText("#RRGGBB");
			Button previewSelectedPieceColor = new Button("Preview");
			Button resetSelectedPieceColor = new Button("Reset");
			Rectangle selectedPieceColorPreview = new Rectangle();
			selectedPieceColorPreview.setWidth(40);
			selectedPieceColorPreview.setHeight(20);
			selectedPieceColorPreview.setFill(Color.web(selectedPieceColor.toString()));
			selectedPieceColorPreview.setStroke(Color.web("#000000"));
			selectedPieceColorPreview.setStrokeWidth(2);
			HBox selectedPieceColorHBox = new HBox(newSelectedPieceColor, previewSelectedPieceColor, resetSelectedPieceColor, selectedPieceColorPreview);
			selectedPieceColorHBox.setSpacing(10);
			previewSelectedPieceColor.setOnAction(spce -> {
				if (checkColorFormat(newSelectedPieceColor.getText())) {
					selectedPieceColorPreview.setFill(Color.web(newSelectedPieceColor.getText()));
				}
			});
			resetSelectedPieceColor.setOnAction(rspce -> {
				if (checkColorFormat(defaultSelectedPieceColor.toString())) {
					selectedPieceColorPreview.setFill(Color.web(defaultSelectedPieceColor.toString()));
					newSelectedPieceColor.setText(defaultSelectedPieceColor.toString());
				} else {
					selectedPieceColorPreview.setFill(Color.web("#80FF80"));
					newSelectedPieceColor.setText("#80FF80");
				}
			});
			
			Label lastMoveLabel = new Label("Last move (origin and destination squares)");
			TextField newLastMoveColor = new TextField(lastMoveColor.toString());
			newLastMoveColor.setPromptText("#RRGGBB");
			Button previewLastMoveColor = new Button("Preview");
			Button resetLastMoveColor = new Button("Reset");
			Rectangle lastMoveColorPreview = new Rectangle();
			lastMoveColorPreview.setWidth(40);
			lastMoveColorPreview.setHeight(20);
			lastMoveColorPreview.setFill(Color.web(lastMoveColor.toString()));
			lastMoveColorPreview.setStroke(Color.web("#000000"));
			lastMoveColorPreview.setStrokeWidth(2);
			HBox lastMoveColorHBox = new HBox(newLastMoveColor, previewLastMoveColor, resetLastMoveColor, lastMoveColorPreview);
			lastMoveColorHBox.setSpacing(10);
			previewLastMoveColor.setOnAction(slmce -> {
				if (checkColorFormat(newLastMoveColor.getText())) {
					lastMoveColorPreview.setFill(Color.web(newLastMoveColor.getText()));
				}
			});
			resetLastMoveColor.setOnAction(rlmce -> {
				if (checkColorFormat(defaultLastMoveColor.toString())) {
					lastMoveColorPreview.setFill(Color.web(defaultLastMoveColor.toString()));
					newLastMoveColor.setText(defaultLastMoveColor.toString());
				} else {
					lastMoveColorPreview.setFill(Color.web("#00FF00"));
					newLastMoveColor.setText("#00FF00");
				}
			});

			Label lastLocustCaptureLabel = new Label("Last locust capture (intermediate square(s))");
			TextField newLastLocustCaptureColor = new TextField(lastLocustCaptureColor.toString());
			newLastLocustCaptureColor.setPromptText("#RRGGBB");
			Button previewLastLocustCaptureColor = new Button("Preview");
			Button resetLastLocustCaptureColor = new Button("Reset");
			Rectangle lastLocustCaptureColorPreview = new Rectangle();
			lastLocustCaptureColorPreview.setWidth(40);
			lastLocustCaptureColorPreview.setHeight(20);
			lastLocustCaptureColorPreview.setFill(Color.web(lastLocustCaptureColor.toString()));
			lastLocustCaptureColorPreview.setStroke(Color.web("#000000"));
			lastLocustCaptureColorPreview.setStrokeWidth(2);
			HBox lastLocustCaptureColorHBox = new HBox(newLastLocustCaptureColor, previewLastLocustCaptureColor, resetLastLocustCaptureColor, lastLocustCaptureColorPreview);
			lastLocustCaptureColorHBox.setSpacing(10);
			previewLastLocustCaptureColor.setOnAction(llcce -> {
				if(checkColorFormat(newLastLocustCaptureColor.getText())) {
					lastLocustCaptureColorPreview.setFill(Color.web(newLastLocustCaptureColor.getText()));
				}
			});
			resetLastLocustCaptureColor.setOnAction(rllcce -> {
				if (checkColorFormat(defaultLastLocustCaptureColor.toString())) {
					lastLocustCaptureColorPreview.setFill(Color.web(defaultLastLocustCaptureColor.toString()));
					newLastLocustCaptureColor.setText(defaultLastLocustCaptureColor.toString());
				} else {
					lastLocustCaptureColorPreview.setFill(Color.web("#FFF000"));
					newLastLocustCaptureColor.setText("#FFF000");
				}
			});

			Label moveLabel = new Label("Move to empty square");
			TextField newMoveColor = new TextField(moveColor.toString());
			newMoveColor.setPromptText("#RRGGBB");
			Button previewMoveColor = new Button("Preview");
			Button resetMoveColor = new Button("Reset");
			Rectangle moveColorPreview = new Rectangle();
			moveColorPreview.setWidth(40);
			moveColorPreview.setHeight(20);
			moveColorPreview.setFill(Color.web(moveColor.toString()));
			moveColorPreview.setStroke(Color.web("#000000"));
			moveColorPreview.setStrokeWidth(2);
			HBox moveColorHBox = new HBox(newMoveColor, previewMoveColor, resetMoveColor, moveColorPreview);
			moveColorHBox.setSpacing(10);
			previewMoveColor.setOnAction(mce -> {
				if(checkColorFormat(newMoveColor.getText())) {
					moveColorPreview.setFill(Color.web(newMoveColor.getText()));
				}
			});
			resetMoveColor.setOnAction(rmce -> {
				if (checkColorFormat(defaultMoveColor.toString())) {
					moveColorPreview.setFill(Color.web(defaultMoveColor.toString()));
					newMoveColor.setText(defaultMoveColor.toString());
				} else {
					moveColorPreview.setFill(Color.web("#FFFF00"));
					newMoveColor.setText("#FFFF00");
				}
			});

			Label captureLabel = new Label("Capture of enemy piece");
			TextField newCaptureColor = new TextField(captureColor.toString());
			newCaptureColor.setPromptText("#RRGGBB");
			Button previewCaptureColor = new Button("Preview");
			Button resetCaptureColor = new Button("Reset");
			Rectangle captureColorPreview = new Rectangle();
			captureColorPreview.setWidth(40);
			captureColorPreview.setHeight(20);
			captureColorPreview.setFill(Color.web(captureColor.toString()));
			captureColorPreview.setStroke(Color.web("#000000"));
			captureColorPreview.setStrokeWidth(2);
			HBox captureColorHBox = new HBox(newCaptureColor, previewCaptureColor, resetCaptureColor, captureColorPreview);
			captureColorHBox.setSpacing(10);
			previewCaptureColor.setOnAction(ce -> {
				if(checkColorFormat(newMoveColor.getText())) {
					captureColorPreview.setFill(Color.web(newCaptureColor.getText()));
				}
			});
			resetCaptureColor.setOnAction(rce -> {
				if (checkColorFormat(defaultCaptureColor.toString().toString())) {
					captureColorPreview.setFill(Color.web(defaultCaptureColor.toString()));
					newCaptureColor.setText(defaultCaptureColor.toString());
				} else {
					captureColorPreview.setFill(Color.web("#FF0000"));
					newCaptureColor.setText("#FF0000");
				}
			});
			
			Label destroyLabel = new Label("Capture of friendly piece");
			TextField newDestroyColor = new TextField(destroyColor.toString());
			newDestroyColor.setPromptText("#RRGGBB");
			Button previewDestroyColor = new Button("Preview");
			Button resetDestroyColor = new Button("Reset");
			Rectangle destroyColorPreview = new Rectangle();
			destroyColorPreview.setWidth(40);
			destroyColorPreview.setHeight(20);
			destroyColorPreview.setFill(Color.web(destroyColor.toString()));
			destroyColorPreview.setStroke(Color.web("#000000"));
			destroyColorPreview.setStrokeWidth(2);
			HBox destroyColorHBox = new HBox(newDestroyColor, previewDestroyColor, resetDestroyColor, destroyColorPreview);
			destroyColorHBox.setSpacing(10);
			previewDestroyColor.setOnAction(dce -> {
				if(checkColorFormat(newDestroyColor.getText())) {
					destroyColorPreview.setFill(Color.web(newDestroyColor.getText()));
				}
			});
			resetDestroyColor.setOnAction(rdce -> {
				if (checkColorFormat(defaultDestroyColor.toString())) {
					destroyColorPreview.setFill(Color.web(defaultDestroyColor.toString()));
					newDestroyColor.setText(defaultDestroyColor.toString());
				} else {
					destroyColorPreview.setFill(Color.web("#0000FF"));
					newDestroyColor.setText("#0000FF");
				}
			});

			Label locustCaptureLabel = new Label("Locust capture (capture and move again)");
			TextField newLocustCaptureColor = new TextField(locustCaptureColor.toString());
			newLocustCaptureColor.setPromptText("#RRGGBB");
			Button previewLocustCaptureColor = new Button("Preview");
			Button resetLocustCaptureColor = new Button("Reset");
			Rectangle locustCaptureColorPreview = new Rectangle();
			locustCaptureColorPreview.setWidth(40);
			locustCaptureColorPreview.setHeight(20);
			locustCaptureColorPreview.setFill(Color.web(locustCaptureColor.toString()));
			locustCaptureColorPreview.setStroke(Color.web("#000000"));
			locustCaptureColorPreview.setStrokeWidth(2);
			HBox locustCaptureColorHBox = new HBox(newLocustCaptureColor, previewLocustCaptureColor, resetLocustCaptureColor, locustCaptureColorPreview);
			locustCaptureColorHBox.setSpacing(10);
			previewLocustCaptureColor.setOnAction(lcce -> {
				if(checkColorFormat(newLocustCaptureColor.getText())) {
					locustCaptureColorPreview.setFill(Color.web(newLocustCaptureColor.getText()));
				}
			});
			resetLocustCaptureColor.setOnAction(rlcce -> {
				if (checkColorFormat(defaultLocustCaptureColor.toString())) {
					locustCaptureColorPreview.setFill(Color.web(defaultLocustCaptureColor.toString()));
					newLocustCaptureColor.setText(defaultLocustCaptureColor.toString());
				} else {
					locustCaptureColorPreview.setFill(Color.web("#00FFFF"));
					newLocustCaptureColor.setText("#00FFFF");
				}
			});
			
			Button applyHighlights = new Button("Apply");
			Button restoreDefaultHighlights = new Button("Restore Defaults");

			HBox buttonHBox = new HBox(applyHighlights, restoreDefaultHighlights);
			buttonHBox.setAlignment(Pos.CENTER_RIGHT);
			buttonHBox.setSpacing(10);
			VBox highlightsVBox = new VBox(instructionsLabel, selectedPieceLabel, selectedPieceColorHBox, lastMoveLabel, lastMoveColorHBox, lastLocustCaptureLabel, lastLocustCaptureColorHBox, moveLabel, moveColorHBox, captureLabel, captureColorHBox, destroyLabel, destroyColorHBox, locustCaptureLabel, locustCaptureColorHBox, buttonHBox);
			highlightsVBox.setSpacing(10);
			highlightsVBox.setPadding(new Insets(10));
			Scene colorsScene = new Scene(highlightsVBox);
			applyHighlights.requestFocus();

			applyHighlights.setOnAction(ae -> {
				boolean hasValidColor = false;
				if(checkColorFormat(newSelectedPieceColor.getText())) {
					selectedPieceColor = new StringBuffer(newSelectedPieceColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newLastMoveColor.getText())) {
					lastMoveColor = new StringBuffer(newLastMoveColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newLastLocustCaptureColor.getText())) {
					lastLocustCaptureColor = new StringBuffer(newLastLocustCaptureColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newMoveColor.getText())) {
					moveColor = new StringBuffer(newMoveColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newCaptureColor.getText())) {
					captureColor = new StringBuffer(newCaptureColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newDestroyColor.getText())) {
					destroyColor = new StringBuffer(newDestroyColor.getText());
					hasValidColor = true;
				}
				if(checkColorFormat(newLocustCaptureColor.getText())) {
					locustCaptureColor = new StringBuffer(newLocustCaptureColor.getText());
					hasValidColor = true;
				}

				if (hasValidColor) {
					Display(true);
					BoardPosition position = board.getGame().get(board.getDisplayed());
					updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
					highlightsStage.close();
				}
			});
			restoreDefaultHighlights.setOnAction(rde -> {
				if (checkColorFormat(defaultSelectedPieceColor.toString())) {
					selectedPieceColor = new StringBuffer(defaultSelectedPieceColor.toString());
				} else {
					selectedPieceColor = new StringBuffer("#80FF80");
				}
				if (checkColorFormat(defaultLastMoveColor.toString())) {
					lastMoveColor = new StringBuffer(defaultLastMoveColor.toString());
				} else {
					lastMoveColor = new StringBuffer("#00FF00");
				}
				if (checkColorFormat(defaultLastLocustCaptureColor.toString())) {
					lastLocustCaptureColor = new StringBuffer(defaultLastLocustCaptureColor.toString());
				} else {
					lastLocustCaptureColor = new StringBuffer("#FFF000");
				}
				if (checkColorFormat(defaultMoveColor.toString())) {
					moveColor = new StringBuffer(defaultMoveColor.toString());
				} else {
					moveColor = new StringBuffer("#FFFF00");
				}
				if (checkColorFormat(defaultCaptureColor.toString())) {
					captureColor = new StringBuffer(defaultCaptureColor.toString());
				} else {
					captureColor = new StringBuffer("#FF0000");
				}
				if (checkColorFormat(defaultMoveColor.toString())) {
					destroyColor = new StringBuffer(defaultDestroyColor.toString());
				} else {
					destroyColor = new StringBuffer("#0000FF");
				}
				if (checkColorFormat(defaultMoveColor.toString())) {
					locustCaptureColor = new StringBuffer(defaultLocustCaptureColor.toString());
				} else {
					locustCaptureColor = new StringBuffer("#00FFFF");
				}
				Display(true);
				BoardPosition position = board.getGame().get(board.getDisplayed());
				updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
				highlightsStage.close();
			});

			highlightsStage.setScene(colorsScene);
			highlightsStage.setTitle("Board Colors");
			highlightsStage.show();
		}
	}
	
	public void goToBeginning()
	{
		ResetEvents(true);
		board.Seek(0);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void goOneBack()
	{
		ResetEvents(true);
		board.Seek(1);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void goOneForward()
	{
		ResetEvents(true);
		board.Seek(2);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void goToEnd()
	{
		ResetEvents(true);
		board.Seek(3);
		BoardPosition position = board.getGame().get(board.getDisplayed());
		updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
		Display(false);
	}
	
	public void undoMove()
	{
		if((board.getGame().size() - 1) >= 1 && board.isCurrentPosition())
		{
			ResetEvents(true);
			board.getGame().remove(board.getGame().size() - 1);
			board.Seek(3);
			BoardPosition position = board.getGame().get(board.getDisplayed());
			updateLastMoveSquares(position.getOriginX(), position.getOriginY(), position.getEX(), position.getEY(), position.getDestX(), position.getDestY());
			Display(false);
		}
	}
	
	/**
	 * Closes excess open dialogs.</br>
	 * Should be called whenever the dialog opened has</br>
	 * the potential to change board statistics</br>
	 * and used on all dialogs with the potential to</br>
	 * change board statistics.
	 */
	public void closeExcessDialogs()
	{
		gamePresetsStage.close(); // dialog for changing game preset
		fenCodeStage.close(); // dialog for changing board position with FEN Code
		fenCodeRequirementsStage.close();
		colorsStage.close(); // dialog for changing square colors
		highlightsStage.close(); // dialog for changing square colors
	}
	
	/**
	 * Closes all open dialogs.</br>
	 * Should be called whenever the application</br>
	 * closes and used on all dialogs created by</br>
	 * the application.
	 */
	public void closeAllDialogs()
	{
		closeExcessDialogs(); // close dialogs closed by closeExcessDialogs
		fenCodeHelpStage.close();
	}
	
	// Events and Event Methods for moving pieces
	
	// Select Piece
	private EventHandler<MouseEvent> selectPieceEvent = spe -> {
		if(disableBoardEvents)
		{
			spe.consume();
		}
		else if(!board.isCurrentPosition())
		{
			spe.consume();
		}
		else if(pieceSelected == false)
		{	
			StackPane selectedPiece = (StackPane)spe.getSource(); // get board square
			String[] selectedPieceCoords = selectedPiece.getId().split(","); // get square ID
			int selectedPieceX = Integer.parseInt(selectedPieceCoords[0]); // update origin coords for moving piece
			int selectedPieceY = Integer.parseInt(selectedPieceCoords[1]);
			
			selectPiece(selectedPieceX, selectedPieceY, true);
		}
	};
	
	// Move Piece
	private EventHandler<MouseEvent> movePieceEvent = mpe -> {
		if(disableBoardEvents)
		{
			mpe.consume();
		}
		else if(!board.isCurrentPosition())
		{
			mpe.consume();
		}
		else
		{
			StackPane selectedPiece = (StackPane)mpe.getSource();
			String[] selectedPieceCoords = selectedPiece.getId().split(",");
			destX = Integer.parseInt(selectedPieceCoords[0]);
			destY = Integer.parseInt(selectedPieceCoords[1]);
			board.Move(originX, originY, null, null, destX, destY, -1);
			updateLastMoveSquares(originX, originY, null, null, destX, destY);
			deselectPiece();
			Display(false);
		}
	};
	
	// Deselect Piece
	private EventHandler<MouseEvent> deselectPieceEvent = dpe -> {
		if(disableBoardEvents)
		{
			dpe.consume();
		}
		else if(!board.isCurrentPosition())
		{
			dpe.consume();
		}
		else
		{
			deselectPiece();
		}
	};
	
	public void selectPiece(int x, int y, boolean updateDisplay)
	{
		if(x < 0 || x > nFiles || y < 0 || y > nRanks)
		{
			return;
		}
		originX = x;
		originY = y;
		if(updateDisplay)
		{
			Display(true);
		}
		StackPane pieceSquare = getBoardSquare(x, y);
		updateSelectedPieceEvents(pieceSquare, false);
		updateMovePieceEvents(false);
		pieceSelected = true;
	}
	
	public void deselectPiece()
	{
		StackPane pieceSquare = getBoardSquare(originX, originY);
		updateSelectedPieceEvents(pieceSquare, true);
		updateMovePieceEvents(true);
		Display(false);
		originX = -1;
		originY = -1;
		ex.clear();
		ey.clear();
		destX = -1;
		destY = -1;
		promotion = -1;
		pieceSelected = false;
	}
	
	/**
	 * 
	 * @param x1 x-coordinate of origin square
	 * @param y1 y-coordinate of origin square
	 * @param ex array of x-coordinates for intermediate squares
	 * @param ey array of y-coordinates for intermediate squares
	 * @param x2 x-coordinate of destination square
	 * @param y2 y-coordinate of destination square
	 */
	public void updateLastMoveSquares(int x1, int y1, ArrayList<Integer> ex, ArrayList<Integer> ey, int x2, int y2)
	{
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				if(board.getPieceOnSquare(j, i) != -1)
				{
					getBoardSquare(j, i).setStyle("-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:#000000;");
				}
			}
		}
		
		if(x1 < 0 || x1 > nFiles || y1 < 0 || y1 > nRanks || x2 < 0 || x2 > nFiles || y2 < 0 || y2 > nRanks)
		{
			return;
		}
		
		int[] epx = null;
		if(ex != null)
		{
			epx = new int[ex.size()];
			for(int i = 0; i < ex.size(); ++i)
			{
				epx[i] = ex.get(i);
			}
		}
		int[] epy = null;
		if(ey != null)
		{
			epy = new int[ey.size()];
			for(int i = 0; i < ey.size(); ++i)
			{
				epy[i] = ey.get(i);
			}
		}
		
		String lastMoveStyleString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + lastMoveColor + ";";
		String lastLocustCaptureStyleString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + lastLocustCaptureColor + ";";
		
		if(ex != null && ey != null) // exit early if any intermediate square cannot be moved to
		{
			int maxIntermediateSquares = Math.min(epx.length, epy.length);
			StackPane intermediateSquare;
			for(int i = 0; i < maxIntermediateSquares; ++i) // exit early if piece on square cannot be moved
			{
				intermediateSquare = getBoardSquare(epx[i], epy[i]);
				intermediateSquare.setStyle(lastLocustCaptureStyleString);
			}
		}
		
		StackPane origin = getBoardSquare(x1, y1);
		origin.setStyle(lastMoveStyleString);
		StackPane dest = getBoardSquare(x2, y2);
		dest.setStyle(lastMoveStyleString);
	}

	public void updateHoleBorders()
	{
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				if(board.getPieceOnSquare(j, i) == -1)
				{
					StackPane boardSquare = getBoardSquare(j, i);
					String holeBorderString = "-fx-border-width:1px; -fx-border-style:solid; -fx-border-color:" + holeBorderColor + ";";
					boardSquare.setStyle(holeBorderString);
				}
			}
		}
	}
	
	// Methods for controlling board events

	/**
	 * Manages the events of a given board square.
	 * @param square board square to manage events on
	 * @param type event type
	 * @param event event
	 * @param remove whether to remove the event rather than add it
	 */
	public void manageBoardSquareEvents(StackPane square, EventType<MouseEvent> type, EventHandler<MouseEvent> event, boolean remove) {
		if (remove) {
			try
			{
				square.removeEventHandler(type, event);
			}
			catch(NullPointerException npe)
			{
				return;
			}
		} else {
			try
			{
				square.addEventHandler(type, event);
			}
			catch(NullPointerException npe)
			{
				return;
			}
		}
	}

	/**
	 * Updates piece selection events on this square.
	 * @param selectedPiece the board square to update selection events on
	 * @param deselect whether to deselect the piece.
	 */
	private void updateSelectedPieceEvents(StackPane selectedPiece, boolean deselect)
	{
		if(deselect)
		{
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, true);
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, selectPieceEvent, false);
		}
		else
		{
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, selectPieceEvent, true);
			manageBoardSquareEvents(selectedPiece, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, false);
		}
	}
	
	public void updateMovePieceEvents(boolean remove)
	{
		int pieceColor = pieceList.getPieceColor(board.getPieceOnSquare(originX, originY));
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				manageBoardSquareEvents(getBoardSquare(j, i), MouseEvent.MOUSE_CLICKED, movePieceEvent, true);
				if(remove == false && board.getPieceOnSquare(j, i) != -1 && pieceColor != pieceList.getPieceColor(board.getPieceOnSquare(j, i)))
				{
					manageBoardSquareEvents(getBoardSquare(j, i), MouseEvent.MOUSE_CLICKED, movePieceEvent, false);
				}
			}
		}
	}

	/**
	 * Resets the board display to its state when no piece is selected.
	 * @param resetCoords whether to reset the coordinates for moving pieces on the board
	 */
	public void ResetEvents(boolean resetCoords)
	{
		if(resetCoords)
		{
			originX = -1;
			originY = -1;
			ex.clear();
			ey.clear();
			destX = -1;
			destY = -1;
			promotion = -1;
			pieceSelected = false;
		}
		StackPane boardSquare;
		for(int i = 0; i < nRanks; ++i)
		{
			for(int j = 0; j < nFiles; ++j)
			{
				boardSquare = getBoardSquare(j, i);
				
				manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, selectPieceEvent, true);
				manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, true);
				manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, movePieceEvent, true);

				if(board.getPieceOnSquare(j, i) > 0 && board.getPieceOnSquare(j, i) <= board.getMaxPieces())
				{
					manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, selectPieceEvent, false);
					manageBoardSquareEvents(boardSquare, MouseEvent.MOUSE_CLICKED, deselectPieceEvent, true);
				}
			}
		}
	}
}