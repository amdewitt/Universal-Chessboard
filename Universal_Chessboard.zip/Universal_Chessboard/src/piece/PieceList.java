package piece;

import java.util.ArrayList;
import javafx.scene.image.*;

/**
 * The PieceList class stores all possible piece types in an ArrayList.
 * @author Adam
 *
 */
public class PieceList {
	private ArrayList<Piece> pieceList; // store piece list in an array
	private int nPieceTypes; // number of color-independent piece types
	private int maxPieceValue; // largest valid piece number
	private int size; // size of list
	private StringBuffer pieceDirectory = new StringBuffer("/chess/"); // directory to search for piece images (must end in "/")
	private StringBuffer whitePrefix = new StringBuffer("w"); // white piece image prefix
	private StringBuffer blackPrefix = new StringBuffer("b"); // black piece image prefix
	private boolean useGIFs = false;
	
	// Create Piece List
	
	/**
	 * Constructor
	 * Creates a new piece list
	 * @param nPieces number of piece types (color-independent). Does not include empty squares.
	 * @param pieceDir piece directory
	 * @param wPrefix white piece image prefix
	 * @param bPrefix black piece image prefix
	 * @param useGIFImages whether to use .gif images rather than .png images
	 */
	public PieceList(int nPieces, String pieceDir, String wPrefix, String bPrefix, boolean useGIFImages)
	{
		if(pieceDir.charAt(pieceDir.length() - 1) != '/') // exit early if initial conditions don't hold
		{
			return;
		}
		pieceDirectory = new StringBuffer(pieceDir); // initialize variables
		whitePrefix = new StringBuffer(wPrefix);
		blackPrefix = new StringBuffer(bPrefix);
		createPieceList(nPieces, useGIFImages); // create piece list
	}
	
	/**
	 * Constructor
	 * Creates a new piece list
	 * @param nPieces number of piece types (color-independent). Does not include empty squares.
	 * @param pieceDir piece directory
	 * @param wPrefix white piece image prefix
	 * @param bPrefix black piece image prefix
	 */
	public PieceList(int nPieces, String pieceDir, String wPrefix, String bPrefix)
	{
		if(pieceDir.charAt(pieceDir.length() - 1) != '/') // exit early if initial conditions don't hold
		{
			return;
		}
		pieceDirectory = new StringBuffer(pieceDir); // initialize variables
		whitePrefix = new StringBuffer(wPrefix);
		blackPrefix = new StringBuffer(bPrefix);
		createPieceList(nPieces, false); // create piece list
	}
	
	/**
	 * Constructor
	 * Creates a new piece list.
	 * @param nPieces number of piece types (color-independent). Does not include empty squares.
	 * @param pieceDir piece directory
	 * @param pieceSuffix the piece image suffix
	 */
	public PieceList(int nPieces, String pieceDir)
	{
		if(pieceDir.charAt(pieceDir.length() - 1) != '/') // exit early if initial conditions don't hold
		{
			return;
		}
		pieceDirectory = new StringBuffer(pieceDir); // initialize variables
		createPieceList(nPieces, false); // create piece list
	}
	
	/**
	 * Constructor
	 * Creates a new piece list with the default settings.
	 */
	public PieceList()
	{
		createPieceList(6, false); // create default piece list
		addPiece(1, "Pawn", "P", "ifmnDfmWfceF", "pawn");
		addPiece(2, "Knight", "N", "N", "knight");
		addPiece(3, "Bishop", "B", "B", "bishop");
		addPiece(4, "Rook", "R", "R", "rook");
		addPiece(5, "Queen", "Q", "Q", "queen");
		addPiece(6, "King", "K", "KisO2", "king");
		setRoyal(6, 1);
	}
	
	private void createPieceList(int nTypes, boolean useGIFs)
	{
		nPieceTypes = nTypes;
		maxPieceValue = nTypes * 2;
		size = nTypes * 2 + 1;
		pieceList = new ArrayList<Piece>(size);
		this.useGIFs = useGIFs;
		for(int i = 0; i < size; ++i)
		{
			pieceList.add(i, new Piece("Null", "?", "O", "/null/null.png"));
		}
	}
	
	public int getNPieceTypes()
	{
		return nPieceTypes;
	}
	
	// Control and Information methods for individual pieces in the list
	
	/**
	 * Adds a piece to the list. One piece of each color is added.
	 * If something goes wrong while adding the pieces, nothing happens.
	 * @param index position in list to place this piece (Cannot be less than 1 or greater than nPieceTypes)
	 * @param pieceName piece's name
	 * @param pieceID piece's ID (must contain at least one letter)
	 * @param pieceBetza piece's moves in XBetza Notation
	 * @param imageName piece's image name (without prefix)
	 */
	public void addPiece(int index, String pieceName, String pieceID, String pieceBetza, String imageName)
	{
		if(index < 1 || index > nPieceTypes)
		{
			return;
		}
		boolean letterFoundInID = false;
		for(int i = 0; i < pieceID.length(); ++i)
		{
			if((pieceID.charAt(i) >= 'A' || pieceID.charAt(i) <= 'Z') || (pieceID.charAt(i) >= 'a' || pieceID.charAt(i) <= 'z'));
			{
				letterFoundInID = true;
			}
		}
		if(letterFoundInID == false)
		{
			return;
		}
		
		String pieceSuffix;
		if(useGIFs == true)
		{
			pieceSuffix = ".gif";
		}
		else
		{
			pieceSuffix = ".png";
		}
		String whiteImage = pieceDirectory.toString() + whitePrefix.toString() + imageName + pieceSuffix;
		String blackImage = pieceDirectory.toString() + blackPrefix.toString() + imageName + pieceSuffix;
		try
		{
			pieceList.set(index, new Piece(pieceName, pieceID.toUpperCase(), pieceBetza, whiteImage));
			pieceList.set(index + nPieceTypes, new Piece(pieceName, pieceID.toUpperCase(), pieceBetza, blackImage));
		}
		catch(NullPointerException e1)
		{
			pieceList.set(index, new Piece(pieceName, pieceID.toUpperCase(), pieceBetza, "/null/null.png"));
			pieceList.set(index + nPieceTypes, new Piece(pieceName, pieceID.toUpperCase(), pieceBetza, "/null/null.png"));
			return;
		}
		catch(IllegalArgumentException e2)
		{
			pieceList.set(index, new Piece(pieceName, pieceID.toUpperCase(), pieceBetza, "/null/null.png"));
			pieceList.set(index + nPieceTypes, new Piece(pieceName, pieceID.toUpperCase(), pieceBetza, "/null/null.png"));
			return;
		}
	}
	
	/**
	 * Gets a specific piece from the list.
	 * @param index the number of this piece. Cannot be < 1 or > size
	 * @return the piece at position index in the list
	 */
	public Piece getPiece(int index)
	{
		if(index < 1 || index > maxPieceValue)
		{
			return null;
		}
		Piece pieceAtIndex = pieceList.get(index);
		return pieceAtIndex;
	}
	
	/**
	 * Gets a specific piece image from the list.
	 * @param index the number of this piece. Cannot be < 1 or > size
	 * @return the image of the piece at position index in the list
	 */
	public ImageView getPieceImage(int index)
	{
		if(index < 1 || index > maxPieceValue)
		{
			return null;
		}
		Image pieceImage = pieceList.get(index).getPieceImage();
		ImageView imageView = new ImageView(pieceImage);
		imageView.setCache(true);
		return imageView;
	}
	
	/**
	 * Gets a specific piece from the list using its index and color.
	 * @param index the number of this piece. Cannot be < 1 or > nPieceTypes.
	 * @param color whether the piece is white or black. true means black.
	 */
	public Piece getPieceByColor(int index, boolean color)
	{
		if(index < 1 || index > nPieceTypes)
		{
			return null;
		}
		if(color == true)
		{
			return pieceList.get(index + nPieceTypes);
		}
		else
		{
			return pieceList.get(index);
		}
	}
	
	/**
	 * Gets the piece type from the piece's number.
	 * 0 returns an empty square.
	 * @param index the number of this piece. Cannot be less than 1 or greater than nPieceTypes.
	 */
	public int getPieceType(int index)
	{
		if(index < 1 || index > maxPieceValue)
		{
			return 0;
		}
		int pieceType = 0;
		if(index > nPieceTypes)
		{
			pieceType = index - nPieceTypes;
		}
		else
		{
			pieceType = index;
		}
		return pieceType;
	}
	
	public int getPieceColor(int index)
	{
		if(index < 1 || index > maxPieceValue)
		{
			return -1;
		}
		if(index > nPieceTypes)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	
	// Control and Information methods for piece image properties
	
	/**
	 * Set file path for piece image directory
	 * @param dir file path of new piece directory
	 */
	public void setPieceDir(String dir)
	{
		pieceDirectory = new StringBuffer(dir);
	}
	
	/**
	 * Get file path for piece image directory
	 * @return path of piece image directory
	 */
	public String getPieceDir()
	{
		return pieceDirectory.toString();
	}
	
	/**
	 * Set prefix for white piece images
	 * @param prefix prefix for white pieces
	 */
	public void setWhitePrefix(String prefix)
	{
		whitePrefix = new StringBuffer(prefix);
	}
	
	/**
	 * Get prefix for white piece images
	 * @return white piece image prefix
	 */
	public String getWhitePrefix()
	{
		return whitePrefix.toString();
	}
	
	/**
	 * Set prefix for white piece images
	 * @param prefix prefix for white pieces
	 */
	public void setBlackPrefix(String prefix)
	{
		blackPrefix = new StringBuffer(prefix);
	}
	
	/**
	 * Get prefix for black piece images
	 * @return black piece image prefix
	 */
	public String getBlackPrefix()
	{
		return blackPrefix.toString();
	}
	
	// Control and Information Methods for individual piece properties
	
	public void setRoyal(int pieceType, int royalty)
	{
		if(pieceType < 1 || pieceType > nPieceTypes)
		{
			return;
		}
		pieceList.get(pieceType).setRoyalty(royalty);
		pieceList.get(pieceType + nPieceTypes).setRoyalty(royalty);
	}
	
	public void setContagious(int pieceType, boolean contagious)
	{
		if(pieceType < 1 || pieceType > nPieceTypes)
		{
			return;
		}
		pieceList.get(pieceType).setContagious(contagious);
		pieceList.get(pieceType + nPieceTypes).setContagious(contagious);
	}
	
	public String getPieceBetza(int piece)
	{
		if(piece < 1 || piece > maxPieceValue)
		{
			return null;
		}
		else
		{
			return pieceList.get(piece).getPieceBetza();
		}
	}
}
