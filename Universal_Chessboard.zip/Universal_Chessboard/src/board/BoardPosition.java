package board;

import java.util.ArrayList;

public class BoardPosition {
	private ArrayList<PositionSquare> squares;
	private int[] holdings;
	private int maxXValue;
	private int maxYValue;
	
	private int originX;
	private int originY;
	private ArrayList<Integer> ex;
	private ArrayList<Integer> ey;
	private int destX;
	private int destY;
	private int promotion;
	
	public BoardPosition(int[][] boardPosition, int[] holdings, int x1, int y1, ArrayList<Integer> ex, ArrayList<Integer> ey, int x2, int y2, int promotion)
	{
		squares = new ArrayList<PositionSquare>();
		this.holdings = new int[holdings.length];
		this.maxXValue = boardPosition[0].length;
		this.maxYValue = boardPosition.length;
		for(int i = 0; i < boardPosition.length; ++i)
		{
			for(int j = 0; j < boardPosition[i].length; ++j)
			{
				if(boardPosition[i][j] != 0)
				{
					squares.add(new PositionSquare(j, i, boardPosition[i][j]));
				}
			}
		}
		for(int i = 0; i < holdings.length; ++i)
		{
			this.holdings[i] = holdings[i];
		}
		originX = x1;
		originY = y1;
		
		this.ex = new ArrayList<Integer>(ex.size());
		for(int i = 0; i < ex.size(); ++i)
		{
			this.ex.add(ex.get(i));
		}
		
		this.ey = new ArrayList<Integer>(ey.size());
		for(int i = 0; i < ey.size(); ++i)
		{
			this.ey.add(ey.get(i));
		}
		
		destX = x2;
		destY = y2;
		this.promotion = promotion;
	}
	
	public void setBoardPosition(int[][] boardPosition)
	{
		squares.clear();
		for(int i = 0; i < boardPosition.length; ++i)
		{
			for(int j = 0; j < boardPosition[i].length; ++j)
			{
				if(boardPosition[i][j] != 0)
				{
					squares.add(new PositionSquare(j, i, boardPosition[i][j]));
				}
			}
		}
	}
	
	public void setHoldings(int[] holdings)
	{
		for(int i = 0; i < holdings.length; ++i)
		{
			this.holdings[i] = holdings[i];
		}
	}
	
	public int getPositionSquare(int x, int y)
	{
		if(x < 0 || x > maxXValue || y < 0 || y > maxYValue) // check validity of coordinates
		{
			return -1;
		}
		else
		{
			for(int i = 0; i < squares.size(); ++i)
			{
				if(squares.get(i).getX() == x && squares.get(i).getY() == y)
				{
					return squares.get(i).getPiece();
				}
			}
			return 0;
		}
	}
	
	public int[] getHoldings()
	{
		return holdings;
	}
	
	public int getOriginX()
	{
		return originX;
	}
	
	public int getOriginY()
	{
		return originY;
	}
	
	public ArrayList<Integer> getEX()
	{
		return ex;
	}
	
	public ArrayList<Integer> getEY()
	{
		return ey;
	}
	
	public int getDestX()
	{
		return destX;
	}
	
	public int getDestY()
	{
		return destY;
	}
	
	public int getPromotion()
	{
		return promotion;
	}
}
