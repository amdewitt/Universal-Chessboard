package board;

import java.util.ArrayList;

public class BoardPosition {
	private ArrayList<PositionSquare> squares;
	private int maxXValue;
	private int maxYValue;
	
	private int originX;
	private int originY;
	private ArrayList<Integer> ex;
	private ArrayList<Integer> ey;
	private int destX;
	private int destY;
	private int promotion;
	
	public BoardPosition(int[][] boardPosition, int x1, int y1, ArrayList<Integer> ex, ArrayList<Integer> ey, int x2, int y2, int promotion)
	{
		//position = new int[maxYValue + 1][maxXValue + 1];
		squares = new ArrayList<PositionSquare>();
		this.maxXValue = boardPosition[0].length;
		this.maxYValue = boardPosition.length;
		for(int i = 0; i < boardPosition.length; ++i)
		{
			for(int j = 0; j < boardPosition[i].length; ++j)
			{
				//position[i][j] = boardPosition[i][j];
				if(boardPosition[i][j] != 0)
				{
					squares.add(new PositionSquare(j, i, boardPosition[i][j]));
				}
			}
		}
		originX = x1;
		originY = y1;
		
		if(ex != null)
		{
			this.ex = new ArrayList<Integer>(ex.size());
			for(int i = 0; i < this.ex.size(); ++i)
			{
				this.ex.add(ex.get(i));
			}
		}
		else
		{
			this.ex = null;
		}
		if(ey != null)
		{
			this.ey = new ArrayList<Integer>(ey.size());
			for(int i = 0; i < this.ey.size(); ++i)
			{
				this.ey.add(ey.get(i));
			}
		}
		else
		{
			this.ey = null;
		}
		
		destX = x2;
		destY = y2;
		this.promotion = promotion;
	}
	
	public int getPositionSquare(int x, int y)
	{
		if(x < 0 || x > maxXValue || y < 0 || y > maxYValue) // check validity of coordinates
		{
			return -1;
		}
		else
		{
			for(int i = 0; i < squares.size(); ++i)
			{
				if(squares.get(i).getX() == x && squares.get(i).getY() == y)
				{
					return squares.get(i).getPiece();
				}
			}
			return 0;
		}
	}
	
	public int getOriginX()
	{
		return originX;
	}
	
	public int getOriginY()
	{
		return originY;
	}
	
	public ArrayList<Integer> getEX()
	{
		return ex;
	}
	
	public ArrayList<Integer> getEY()
	{
		return ey;
	}
	
	public int getDestX()
	{
		return destX;
	}
	
	public int getDestY()
	{
		return destY;
	}
	
	public int getPromotion()
	{
		return promotion;
	}
}
