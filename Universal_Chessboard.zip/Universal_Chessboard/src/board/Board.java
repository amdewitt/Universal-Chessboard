package board;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import piece.*;

/**
 * The Board class defines and manages the internal board and keeps</br>
 * track of the game currently being played on it.
 * @author Adam
 *
 */
public class Board {
	private int maxXValue; // largest valid x-coordinate (number of vertical columns - 1)
	private int maxYValue; // largest valid y-coordinate (number of horizontal rows - 1)
	private int[][] board; // store board as a 2D int array
	private boolean[][] virgin; // store virgin piece locations as a 2D boolean array
	private int[] hand; // store holdings as a 1D int array
	private int nPieceTypes; // number of color-independent piece types
	private int maxPieceValue; // largest valid piece number
	
	private PieceList pieceList;
	
	private ArrayList<BoardPosition> game = new ArrayList<BoardPosition>(); // game log
	private int displayed = 0;
	
	private boolean[] promotionOptions;
	private boolean[] promoteToCapturedOnly;
	private boolean[] notOnLastRank;
	private int[] customZoneDepths;
	
	// Board Properties
	
	// whether pieces can move contrary to how their moves are defined
	private boolean enforceMoveRules = false;
	
	// whether pieces can be dropped back onto the board
	private boolean enableDrops = false;
	
	// whether to allow promotions on drops
	private boolean allowDropPromotions = false;
	
	// whether drops can be used to capture pieces. Meaningless if enableDrops is false
	private boolean enableDropCaptures = false;
	
	/* 
	 * determine if holdings exist and how they behave
	 * -1: Captured pieces defect to capturer
	 * 0: Holdings does not exist
	 * 1: Captured pieces
	 */
	private int holdingsType = 0;
	
	/*
	 * Whether to demote captured pieces. Meaningless if holdings does not exist
	 * and promotion is not Shogi-style.
	 */
	private boolean demoteOnCapture = false;
	
	// The first maxPromotingPieces pieces on each side can promote
	private int maxPromotingPieces = 1;
	
	// The thickness of the promotion zone
	private int promotionZone = 1;
	
	/*
	 *  A string containing the piece IDs of pieces that can be promoted to.
	 *  Multiple-character IDs are enclosed in curly brackets ({}).
	 *  May also be shogi, capture, or microshogi,
	 *  in which case promotionOffset must be defined.
	 */
	private StringBuffer promotionChoice = new StringBuffer("QRBN");
	
	/*
	 *  The amount to add to a promoting piece's number when doing Shogi-style promotions.
	 *  Ignored if promoChoice is anything other than "shogi", "capture", or "microshogi".
	 *  Cannot be < 0 or > than (nPieceTypes - 1).
	 */
	private int promotionOffset = 0;
	
	// Determines whether to force promotions. 0 is never, 1 is as needed, 2 is always.
	private int forcePromotions = 0;
	
	// Create Board
	
	/**
	 * Constructor<br>
	 * Creates a new board with nFiles files (vertical columns) and</br>
	 * nRanks ranks (horizontal rows), with nPieces piece types</br>
	 * (color independent). If either nFiles or nRanks is less</br>
	 * than 1, a board with 8 files and 8 ranks is made. If nPieces</br>
	 * is less than 1, the number of color-independent piece types</br>
	 * is set to 6.
	 * @param nFiles number of files on this board. Must be at least 1.
	 * @param nRanks number of ranks on this board. Must be at least 1.
	 * @param nPieces number of possible piece types. Must be at least 1.
	 */
	public Board(int nFiles, int nRanks, int nPieces)
	{
		if(nFiles < 1 || nRanks < 1) // use defaults if board size is nonexistent
		{
			board = new int[8][8];
			virgin = new boolean[8][8];
		}
		else
		{
			board = new int[nRanks][nFiles];
			virgin = new boolean[nRanks][nFiles];
		}
		if(nPieces < 1) // use defaults if number of piece types is nonexistent
		{
			nPieces = 6;
		}
		nPieceTypes = nPieces;
		setUpperBounds();
	}
	
	/**
	 * Default Constructor<br>
	 * Creates a new board with the default settings.
	 */
	public Board()
	{
		board = new int[8][8];
		virgin = new boolean[8][8];
		nPieceTypes = 6;
		setUpperBounds();
		
		// set default starting position
		for(int i = 0; i <= maxXValue; ++i) // Pawns
		{
			setVirginPieceOnSquare(i, 1, 1);
			setVirginPieceOnSquare(i, 6, 7);
		}
		
		setVirginPieceOnSquare(0, 0, 4); // Rooks
		setVirginPieceOnSquare(7, 0, 4);
		setVirginPieceOnSquare(0, 7, 10);
		setVirginPieceOnSquare(7, 7, 10);
		
		setVirginPieceOnSquare(1, 0, 2); // Knights
		setVirginPieceOnSquare(6, 0, 2);
		setVirginPieceOnSquare(1, 7, 8);
		setVirginPieceOnSquare(6, 7, 8);
		
		setVirginPieceOnSquare(2, 0, 3); // Bishops
		setVirginPieceOnSquare(5, 0, 3);
		setVirginPieceOnSquare(2, 7, 9);
		setVirginPieceOnSquare(5, 7, 9);
		
		setVirginPieceOnSquare(3, 0, 5); // Queens
		setVirginPieceOnSquare(3, 7, 11);
		
		setVirginPieceOnSquare(4, 0, 6); // Kings
		setVirginPieceOnSquare(4, 7, 12);
		AddMove();
	}
	
	/**
	 * Sets upper bounds for x and y coordinates, which are used internally</br>
	 * for checking the validity of coordinates and piece values.
	 */
	private void setUpperBounds()
	{
		maxYValue = board.length - 1;
		maxXValue = board[0].length - 1;
		maxPieceValue = nPieceTypes * 2;
		hand = new int[maxPieceValue];
		promotionOptions = new boolean[nPieceTypes];
		promoteToCapturedOnly = new boolean[nPieceTypes];
		notOnLastRank = new boolean[nPieceTypes];
		customZoneDepths = new int[nPieceTypes];
	}
	
	// Information Methods for board parts
	
	public int[][] getBoard()
	{
		return board;
	}
	
	public int[] getHand()
	{
		return hand;
	}
	
	// Methods for Piece List
	
	public void createPieceList(String pieceDir, String wPrefix, String bPrefix, boolean useGIFImages)
	{
		pieceList = new PieceList(nPieceTypes, pieceDir, wPrefix, bPrefix, useGIFImages);
	}
	
	public void createPieceList()
	{
		pieceList = new PieceList();
	}
	
	public PieceList getPieceList()
	{
		return pieceList;
	}
	
	// Control and Information methods for board properties
	
	/**
	 * Gets the largest valid rank number.
	 * @return largest valid file number.
	 */
	public int getNFiles()
	{
		return maxXValue;
	}
	
	/**
	 * Gets the largest valid rank number.
	 * @return largest valid rank number.
	 */
	public int getNRanks()
	{
		return maxYValue;
	}
	
	/**
	 * Gets the number of color-independent piece types.
	 * @return the number of color-independent piece types.
	 */
	public int getNPieceTypes()
	{
		return nPieceTypes;
	}
	
	/**
	 * Gets the largest possible piece value for this board.
	 * @return the largest possible piece value for this board.
	 */
	public int getMaxPieces()
	{
		return maxPieceValue;
	}

	/**
	 * Set state of rule enforcement for piece moves
	 * @param enforceRules whether to enforce move rules
	 */
	public void setEnforceMoveRules(boolean enforceRules)
	{
		enforceMoveRules = enforceRules;
	}

	/**
	 * Get state of rule enforcement for piece moves
	 * @return whether rules are enforced for piece moves
	 */
	public boolean getEnforceMoveRules()
	{
		return enforceMoveRules;
	}

	/**
	 * Set whether drops are enabled
	 * @param enableDrops whether enable drops
	 */
	public void setEnableDrops(boolean enableDrops)
	{
		this.enableDrops = enableDrops;
	}

	/**
	 * Get state of drops
	 * @return whether drops are enabled
	 */
	public boolean getEnableDrops()
	{
		return enableDrops;
	}
	
	/**
	 * Set whether drop promotions are allowed
	 * @param allowDropPromotions whether drop promotions are allowed
	 */
	public void setAllowDropPromotions(boolean allowDropPromotions)
	{
		this.allowDropPromotions = allowDropPromotions;
		if(this.allowDropPromotions == true)
		{
			demoteOnCapture = true;
		}
	}

	/**
	 * Get whether drop promotions are allowed
	 * @return whether drop promotions are allowed
	 */
	public boolean getAllowDropPromotions()
	{
		return allowDropPromotions;
	}

	/**
	 * Set holdings type</br>
	 * -1: Captured pieces defect to capturer</br>
	 * 0: Holdings does not exist</br>
	 * 1: Captured pieces return to owner</br>
	 * Defaults to 0 if value is invalid
	 * @param enforceRules whether enable drops
	 */
	public void setHoldingsType(int holdingsType)
	{
		if(holdingsType < -1 || holdingsType > 1)
		{
			return;
		}
		this.holdingsType = holdingsType;
	}

	/**
	 * Get holdings type
	 * @return holdings type
	 */
	public int getHoldingsType()
	{
		return holdingsType;
	}

	/**
	 * Set whether captured pieces that have promoted demote or not
	 * @param demoteOnCapture whether captured pieces that have promoted demote or not
	 */
	public void setDemoteOnCapture(boolean demoteOnCapture)
	{
		if(allowDropPromotions == true)
		{
			this.demoteOnCapture = true;
		}
		else if(!promotionChoice.toString().equals("shogi") && !promotionChoice.toString().equals("capture") && !promotionChoice.toString().equals("microshogi"))
		{
			this.demoteOnCapture = false;
		}
		else
		{
			this.demoteOnCapture = demoteOnCapture;
		}
	}
	
	/**
	 * Get whether captured pieces that have promoted demote or not
	 * @return whether captured pieces that have promoted demote or not
	 */
	public boolean getDemoteOnCapture()
	{
		return demoteOnCapture;
	}

	/**
	 * Set number of promoting pieces
	 * @param number of promoting pieces
	 */
	public void setMaxPromotingPieces(int nPromotingPieces)
	{
		maxPromotingPieces = nPromotingPieces;
	}

	/**
	 * Get number of promoting pieces
	 * @return number of promoting pieces
	 */
	public int getMaxPromotingPieces()
	{
		return maxPromotingPieces;
	}

	/**
	 * Set number of promoting pieces
	 * @param thickness thickness of promotion zone
	 */
	public void setPromotionZone(int thickness)
	{
		promotionZone = thickness;
	}

	/**
	 * Get thickness of promotion zone
	 * @return thickness of promotion zone
	 */
	public int getPromotionZone()
	{
		return promotionZone;
	}

	/**
	 * Set list of pieces that can be promoted to. May</br>
	 * also be '+' or 'capture' for Shogi-style promotions.
	 * @param enforceRules whether to enforce move rules
	 */
	public void setPromotionChoice(String promotions)
	{
		promotionChoice = new StringBuffer(promotions);
		setPromoChoices();
	}

	/**
	 * Get promotion choice list
	 * @return whether rules are enforced for piece moves
	 */
	public String getPromotionChoice()
	{
		return promotionChoice.toString();
	}

	/**
	 * Set amount to add to piece number on Shogi-style promotions.</br>
	 * @param offset promotion offset. Cannot be < 0 or > nPiecTypes - 1.
	 */
	public void setPromotionOffset(int offset)
	{
		if(offset < 0)
		{
			promotionOffset = 0;
		}
		else if(offset > nPieceTypes - 1)
		{
			promotionOffset = nPieceTypes - 1;
		}
		else
		{
			promotionOffset = offset;
		}
	}

	/**
	 * Get promotion offset for Shogi-style promotions
	 * @return promotion offset
	 */
	public int getPromotionOffset()
	{
		return promotionOffset;
	}

	/**
	 * Set whether to force promotions.</br>
	 * 0: never</br>
	 * 1: as needed (force promotion if no moves left)</br>
	 * 2: always
	 * @param mode whether to enforce promotions. Cannot be < 0 or > 2.
	 */
	public void setForcePromotions(int mode)
	{
		if(mode < 0)
		{
			forcePromotions = 0;
		}
		else if(mode > 2)
		{
			forcePromotions = 2;
		}
		else
		{
			forcePromotions = mode;
		}
	}

	/**
	 * Get whether to force promotions
	 * @return whether to force promotions
	 */
	public int getForcePromotions()
	{
		return forcePromotions;
	}
	
	// Control and information methods for pieces in the hand
	
	/**
	 * Sets the number of pieces in a specific spot in the hand.
	 * @param piece the piece number. Cannot be < 1 or > maxPieceValue.
	 * @param nInHand the number of pieces in this spot in the hand. Cannot be < 0.
	 */
	public void setNPiecesInHand(int piece, int nInHand)
	{
		if(piece < 1 || piece > maxPieceValue)
		{
			return;
		}
		else if(nInHand < 0)
		{
			hand[piece - 1] = 0;
		}
		else
		{
			hand[piece - 1] = nInHand;
		}
	}
	
	/**
	 * Gets the number of pieces in a specific spot in the hand.
	 * @param piece the piece number. Cannot be < 1 or > maxPieceValue.
	 */
	public int getNPiecesInHand(int piece)
	{
		if(piece < 1 || piece > maxPieceValue)
		{
			return 0;
		}
		else
		{
			return hand[piece - 1];
		}
	}
	
	/**
	 * Manages the holdings. Used for putting captured pieces in the hand and</br>
	 * dropping pieces on the board. Does nothing if holdings does not exist</br>
	 * or the piece number is invalid.
	 * @param piece the piece number. Cannot be < 1 or > maxPieceValue.
	 * @param remove whether to remove the piece
	 */
	public void Hold(int piece, boolean remove)
	{
		
		if(piece < 1 || piece > maxPieceValue)
		{
			return;
		}
		else
		{
			int handPiece = piece;
			if(remove == false)
			{
				if(holdingsType != 0)
				{
					if(holdingsType == -1)
					{
						if(handPiece > nPieceTypes)
						{
							handPiece -= nPieceTypes;
						}
						else
						{
							handPiece += nPieceTypes;
						}
					}
					if(getPieceType(handPiece - promotionOffset) > 0 && getPieceType(handPiece - promotionOffset) <= maxPromotingPieces && demoteOnCapture == true)
					{
						handPiece -= promotionOffset;
					}
					++hand[handPiece - 1];
				}
				else
				{
					return;
				}
			}
			else
			{
				if(hand[handPiece - 1] > 0)
				{
					--hand[handPiece - 1];
				}
			}
		}
	}

	// Control and information methods for individual pieces on the board
	
	/**
	 * Sets square at coordinates (x,y) to the nth piece in the piece list.</br>
	 * Valid x-coordinates range from 0 to (number of files - 1).</br>
	 * Valid y-coordinates range from 0 to (number of ranks - 1).</br>
	 * Valid piece values range from -1 to the number of the last piece in</br>
	 * the list. 0 is an empty square. -1 is a hole in the board.
	 * @param x x-coordinate of square to set
	 * @param y y-coordinate of square to set
	 * @param piece number of piece to be set to.
	 */
	public void setPieceOnSquare(int x, int y, int piece)
	{
		if(x < 0 || x > maxXValue || y < 0 || y > maxYValue) // check validity of coordinates
		{
			return;
		}
		else if(piece < -1 || piece > maxPieceValue) // check validity of piece
		{
			return;
		}
		else
		{
			board[y][x] = piece; // set piece on square
		}
	}
	
	/**
	 * Sets square at coordinates (x,y) to the nth piece in the piece list.</br>
	 * This method also sets the virginity of the piece to true if</br>
	 * the piece is not an empty square or a hole.
	 * Valid x-coordinates range from 0 to (number of files - 1).</br>
	 * Valid y-coordinates range from 0 to (number of ranks - 1).</br>
	 * Valid piece values range from -1 to the number of the last piece in</br>
	 * the list. 0 is an empty square. -1 is a hole in the board.
	 * @param x x-coordinate of square to set
	 * @param y y-coordinate of square to set
	 * @param piece number of piece to be set to.
	 */
	public void setVirginPieceOnSquare(int x, int y, int piece)
	{
		if(x < 0 || x > maxXValue || y < 0 || y > maxYValue) // check validity of coordinates
		{
			return;
		}
		else if(piece < -1 || piece > maxPieceValue) // check validity of piece
		{
			return;
		}
		else
		{
			board[y][x] = piece; // set piece on square
			if(piece >= 1) // set virginity if not empty square or hole
			{
				virgin[y][x] = true; // piece is virgin
			}
		}
	}
	
	/**
	 * Gets the piece on the specified square.</br>
	 * Valid x-coordinates range from 0 to (number of files - 1).</br>
	 * Valid y-coordinates range from 0 to (number of ranks - 1).</br>
	 * @param x x-coordinate of the specified square
	 * @param y y-coordinate of the specified square
	 * @return the number of the piece on the square at coordinates (x,y).</br> 
	 * 0 is an empty square. -1 is a hole/off-board.
	 */
	public int getPieceOnSquare(int x, int y)
	{
		if(x < 0 || x > maxXValue || y < 0 || y > maxYValue)
		{
			return -1; // off-board
		}
		else
		{
			return board[y][x]; // number of piece on square
		}
	}
	
	/**
	 * Gets the piece type on the specified square.</br>
	 * Valid piece values range from 1 to maxPieceValue.
	 * @param piece piece number
	 * @return the number of the piece type.
	 */
	public int getPieceType(int piece)
	{
		if(piece < 0 || piece > maxPieceValue)
		{
			return 0;
		}
		else
		{
			int pieceType = piece;
			if(pieceType > nPieceTypes)
			{
				pieceType -= nPieceTypes;
			}
			return pieceType;
		}
	}
	
	public int getPieceColor(int index)
	{
		if(index < 1 || index > maxPieceValue)
		{
			return -1;
		}
		if(index > nPieceTypes)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	
	/**
	 * Gets the virginity of the piece piece on the specified square</br>
	 * (whether the piece has moved before).</br>
	 * Valid x-coordinates range from 0 to (number of files - 1).</br>
	 * Valid y-coordinates range from 0 to (number of ranks - 1).</br>
	 * @param x x-coordinate of the specified square
	 * @param y y-coordinate of the specified square
	 * @return whether the piece has moved before.</br> 
	 * defaults to false if the square is empty, a</br>
	 * hole, or off-board.
	 */
	public boolean getVirginity(int x, int y)
	{
		if(x < 0 || x > maxXValue || y < 0 || y > maxYValue)
		{
			return false; // off-board
		}
		else if(getPieceOnSquare(x, y) <= 0)
		{
			return false; // empty square or hole
		}
		else
		{
			return virgin[y][x]; // virginity of piece
		}
	}
	
	// Methods for moving pieces on the board.
	
	/**
	 * Carries out piece movements</br>
	 * @param x1 x-coordinate of origin square
	 * @param y1 y-coordinate of origin square
	 * @param ex array of x-coordinates for intermediate squares. Is null if absent.
	 * @param ey array of y-coordinates for intermediate squares. Is null if absent.
	 * @param x2 x-coordinate of destination square
	 * @param y2 y-coordinate of destination square
	 * @promotion the piece to be promoted to. -1 means no promotion.
	 */
	public void Move(int x1, int y1, ArrayList<Integer> ex, ArrayList<Integer> ey, int x2, int y2, int promotion)
	{
		if(x1 >= 1 && x1 <= maxPieceValue && y1 == -1)
		{
			MakeMove(x1, y1, null, null, x2, y2, promotion);
			AddMove(x1, y1, null, null, x2, y2, promotion);
		}
		else
		{
			int maxIntermediateMoves = 0; // set max intermediate moves
			if(ex != null && ey != null)
			{
				Math.min(ex.size(), ey.size());
			}
			if(maxIntermediateMoves > 0) // remove duplicates
			{
				if(x1 == ex.get(0) && y1 == ey.get(0)) // check origin and first intermediate square
				{
					return;
				}
				for(int j = 0; j < maxIntermediateMoves - 1; ++j) // check intermediate squares
				{
					if(ex.get(j) == ex.get(j + 1) && ey.get(j) == ey.get(j + 1)) // check last intermediate square and destination
					{
						ex.remove(j);
						ey.remove(j);
					}
				}
				if(ex.get(maxIntermediateMoves - 1) == x2 && ey.get(maxIntermediateMoves - 1) == y2)
				{
					ex.remove(maxIntermediateMoves - 1);
					ey.remove(maxIntermediateMoves - 1);
				}
			}
			else
			{
				if(x1 == x2 && y1 == y2)
				{
					return;
				}
			}
			int[] epx = null;
			if(ex != null)
			{
				epx = new int[maxIntermediateMoves];
				for(int j = 0; j < maxIntermediateMoves; ++j)
				{
					epx[j] = ex.get(j);
				}
			}
			int[] epy = null;
			if(ey != null)
			{
				epy = new int[maxIntermediateMoves];
				for(int j = 0; j < maxIntermediateMoves; ++j)
				{
					epy[j] = ey.get(j);
				}
			}
			
			if(promotion == board[y1][x1])
			{
				promotion = -1;
			}
			MakeMove(x1, y1, epx, epy, x2, y2, promotion);
			AddMove(x1, y1, ex, ey, x2, y2, promotion);
		}
	}
	
	/**
	 * Adds a move to the game log.
	 * @param x1 x-coordinate of origin
	 * @param y1 y-coordinate of origin
	 * @param ex array of x-coordinates for intermediate squares
	 * @param ey array of y-coordinates for intermediate squares
	 * @param x2 x-coordinate of destination
	 * @param y2 y-coordinate of destination
	 * @param promotion the promotion of this piece
	 */
	public void AddMove(int x1, int y1, ArrayList<Integer> ex, ArrayList<Integer> ey, int x2, int y2, int promo)
	{
		BoardPosition position = new BoardPosition(board, hand, x1, y1, ex, ey, x2, y2, promo);
		game.add(position);
		++displayed;
	}
	
	public void AddMove()
	{
		BoardPosition position = new BoardPosition(board, hand, -1, -1, null, null, -1, -1, -1);
		game.add(position);
	}
	
	/**
	 * Moves a piece from one square to the other, replacing the</br>
	 * piece on the destination square. If the piece being moved</br>
	 * is an empty square/hole or any of the squares being moved</br>
	 * to is a hole/off-board, nothing happens. Intermediate</br>
	 * if present are specified using two int arrays. If one is</br>
	 * shorter than the other, the excess numbers in the longer</br>
	 * array  are ignored. If one array is absent, the other is</br>
	 * ignored entirely.
	 * @param x1 x-coordinate of origin square
	 * @param y1 y-coordinate of origin square
	 * @param ex array of x-coordinates for intermediate squares. Is null if absent.
	 * @param ey array of y-coordinates for intermediate squares. Is null if absent.
	 * @param x2 x-coordinate of destination square
	 * @param y2 y-coordinate of destination square
	 * @promotion the piece to be promoted to. -1 means no promotion.
	 */
	public void MakeMove(int x1, int y1, int[] ex, int[] ey, int x2, int y2, int promotion)
	{
		int origin = getPieceOnSquare(x1, y1);
		int dest = getPieceOnSquare(x2, y2);
		int maxIntermediateMoves = 0;
		
		if(origin <= 0 && !(x1 >= 1 && x1 <= maxPieceValue && y1 == -1)) // exit early if piece on square cannot be moved
		{
			return;
		}
		else if(dest == -1) // exit early if destination square cannot be moved to
		{
			return;
		}
		
		if(x1 >= 1 && x1 <= maxPieceValue && y1 == -1)
		{
			if(!enableDropCaptures && board[y2][x2] != 0)
			Hold(board[y2][x2], false);
			board[y2][x2] = x1;
			virgin[y2][x2] = false;
			Hold(x1, true);
			if(promotion >= 0 && promotion <= maxPieceValue)
			{
				board[y2][x2] = promotion;
			}
			return;
		}
		
		if(ex != null && ey != null) // exit early if any intermediate square cannot be moved to
		{
			maxIntermediateMoves = Math.min(ex.length, ey.length);
			for(int i = 0; i < maxIntermediateMoves; ++i) // exit early if piece on square cannot be moved
			{
				if(getPieceOnSquare(ex[i], ey[i]) == -1)
				{
					return;
				}
			}
		}
	
		if(ex != null && ey != null)
		{
			int epx = ex[0]; // store current intermediate x-coordinate
			int epy = ey[0]; // store current intermediate y-coordinate
			
			Hold(board[epy][epx], false);
			board[epy][epx] = board[y1][x1];
			board[y1][x1] = 0;
			virgin[y1][x1] = false;
			
			int epx2 = -1;
			int epy2 = -1;
			for(int i = 0; i < (maxIntermediateMoves - 1); ++i)
			{
				epx = ex[i];
				epy = ey[i];
				epx2 = ex[i + 1];
				epy2 = ey[i + 1];
				
				Hold(board[epy2][epx2], false);
				board[epy2][epx2] = board[epy][epx];
				board[epy][epx] = 0;
				virgin[epy][epx] = false;
			}
			
			if(epx2 > -1 && epy2 > -1)
			{
				Hold(board[y2][x2], false);
				board[y2][x2] = board[epy2][epx2];
				board[epy2][epx2] = 0;
				virgin[epy2][epx2] = false;
			}
			else
			{
				Hold(board[y2][x2], false);
				board[y2][x2] = board[epy][epx];
				board[epy][epx] = 0;
				virgin[epy][epx] = false;
			}
		}
		else
		{
			Hold(board[y2][x2], false);
			board[y2][x2] = board[y1][x1];
			board[y1][x1] = 0;
			virgin[y1][x1] = false;
		}
		
		if(promotion >= 0 && promotion <= maxPieceValue)
		{
			board[y2][x2] = promotion;
		}
	}
	
	// Methods for managing of the game
	
	/**
	 * Navigates to a particular move in the game</br>
	 * according to the seek mode.
	 * 0 - go to beginning
	 * 1 - go 1 move backward
	 * 2 - go 1 move forward
	 * 3 - go to end
	 * Defaults to 3 if seek mode is not valid
	 * @param mode the seek mode
	 */
	public void Seek(int mode)
	{
		int target;
		if(mode == 0)
		{
			target = 0;
		}
		else if(mode == 1)
		{
			target = Math.max(0, displayed - 1);
		}
		else if(mode == 2)
		{
			target = Math.min(game.size() - 1, displayed + 1);
		}
		else
		{
			target = game.size() - 1;
		}
		
		BoardPosition position = game.get(target);
		for(int i = 0; i <= maxYValue; ++i)
		{
			for(int j = 0; j <= maxXValue; ++j)
			{
				board[i][j] = position.getPositionSquare(j, i);
			}
		}
		int[] newHand = position.getHoldings();
		for(int i = 1; i <= maxPieceValue; ++i)
		{
			hand[i - 1] = newHand[i - 1];
		}
		displayed = target;
	}
		
	/**
	 * Determines whether the current position is being displayed.
	 * @return whether the displayed position is the current one
	 */
	public boolean isCurrentPosition()
	{
		return displayed == game.size() - 1;
	}
	
	
	/**
	 * Get number of the current position is being displayed.
	 * @return the current board position number
	 */
	public int getDisplayed()
	{
		return displayed;
	}
	
	public ArrayList<BoardPosition> getGame()
	{
		return game;
	}
	
	public void newGame()
	{
		while(game.size() > 1)
		{
			game.remove(game.size() - 1);
		}
		Seek(0);
	}
	
	// Methods for handling promotions
	
	public boolean isInsidePromotionZone(int y, int piece)
	{
		if(promotionZone <= 0)
		{
			return false;
		}
		int zone;
		if(piece > nPieceTypes)
		{
			zone = promotionZone;
			return y >= 0 && y < zone;
		}
		else
		{
			zone = maxYValue - promotionZone;
			return y > zone && y <= maxYValue;
		}
	}
	
	public boolean isInsidePromotionZone(int y, int piece, int zoneSize)
	{
		if(promotionZone <= 0)
		{
			return false;
		}
		int zone;
		if(piece > nPieceTypes)
		{
			zone = zoneSize;
			return y >= 0 && y < zone;
		}
		else
		{
			zone = maxYValue - zoneSize;
			return y > zone && y <= maxYValue;
		}
	}
	
	public int shogiPromotion(int piece)
	{
		int newPiece = piece + promotionOffset;
		return newPiece;
	}
	
	public int shogiDemotion(int piece)
	{
		int newPiece = piece - promotionOffset;
		return newPiece;
	}
	
	public boolean isPromotable(int piece)
	{
		boolean isPromotable = (getPieceType(piece) > 0 && getPieceType(piece) <= maxPromotingPieces);
		return isPromotable;
	}
	
	public boolean isDemotable(int piece)
	{
		return isPromotable(piece - promotionOffset);
	}
	
	public void setPromoChoices()
	{
		boolean mustTakeFromHoldings;
		boolean notAvailableOnLastRank;
		promotionOptions = new boolean[nPieceTypes];
		
		String promoChoice = promotionChoice.toString().replaceAll("\\s", "");
		if(promoChoice.equals("shogi") || promoChoice.equals("capture") || promoChoice.equals("microshogi"))
		{
			return;
		}
		
		ArrayList<String> customZoneDepthsReg = new ArrayList<String>(); // create ArrayList for numbers
		Pattern p = Pattern.compile("\\d+");
		Matcher m = p.matcher(promoChoice);
		while(m.find())
		{
			customZoneDepthsReg.add(m.group());
		}
		
		int index = 0;
		int choiceIndex = 0;
		int customZoneDepthIndex = 0;
		
		while(index < promoChoice.length())
		{
			mustTakeFromHoldings = false;
			notAvailableOnLastRank = false;
			if(promoChoice.charAt(index) == '*') // allow promotion only if this piece is captured
			{
				mustTakeFromHoldings = true;
				++index; // advance to the next element in promotion choice list
			}
			if(promoChoice.charAt(index) == '!') // allow promotion only if this piece is captured
			{
				notAvailableOnLastRank = true;
				++index; // advance to the next element in promotion choice list
			}
			if(promoChoice.charAt(index) >= 'A' && promoChoice.charAt(index) <= 'Z') // uppercase letters
			{
				String ID = Character.toString(promoChoice.charAt(index)).toUpperCase(); // ID to search for
				int piece = idToPiece(ID); // search for piece
				if(piece < 0) // exit if piece is not supported
				{
					promotionOptions = new boolean[nPieceTypes];
					promoteToCapturedOnly = new boolean[nPieceTypes];
					notOnLastRank = new boolean[nPieceTypes];
					customZoneDepths = new int[nPieceTypes];
					return;
				}
				else
				{
					choiceIndex = piece - 1;
					promotionOptions[choiceIndex] = true;
					promoteToCapturedOnly[choiceIndex] = mustTakeFromHoldings;
					notOnLastRank[choiceIndex] = notAvailableOnLastRank;
					++index; // advance to the next element in promotion choice list
				}
			}
			else if(promoChoice.charAt(index) >= 'a' && promoChoice.charAt(index) <= 'z') // lowercase letters
			{
				String ID = Character.toString(promoChoice.charAt(index)).toUpperCase(); // ID to search for
				int piece = idToPiece(ID); // search for piece
				if(piece < 0) // exit if piece is not supported
				{
					promotionOptions = new boolean[nPieceTypes];
					promoteToCapturedOnly = new boolean[nPieceTypes];
					notOnLastRank = new boolean[nPieceTypes];
					customZoneDepths = new int[nPieceTypes];
					return;
				}
				else
				{
					choiceIndex = piece - 1;
					promotionOptions[choiceIndex] = true;
					promoteToCapturedOnly[choiceIndex] = mustTakeFromHoldings;
					notOnLastRank[choiceIndex] = notAvailableOnLastRank;
					++index; // advance to the next element in promotion choice list
				}
			}
			else if(promoChoice.charAt(index) == '{') // piece ID enclosed in curly brackets
			{
    			int endPosition = promoChoice.indexOf("}", index);
    			String pieceID = promoChoice.substring(index + 1, endPosition);
    			if(pieceID.equals(pieceID.toUpperCase()))
    			{
    				int piece = idToPiece(pieceID);
					if(piece < 0) // exit if piece is not supported
					{
						promotionOptions = new boolean[nPieceTypes];
						promoteToCapturedOnly = new boolean[nPieceTypes];
						notOnLastRank = new boolean[nPieceTypes];
						customZoneDepths = new int[nPieceTypes];
						return;
					}
					else
					{
						choiceIndex = piece - 1;
						promotionOptions[choiceIndex] = true;
						promoteToCapturedOnly[choiceIndex] = mustTakeFromHoldings;
						notOnLastRank[choiceIndex] = notAvailableOnLastRank;
					}
    			}
    			else if(pieceID.equals(pieceID.toLowerCase()))
    			{
    				int piece = idToPiece(pieceID.toUpperCase());
					if(piece < 0) // exit if piece is not supported
					{
						return;
					}
					else
					{
						choiceIndex = piece - 1;
						promotionOptions[choiceIndex] = true;
						promoteToCapturedOnly[choiceIndex] = mustTakeFromHoldings;
						notOnLastRank[choiceIndex] = notAvailableOnLastRank;
					}
    			}
    			else
    			{
    				return;
    			}
				index += pieceID.length() + 2; // advance to the next element in FEN hand
			}
			else if(promoChoice.charAt(index) >= '0' && promoChoice.charAt(index) <= '9')
			{
				customZoneDepths[choiceIndex] = Integer.parseInt(customZoneDepthsReg.get(customZoneDepthIndex)); // update corresponding custom promotion zone depth 
				index += customZoneDepthsReg.get(customZoneDepthIndex).length(); // advance past the number
				++customZoneDepthIndex; // increment counter for next match
			}
			else
			{
				promotionOptions = new boolean[nPieceTypes];
				promoteToCapturedOnly = new boolean[nPieceTypes];
				notOnLastRank = new boolean[nPieceTypes];
				customZoneDepths = new int[nPieceTypes];
				return;
			}
		}
	}
	
	public boolean[] getPromoChoices(int y, int piece)
	{
		boolean[] choices = new boolean[nPieceTypes];
		for(int i = 0; i < choices.length; ++i)
		{
			int pieceIndex = i;
			if(getPieceColor(piece) == 0)
			{
				pieceIndex += nPieceTypes;
			}
			choices[i] = promotionOptions[i];
			if(promoteToCapturedOnly[i] == true && hand[pieceIndex] <= 0)
			{
				choices[i] = false;
			}
			if(notOnLastRank[i] == true && isInsidePromotionZone(y, piece, 1))
			{
				choices[i] = false;
			}
			if(customZoneDepths[i] > 0 && !isInsidePromotionZone(y, piece, customZoneDepths[i]))
			{
				choices[i] = false;
			}
		}
		return choices;
	}
	
	public boolean[] getTakeFromHoldings()
	{
		return promoteToCapturedOnly;
	}
	
	public int idToPiece(String id)
	{
		String searchID = id.toUpperCase();
		for(int i = 1; i <= nPieceTypes; ++i)
		{
			if(searchID.equals(pieceList.getPiece(i).getPieceID()))
			{
				return i;
			}
		}
		return -1;
	}
	
	public boolean isContagiousPromotion(int piece)
	{
		if(piece < 1 || piece > maxPieceValue)
		{
			return false;
		}
		return pieceList.getPiece(piece).getContagiousPromotion();
	}
	
	public boolean isContagious(int piece)
	{
		if(piece < 1 || piece > maxPieceValue)
		{
			return false;
		}
		return pieceList.getPiece(piece).getContagious();
	}
	
	public boolean isRoyal(int piece)
	{
		if(piece < 1 || piece > maxPieceValue)
		{
			return false;
		}
		return pieceList.getPiece(piece).getRoyalty() == 1;
	}
	
	public boolean isIron(int piece)
	{
		if(piece < 1 || piece > maxPieceValue)
		{
			return false;
		}
		return pieceList.getPiece(piece).getRoyalty() == 2;
	}
}
