package board;

public class PieceInHand {
	private int piece;
	private int nInHand;
	
	public PieceInHand(int piece, int nInHand)
	{
		this.piece = piece;
		this.nInHand = nInHand;
	}
	
	public int getPiece()
	{
		return piece;
	}
	
	public int getNInHand()
	{
		return nInHand;
	}
}
