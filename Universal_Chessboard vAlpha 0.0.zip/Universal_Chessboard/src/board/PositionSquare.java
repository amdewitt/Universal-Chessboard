package board;

public class PositionSquare {
	private int x;
	private int y;
	private int piece;
	
	public PositionSquare(int x, int y, int piece)
	{
		this.x = x;
		this.y = y;
		this.piece = piece;
	}
	
	public int getX()
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	
	public int getPiece()
	{
		return piece;
	}
}
