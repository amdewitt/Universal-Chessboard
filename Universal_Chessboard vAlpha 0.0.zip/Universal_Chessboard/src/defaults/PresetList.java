package defaults;

/**
 * The PresetList class stores all of the default presets used in the Universal Chessboard so they can be</br>
 * fetched regardless of whether the program is run in Eclipse or from a .jar file.
 */
public class PresetList {
	private static String cannon_shosu_shogi = "files=10\n" + 
			"ranks=10\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=10\n" + 
			"promoZone=3\n" + 
			"promoOffset=11\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=7,1\n" + 
			"forceShogiPromotionZone=8,2\n" + 
			"graphicsDir=/futashikana_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=45\n" + 
			"pawn:P:fW:p:a3-j3\n" + 
			"dog:D:bFfW:d:c4,h4\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:i2\n" + 
			"silver cannon:I:mBcpB:i:d2,g2\n" + 
			"gold cannon:C:mRcpR:c:c2,h2\n" + 
			"lance:L:fR:l:a1,j1\n" + 
			"knight:N:ffN:n:b1,i1\n" + 
			"silver general:S:FfW:s:c1,h1\n" + 
			"gold general:G:WfF:g:d1,g1\n" + 
			"queen:Q:Q:q:e1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"side mover:+D:WsR:d2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"bishop general:+I:BWDcpB:i2:\n" + 
			"rook general:+C:RFAcpR:c2:\n" + 
			"vertical mover:+L:WvR:l2:\n" + 
			"white horse:+N:N:n2:\n" + 
			"vice general:+S:WfF:s2:\n" + 
			"great general:+G:FfsW:g2:\n" + 
			"king:K:K:k:f1";
	
	private static String chess = "default";
	
	private static String chushin_shogi = "files=18\n" + 
			"ranks=18\n" + 
			"maxPromote=44\n" + 
			"promoZone=4\n" + 
			"promoOffset=50\n" + 
			"promoChoice=shogi\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=62\n" + 
			"royal=95\n" + 
			"symmetry=rotate\n" + 
			"squareSize=41\n" + 
			"pawn:P:fW:p:a6-r6\n" + 
			"dog:D:bFfW:d:f7,m7\n" + 
			"knight:N:N:n:b1,q1\n" + 
			"iron general:I:fFbW:i:d1,o1\n" + 
			"copper general:C:fFvW:c:e1,n1\n" + 
			"silver general:S:FfW:s:f1,m1\n" + 
			"blind tiger:BT:FsbW:bt:g2,l2\n" + 
			"ferocious leopard:FL:FvW:fl:c1,p1\n" + 
			"gold general:G:WfF:g:g1,l1\n" + 
			"left general:LT:FvrW:lt:h1\n" + 
			"right general:RT:FvlW:rt:k1\n" + 
			"drunk elephant:DE:FsfW:de:i1\n" + 
			"flying horse:FH:F2:fh:e3,n3\n" + 
			"flying dragon:FN:W2:fn:f3,m3\n" + 
			"roaring dog:RD:K3:rd:d2,o2\n" + 
			"reverse chariot:RV:vR:rv:a2,r2\n" + 
			"lance:L:fRbW2:l:a1,r1\n" + 
			"kirin:KY:FD:ky:h3\n" + 
			"phoenix:PH:WA:ph:k3\n" + 
			"side mover:SM:WsR:sm:a5,r5\n" + 
			"vertical mover:VM:WvR:vm:b5,q5\n" + 
			"bishop:B:B:b:c4,p4\n" + 
			"side soldier:SS:WsRfW2:ss:a4,r4\n" + 
			"vertical soldier:VS:WfRsW2:vs:b4,q4\n" + 
			"rook:R:R:r:c5,p5\n" + 
			"side chariot:SC:sRvW2:sc:a3,r3\n" + 
			"vertical chariot:VC:vRsW2:vc:b3,q3\n" + 
			"dragon horse:DH:BW:dh:e4,n4\n" + 
			"dragon king:DK:RF:dk:f4,m4\n" + 
			"violent falcon:VF:BN:vf:d4,o4\n" + 
			"fierce eagle:VE:RN:ve:d5,o5\n" + 
			"chariot soldier:CS:BvRsW2:cs:c2,e2,n2,p2\n" + 
			"horned falcon:HF:BbsRfWfDfcavWfmabW:hf:e5,n5\n" + 
			"soaring eagle:SE:RbBfFfAfcavFfmabF:se:f5,m5\n" + 
			"lion:LN:KNADcaKmcabK:ln:i3\n" + 
			"lion dog:LD:KADGHcafKmcabKcafmpafKmpafcavK:ld:k2\n" + 
			"queen:Q:Q:q:j3\n" + 
			"free eagle:FE:QADcasFcafFmcabF:fe:j4\n" + 
			"lion hawk:LH:BWNADcaKmcabK:lh:i4\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:g5,l5\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:h5,k5\n" + 
			"violent horse:VH:R3pafpafcBmcBcpB:vh:i5,j5\n" + 
			"violent dragon:VD:B3pafpafcRmcRcpR:vd:g3,l3\n" + 
			"water buffalo:WB:BsRvW2:wb:g4,l4\n" + 
			"free demon:HK:BsRvW5:hk:d3,o3\n" + 
			"free dream eater:HB:BvRsW5:hb:c3,p3\n" + 
			"furious fiend:FF:KNADGHcaKmcabKcafmpafKmpafcavK:ff:h2\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:j2\n" + 
			"great general:GG:pafpafcQmcQcpQ:gg:i2\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:h4,k4\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"shogun:+LT:KaKaaKmabK:lt2:\n" + 
			"shogun:+RT:KaKaaKmabK:rt2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"violent falcon:+FH:BN:fh2:\n" + 
			"fierce eagle:+FN:RN:fn2:\n" + 
			"lion dog:+RD:KADGHcafKmcabKcafmpafKmpafcavK:rd2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"chariot soldier:+VS:BvRsW2:vs2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"free demon:+SC:BsRvW5:sc2:\n" + 
			"free dream eater:+VC:BvRsW5:vc2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"violent horse:+VF:R3pafpafcBmcBcpB:vf2:\n" + 
			"violent dragon:+VE:B3pafpafcRmcRcpR:ve2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"bishop general:+HF:pafpafcBmcBcpB:hf2:\n" + 
			"rook general:+SE:pafpafcRmcRcpR:se2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"furious fiend:+LD:KNADGHcaKmcabKcafmpafKmpafcavK:ld2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"golden bird:+FE:QDcasWcafWmcabW:fe2:\n" + 
			"great dragon:+LH:RFNADcaKmcabK:lh2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"horse master:+VH:pafpafcBmcBcpBKaKmabK:vh2:\n" + 
			"dragon master:+VD:pafpafcRmcRcpRKaKmabK:vd2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"king:K:K:k:j1";
	
	private static String futashikana_shogi = "files=11\n" + 
			"ranks=11\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=11\n" + 
			"promoZone=3\n" + 
			"promoOffset=12\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=8,1\n" + 
			"forceShogiPromotionZone=9,2\n" + 
			"graphicsDir=/futashikana_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=45\n" + 
			"pawn:P:fW:p:a3-c3,d4,e3-g3,h4,i3-k3\n" + 
			"kirin:O:FD:o:b1\n" + 
			"phoenix:X:WA:x:j1\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:j2\n" + 
			"side soldier:M:sRfR2:m:d3\n" + 
			"vertical soldier:V:fRsR2:v:h3\n" + 
			"lance:L:fR:l:a1,k1\n" + 
			"knight:N:ffN:n:c1,i1\n" + 
			"silver general:S:FfW:s:d1,h1\n" + 
			"gold general:G:WfF:g:e1,g1\n" + 
			"queen:Q:Q:q:f2\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"horned falcon:+O:BN:o2:\n" + 
			"soaring eagle:+X:RN:x2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"water buffalo:+M:BsRvW2:m2:\n" + 
			"chariot soldier:+V:BvRsW2:v2:\n" + 
			"vertical mover:+L:WvR:l2:\n" + 
			"white horse:+N:N:n2:\n" + 
			"vice general:+S:WfF:s2:\n" + 
			"great general:+G:FfsW:g2:\n" + 
			"king:K:K:k:f1";
	
	private static String grand_chess = "author=Christian Freeling\n" + 
			"files=10\n" + 
			"ranks=10\n" + 
			"holdingsType=1\n" + 
			"promoZone=3\n" + 
			"promoChoice=*Q*M*A*R*B*N!P\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDifmnHfmWfceF:pawn:a3-j3\n" + 
			"knight:N:N:knight:b2,i2\n" + 
			"bishop:B:B:bishop:c2,h2\n" + 
			"rook:R:R:rook:a1,j1\n" + 
			"queen:Q:Q:queen:d2\n" + 
			"marshall:M:RN:marshall:f2\n" + 
			"archbishop:A:BN:archbishop:g2\n" + 
			"king:K:K:king:e2";
	
	private static String gross_chess = "author=Fergus Duniho\n" + 
			"files=12\n" + 
			"ranks=12\n" + 
			"holdingsType=1\n" + 
			"promoZone=3\n" + 
			"promoChoice=!P*N*B*R2*S2*W*C2*V*A1*M1*Q1\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a3-l3\n" + 
			"knight:N:N:knight:d2,i2:4\n" + 
			"bishop:B:B:bishop:e2,h2:4\n" + 
			"rook:R:R:rook:b2,k2:4\n" + 
			"queen:Q:Q:queen:f2:2\n" + 
			"wizard:W:FC:wizard:d1,i1\n" + 
			"champion:S:WAD:champion:c2,j2\n" + 
			"marshall:M:RN:marshall:a1,l1\n" + 
			"archbishop:A:BN:archbishop:b1,k1\n" + 
			"cannon:C:mRcpR:cannon:e1,h1\n" + 
			"vao:V:mBcpB:vao:c1,j1\n" + 
			"king:K:KilO4isO3isO2:king:g2";
	
	private static String hectochess = "files=10\n" + 
			"ranks=10\n" + 
			"promoChoice=QMARSONBW\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a3-j3\n" + 
			"knight:N:N:knight:c2,h2\n" + 
			"bishop:B:B:bishop:d2,g2\n" + 
			"rook:R:R:rook:a2,j2\n" + 
			"queen:Q:Q:queen:e2\n" + 
			"wizard:W:FC:wizard:b1,i1\n" + 
			"champion:S:WAD:champion:b2,i2\n" + 
			"marshall:M:RN:marshall:a1\n" + 
			"archbishop:A:BN:archbishop:j1\n" + 
			"leo:O:mQcpQ:leo:c1,h1\n" + 
			"king:K:KisO3isO2:king:f2";
	
	private static String hook_shogi = "files=19\n" + 
			"ranks=19\n" + 
			"maxPromote=49\n" + 
			"promoZone=0\n" + 
			"promoOffset=51\n" + 
			"promoChoice=capture\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=49\n" + 
			"royal=99\n" + 
			"royal=100\n" + 
			"contagiousPromotion=46\n" + 
			"contagiousPromotion=47\n" + 
			"contagious=97\n" + 
			"contagious=98\n" + 
			"symmetry=rotate\n" + 
			"squareSize=41\n" + 
			"pawn:P:fW:p:a6-s6\n" + 
			"dog:D:bFfW:d:f7,n7\n" + 
			"knight:N:N:n:c4,q4\n" + 
			"earth general:E:vW:e:b1,r1\n" + 
			"stone general:O:fF:o:c1,q1\n" + 
			"tile general:T:fFbW:t:d1,p1\n" + 
			"iron general:I:fFfW:i:e1,o1\n" + 
			"copper general:C:fFvW:c:f1,n1\n" + 
			"silver general:S:FfW:s:g1,m1\n" + 
			"blind tiger:BT:FsbW:bt:i2,k2\n" + 
			"ferocious leopard:FL:FvW:fl:h2,l2\n" + 
			"gold general:G:WfF:g:h1,l1\n" + 
			"cat sword:CT:F:ct:c2,q2\n" + 
			"angry boar:AB:W:ab:d3,p3\n" + 
			"evil wolf:EW:fFfsW:ew:h3,l3\n" + 
			"coiled serpent:CO:bFvW:co:g2\n" + 
			"blind dog:BD:fFsbW:bd:e2\n" + 
			"old monkey:OM:FbW:om:o2\n" + 
			"reclining dragon:RN:WbF:rn:m2\n" + 
			"flying horse:FH:F2:fh:g4,m4\n" + 
			"flying dragon:FN:W2:fn:e4,o4\n" + 
			"roaring dog:RD:K3:rd:a4,s4\n" + 
			"reverse chariot:RV:vR:rv:a2,s2\n" + 
			"lance:L:fRbW2:l:a1,s1\n" + 
			"kirin:KY:FD:ky:h4,l4\n" + 
			"phoenix:PH:WA:ph:i3,k3\n" + 
			"warrior:WR:WfFA:wr:i4\n" + 
			"poisonous snake:PS:FvWD:ps:k4\n" + 
			"left chariot:LC:fRbWflbrB:lc:b5\n" + 
			"right chariot:RC:fRbWfrblB:rc:r5\n" + 
			"side mover:SM:WsR:sm:c5,q5\n" + 
			"vertical mover:VM:WvR:vm:e5,o5\n" + 
			"bishop:B:B:b:f5,n5\n" + 
			"rook:R:R:r:a5,s5\n" + 
			"side chariot:SC:sRvW2:sc:d5,p5\n" + 
			"vertical chariot:VC:vRsW2:vc:f3,n3\n" + 
			"dragon horse:DH:BW:dh:g5,m5\n" + 
			"dragon king:DK:RF:dk:h5,l5\n" + 
			"fire dragon:F:RfB4bB2:f:b3,r3\n" + 
			"water dragon:W:RbB4fB2:w:a3,s3\n" + 
			"earth dragon:H:BsR4vR2:h:b2,r2\n" + 
			"wind dragon:A:BvR4sR2:a:b4,r4\n" + 
			"lion:LN:KNADcaKmcabK:ln:j3\n" + 
			"lion dog:LD:KADGHcafKmcabKcafmpafKmpafcavK:ld:j4\n" + 
			"queen:Q:Q:q:j5\n" + 
			"deva:DV:lfbFW:dv:i1\n" + 
			"dark spirit:DS:rfbFW:ds:k1\n" + 
			"drunk elephant:DE:FsfW:de:j2\n" + 
			"king:K:K:k:j1\n" + 
			"tengu:TG:WBmasB:tg:i5\n" + 
			"hook mover:HM:RmasR:hm:k5\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"reverse chariot:+E:vR:e2:\n" + 
			"side chariot:+O:sRvW2:o2:\n" + 
			"vertical chariot:+T:vRsW2:t2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"free cat:+CT:B:ct2:\n" + 
			"running boar:+AB:R:ab2:\n" + 
			"free wolf:+EW:KsR:ew2:\n" + 
			"free serpent:+CO:bBvR:co2:\n" + 
			"wizard stork:+BD:BsfRbW:bd2:\n" + 
			"mountain witch:+OM:BsbRfW:om2:\n" + 
			"free dragon:+RN:RbB:rn2:\n" + 
			"violent falcon:+FH:BN:fh2:\n" + 
			"fierce eagle:+FN:RN:fn2:\n" + 
			"lion dog:+RD:KADGHcafKmcabKcafmpafKmpafcavK:rd2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"tengu:+WR:WBmasB:wr2:\n" + 
			"hook mover:+PS:RmasR:ps2:\n" + 
			"left army:+LC:KrvBrR:lc2:\n" + 
			"right army:+RC:KlvBlR:rc2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"free demon:+SC:BsRvW5:sc2:\n" + 
			"free dream eater:+VC:BvRsW5:vc2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"kirin master:+F:BbsRfWfDfHfcafWfmcabWfcafmpafWfmpafcavW:f2:\n" + 
			"phoenix master:+W:RbBfFfAfGfcafFfmcabFfcafmpafFfmpafcavF:w2:\n" + 
			"earthward net:+H:BWaKmabK:h2:\n" + 
			"skyward net:+A:RFaKmabK:a2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"furious fiend:+LD:KNADGHcaKmcabKcafmpafKmpafcavK:ld2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"teaching king:+DV:QADGHcafKmcabKcafmpafKmpafcavK:dv2:\n" + 
			"divine dragon:+DS:QNADcaKmcabK:ds2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"emperor:+K:U:k2:";
	
	private static String manchu_chess = "files=9\n" + 
			"ranks=10\n" + 
			"promoZone=5\n" + 
			"promoOffset=1\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/xiangqi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"shades=111000111/111000111/111000111/111111111/111111111/000000000/000000000/000111000/000111000/000111000\n" + 
			"symmetry=none\n" + 
			"squareSize=54\n" + 
			"soldier:S:fW:soldier:a4,c4,e4,g4,i4,,a7,c7,e7,g7,i7\n" + 
			"soldier:Q:fsW:soldier:\n" + 
			"cannon:C:mRcpR:cannon:,,b8,h8\n" + 
			"chariot:R:R:chariot:,,a10,i10\n" + 
			"manchu chariot:M:RcpRmafsW:chariot:a1\n" + 
			"horse:H:mafsW:horse:,,b10,h10\n" + 
			"elephant:E:mafF:elephant:c1,g1,,c10,g10\n" + 
			"advisor:A:F:advisor:d1,f1,,d10,f10\n" + 
			"general:G:WfkR:general:e1,,e10";
	
	private static String microshogi = "author=Oyama Yasuharu (attributed)\n" + 
			"files=4\n" + 
			"ranks=5\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"allowDropPromotions=true\n" + 
			"maxPromote=4\n" + 
			"promoZone=0\n" + 
			"promoOffset=4\n" + 
			"promoChoice=microshogi\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/shogi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=54\n" + 
			"pawn:P:fW:p:d2\n" + 
			"bishop:B:B:b:c1\n" + 
			"silver general:S:FfW:s:a1\n" + 
			"gold general:G:WfF:g:b1\n" + 
			"knight:+P:ffN:n:\n" + 
			"tokin:+B:BW:p2:\n" + 
			"lance:+S:fR:l:\n" + 
			"rook:+G:R:r:\n" + 
			"king:K:K:k:d1";
	
	private static String minishogi = "author=Shigenobu Kusumoto\n" + 
			"files=5\n" + 
			"ranks=5\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=4\n" + 
			"promoOffset=5\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"graphicsDir=/shogi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=54\n" + 
			"pawn:P:fW:p:a2\n" + 
			"bishop:B:B:b:d1\n" + 
			"rook:R:R:r:e1\n" + 
			"silver general:S:FfW:s:c1\n" + 
			"gold general:G:WfF:g:b1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"promoted silver:+S:WfF:s2:\n" + 
			"king:K:K:k:a1";
	
	private static String mitsugumi_shogi = "files=13\n" + 
			"ranks=13\n" + 
			"maxPromote=22\n" + 
			"promoZone=4\n" + 
			"promoOffset=24\n" + 
			"promoChoice=shogi\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=41\n" + 
			"pawn:P:fW:p:a4-m4\n" + 
			"dog:D:bFfW:d:d5,j5\n" + 
			"knight:N:N:n:b1,l1\n" + 
			"silver general:S:FfW:s:d1,j1\n" + 
			"blind tiger:BT:FsbW:bt:f1,h1\n" + 
			"ferocious leopard:FL:FvW:fl:c1,k1\n" + 
			"gold general:G:WfF:g:e1,i1\n" + 
			"lance:L:fRbW2:l:a1,m1\n" + 
			"kirin:KY:FD:ky:c2\n" + 
			"phoenix:PH:WA:ph:j2\n" + 
			"vertical mover:VM:WvR:vm:a2,m2\n" + 
			"bishop:B:B:b:c3,k3\n" + 
			"side soldier:SS:WsRfW2:ss:a3,m3\n" + 
			"rook:R:R:r:b3,l3\n" + 
			"dragon horse:DH:BW:dh:d3,j3\n" + 
			"dragon king:DK:RF:dk:e3,i3\n" + 
			"chariot soldier:CS:BvRsW2:cs:d2\n" + 
			"lion:LN:KNADcaKmcabK:ln:f2\n" + 
			"queen:Q:Q:q:h2\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:f3\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:g3\n" + 
			"water buffalo:WB:BsRvW2:wb:k2\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:h3\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:g2\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"king:K:K:k:g1";
	
	private static String omega_chess = "author=Daniel MacDonald\n" + 
			"files=12\n" + 
			"ranks=12\n" + 
			"promoZone=2\n" + 
			"promoChoice=QRSNBW\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#CF8948\n" + 
			"darkShade=#FFCC9C\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"hole:b1-k1,b12-k12,a2-a11,l2-l11\n" + 
			"pawn:P:ifmnDifmnHfmWfceF:pawn:b3-k3\n" + 
			"knight:N:N:knight:d2,i2\n" + 
			"bishop:B:B:bishop:e2,h2\n" + 
			"rook:R:R:rook:c2,j2\n" + 
			"queen:Q:Q:queen:f2\n" + 
			"wizard:W:FC:wizard:a1,l1\n" + 
			"champion:S:WAD:champion:b2,k2\n" + 
			"king:K:KisO2:king:g2";
	
	private static String ryugi = "files=10\n" + 
			"ranks=10\n" + 
			"promoChoice=QDMRBNI\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=rotate\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a2-d2,e3-f3,g2-j2\n" + 
			"knight:N:N:knight:e2,f2\n" + 
			"kirin:I:FD:kirin:b1,i1\n" + 
			"bishop:B:B:bishop:c1,h1\n" + 
			"rook:R:R:rook:a1,j1\n" + 
			"marshall:M:RN:marshall:d1\n" + 
			"dragon:D:BN0:dragon:g1\n" + 
			"queen:Q:Q:queen:e1\n" + 
			"king:K:KisO3isO2:king:f1";
	
	private static String shogi = "files=9\n" + 
			"ranks=9\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=6\n" + 
			"promoZone=3\n" + 
			"promoOffset=7\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=4,1\n" + 
			"forceShogiPromotionZone=5,2\n" + 
			"graphicsDir=/shogi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=54\n" + 
			"pawn:P:fW:p:a3-i3\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:h2\n" + 
			"lance:L:fR:l:a1,i1\n" + 
			"knight:N:ffN:n:b1,h1\n" + 
			"silver general:S:FfW:s:c1,g1\n" + 
			"gold general:G:WfF:g:d1,f1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"promoted lance:+L:WfF:l2:\n" + 
			"promoted knight:+N:WfF:n2:\n" + 
			"promoted silver:+S:WfF:s2:\n" + 
			"king:K:K:k:e1";
	
	private static String shosu_shogi = "files=10\n" + 
			"ranks=10\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=7\n" + 
			"promoZone=3\n" + 
			"promoOffset=8\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=4,1\n" + 
			"forceShogiPromotionZone=5,2\n" + 
			"graphicsDir=/futashikana_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=45\n" + 
			"pawn:P:fW:p:a3-j3\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:i2\n" + 
			"lance:L:fR:l:a1,j1\n" + 
			"knight:N:ffN:n:b1,i1\n" + 
			"silver general:S:FfW:s:c1,h1\n" + 
			"gold general:G:WfF:g:d1,g1\n" + 
			"queen:Q:Q:q:e1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"vertical mover:+L:WvR:l2:\n" + 
			"white horse:+N:N:n2:\n" + 
			"vice general:+S:WfF:s2:\n" + 
			"great general:+S:FsfW:g2:\n" + 
			"king:K:K:k:f1";
	
	private static String suzumu_shogi = "files=16\n" + 
			"ranks=16\n" + 
			"maxPromote=30\n" + 
			"promoZone=5\n" + 
			"promoOffset=35\n" + 
			"promoChoice=shogi\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=45\n" + 
			"royal=66\n" + 
			"symmetry=mirror\n" + 
			"squareSize=41\n" + 
			"pawn:P:fW:p:a5-p5\n" + 
			"dog:D:bFfW:d:e6,l6\n" + 
			"knight:N:N:n:b1,o1\n" + 
			"iron general:I:fFbW:i:d1,m1\n" + 
			"copper general:C:fFvW:c:e1,l1\n" + 
			"silver general:S:FfW:s:f1,k1\n" + 
			"blind tiger:BT:FsbW:bt:f2,k2\n" + 
			"ferocious leopard:FL:FvW:fl:c1,n1\n" + 
			"gold general:G:WfF:g:g1,j1\n" + 
			"drunk elephant:DE:FsfW:de:h1\n" + 
			"reverse chariot:RV:vR:rv:a2,p2\n" + 
			"lance:L:fRbW2:l:a1,p1\n" + 
			"kirin:KY:FD:ky:g2\n" + 
			"phoenix:PH:WA:ph:j2\n" + 
			"side mover:SM:WsR:sm:a4,p4\n" + 
			"vertical mover:VM:WvR:vm:b4,o4\n" + 
			"bishop:B:B:b:c3,n3\n" + 
			"side soldier:SS:WsRfW2:ss:a3,p3\n" + 
			"vertical soldier:VS:WfRsW2:vs:b3,o3\n" + 
			"rook:R:R:r:c4,n4\n" + 
			"dragon horse:DH:BW:dh:d3,m3\n" + 
			"dragon king:DK:RF:dk:e3,l3\n" + 
			"chariot soldier:CS:BvRsW2:cs:c2,d2,m2,n2\n" + 
			"horned falcon:HF:BbsRfWfDfcavWfmabW:hf:d4,m4\n" + 
			"soaring eagle:SE:RbBfFfAfcavFfmabF:se:e4,l4\n" + 
			"lion:LN:KNADcaKmcabK:ln:h2\n" + 
			"queen:Q:Q:q:i2\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:f4,k4\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:g4,j4\n" + 
			"water buffalo:WB:BsRvW2:wb:f3,k3\n" + 
			"free eagle:FE:QADcasFcafFmcabF:fe:i3\n" + 
			"lion hawk:LH:BWNADcaKmcabK:lh:h3\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:i4\n" + 
			"great general:GG:pafpafcQmcQcpQ:gg:h4\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:g3,j3\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"chariot soldier:+VS:BvRsW2:vs2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"bishop general:+HF:pafpafcBmcBcpB:hf2:\n" + 
			"rook general:+SE:pafpafcRmcRcpR:se2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"king:K:K:k:i1";
	
	private static String taishin_shogi = "files=25\n" + 
			"ranks=25\n" + 
			"maxPromote=79\n" + 
			"promoZone=0\n" + 
			"promoOffset=86\n" + 
			"promoChoice=capture\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=78\n" + 
			"royal=79\n" + 
			"royal=163\n" + 
			"royal=164\n" + 
			"royal=165\n" + 
			"contagiousPromotion=75\n" + 
			"contagiousPromotion=76\n" + 
			"contagious=161\n" + 
			"contagious=162\n" + 
			"symmetry=rotate\n" + 
			"squareSize=41\n" + 
			"pawn:P:fW:p:a7-y7\n" + 
			"dog:D:bFfW:d:h8,r8\n" + 
			"knight:N:N:n:d2,v2\n" + 
			"earth general:E:vW:e:d5,v5\n" + 
			"stone general:O:fF:o:e5,u5\n" + 
			"tile general:T:fFbW:t:f5,t5\n" + 
			"iron general:I:fFfW:i:g5,s5\n" + 
			"copper general:C:fFvW:c:h5,r5\n" + 
			"silver general:S:FfW:s:k2,o2\n" + 
			"blind tiger:BT:FsbW:bt:j3,p3\n" + 
			"ferocious leopard:FL:FvW:fl:c4,w4\n" + 
			"gold general:G:WfF:g:k1,o1\n" + 
			"cat sword:CT:F:ct:c3,w3\n" + 
			"angry boar:AB:W:ab:k6,o6\n" + 
			"evil wolf:EW:fFfsW:ew:l6,n6\n" + 
			"coiled serpent:CO:bFvW:co:i5,q5\n" + 
			"blind dog:BD:fFsbW:bd:f4,t4\n" + 
			"old monkey:OM:FbW:om:h4,r4\n" + 
			"reclining dragon:RN:WbF:rn:j6,p6\n" + 
			"flying horse:FH:F2:fh:d1,v1\n" + 
			"flying dragon:FN:W2:fn:d3,v3\n" + 
			"roaring dog:RD:K3:rd:f1,t1\n" + 
			"reverse chariot:RV:vR:rv:a2,y2\n" + 
			"lance:L:fRbW2:l:a1,y1\n" + 
			"whale:WL:bBvR:wl:c1,w1\n" + 
			"white horse:WH:fBvR:wh:b3,x3\n" + 
			"howling dog:HD:fRbW:hd:a6,y6\n" + 
			"kirin:KY:FD:ky:n4,l4\n" + 
			"phoenix:PH:WA:ph:i3,q3\n" + 
			"warrior:WR:WfFA:wr:j4,p4\n" + 
			"poisonous snake:PS:FvWD:ps:e2,u2\n" + 
			"left chariot:LC:fRbWflbrB:lc:a5\n" + 
			"right chariot:RC:fRbWfrblB:rc:y5\n" + 
			"soldier:SO:RbB:so:a3,y3\n" + 
			"side mover:SM:WsR:sm:f6,t6\n" + 
			"vertical mover:VM:WvR:vm:g6,s6\n" + 
			"bishop:B:B:b:g2,s2\n" + 
			"side soldier:SS:WsRfW2:ss:e3,u3\n" + 
			"vertical soldier:VS:WfRsW2:vs:f3,t3\n" + 
			"rook:R:R:r:g1,s1\n" + 
			"side chariot:SC:sRvW2:sc:b5,x5\n" + 
			"vertical chariot:VC:vRsW2:vc:c5,w5\n" + 
			"dragon horse:DH:BW:dh:h1,r1\n" + 
			"dragon king:DK:RF:dk:i1,q1\n" + 
			"fire dragon:F:RfB4bB2:f:i6,q6\n" + 
			"water dragon:W:RbB4fB2:w:h6,r6\n" + 
			"earth dragon:H:BsR4vR2:h:c6,w6\n" + 
			"wind dragon:A:BvR4sR2:a:b6,x6\n" + 
			"violent falcon:VF:BN:vf:k4,o4\n" + 
			"fierce eagle:VE:RN:ve:k3,o3\n" + 
			"chariot soldier:CS:BvRsW2:cs:a4,y4\n" + 
			"mountain falcon:MF:RfBbB2fD:mf:d6,v6\n" + 
			"left mountain eagle:LE:RlbfBrbB2lvA:le:e6\n" + 
			"right mountain eagle:RE:RrbfBlbB2rvA:re:u6\n" + 
			"horned falcon:HF:BbsRfWfDfcavWfmabW:hf:g4,s4\n" + 
			"soaring eagle:SE:RbBfFfAfcavFfmabF:se:c2,w2\n" + 
			"lion:LN:KNADcaKmcabK:ln:h3,r3\n" + 
			"lion dog:LD:KADGHcafKmcabKcafmpafKmpafcavK:ld:g3,s3\n" + 
			"queen:Q:Q:q:j1,p1\n" + 
			"free eagle:FE:QADcasFcafFmcabF:fe:m6\n" + 
			"lion hawk:LH:BWNADcaKmcabK:lh:m5\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:d4,v4\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:e4,u4\n" + 
			"violent horse:VH:R3pafpafcBmcBcpB:vh:h2,r2\n" + 
			"violent dragon:VD:B3pafpafcRmcRcpR:vd:i2,q2\n" + 
			"vice master:VA:DpafpafcBmcBcpB:va:b1,x1\n" + 
			"great master:GA:ApafpafcRmcRcpR:ga:b2,x2\n" + 
			"water buffalo:WB:BsRvW2:wb:b4,x4\n" + 
			"free demon:HK:BsRvW5:hk:j2,p2\n" + 
			"free dream eater:HB:BvRsW5:hb:f2,t2\n" + 
			"peacock:PC:bB2fBfmasB:pc:i4,q4\n" + 
			"capricorn:CA:BmasB:ca:e1,u1\n" + 
			"left general:LT:FvrW:lt:l2\n" + 
			"right general:RT:FvlW:rt:n2\n" + 
			"deva:DV:lfbFW:dv:l1\n" + 
			"dark spirit:DS:rfbFW:ds:n1\n" + 
			"drunk elephant:DE:FsfW:de:m3\n" + 
			"crown prince:CP:K:cp:m2\n" + 
			"king:K:K:k:m1\n" + 
			"furious fiend:FF:KNADGHcaKmcabKcafmpafKmpafcavK:ff:m4\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:n3\n" + 
			"great general:GG:pafpafcQmcQcpQ:gg:l3\n" + 
			"heavenly tetrarch:HT:jsR3jBjvRcabK:ht:j5,p5\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:k5,o5\n" + 
			"tengu:TG:WBmasB:tg:l5\n" + 
			"hook mover:HM:RmasR:hm:n5\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"reverse chariot:+E:vR:e2:\n" + 
			"side chariot:+O:sRvW2:o2:\n" + 
			"vertical chariot:+T:vRsW2:t2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"free cat:+CT:B:ct2:\n" + 
			"running boar:+AB:R:ab2:\n" + 
			"free wolf:+EW:KsR:ew2:\n" + 
			"free serpent:+CO:bBvR:co2:\n" + 
			"wizard stork:+BD:BsfRbW:bd2:\n" + 
			"mountain witch:+OM:BsbRfW:om2:\n" + 
			"free dragon:+RN:RbB:rn2:\n" + 
			"violent falcon:+FH:BN:fh2:\n" + 
			"fierce eagle:+FN:RN:fn2:\n" + 
			"lion dog:+RD:KADGHcafKmcabKcafmpafKmpafcavK:rd2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"great whale:+WL:bBvRsR2:wl2:\n" + 
			"great horse:+WH:fBvRsR2:wh2:\n" + 
			"roaring dog:+HD:K3:hd2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"tengu:+WR:WBmasB:wr2:\n" + 
			"hook mover:+PS:RmasR:ps2:\n" + 
			"left army:+LC:KrvBrR:lc2:\n" + 
			"right army:+RC:KlvBlR:rc2:\n" + 
			"cavalier:+SO:RfB:so2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"chariot soldier:+VS:BvRsW2:vs2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"free demon:+SC:BsRvW5:sc2:\n" + 
			"free dream eater:+VC:BvRsW5:vc2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"kirin master:+F:BbsRfWfDfHfcafWfmcabWfcafmpafWfmpafcavW:f2:\n" + 
			"phoenix master:+W:RbBfFfAfGfcafFfmcabFfcafmpafFfmpafcavF:w2:\n" + 
			"earthward net:+H:BWaKmabK:h2:\n" + 
			"skyward net:+A:RFaKmabK:a2:\n" + 
			"violent horse:+VF:R3pafpafcBmcBcpB:vf2:\n" + 
			"violent dragon:+VE:B3pafpafcRmcRcpR:ve2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"horned falcon:+MF:BbsRfWfDfcavWfmabW:mf2:\n" + 
			"soaring eagle:+LE:RbBfFfAfcavFfmabF:le2:\n" + 
			"soaring eagle:+RE:RbBfFfAfcavFfmabF:re2:\n" + 
			"bishop general:+HF:pafpafcBmcBcpB:hf2:\n" + 
			"rook general:+SE:pafpafcRmcRcpR:se2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"furious fiend:+LD:KNADGHcaKmcabKcafmpafKmpafcavK:ld2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"golden bird:+FE:QDcasWcafWmcabW:fe2:\n" + 
			"great dragon:+LH:RFNADcaKmcabK:lh2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"horse master:+VH:pafpafcBmcBcpBKaKmabK:vh2:\n" + 
			"dragon master:+VD:pafpafcRmcRcpRKaKmabK:vd2:\n" + 
			"vice general:+VA:pafpafcBmcBcpBKaKaaKmabK:va2:\n" + 
			"great general:+GA:pafpafcQmcQcpQ:ga2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"great demon:+HK:BsRKaKaaKmabK:hk2:\n" + 
			"great dream eater:+HB:BvRKaKaaKmabK:hb2:\n" + 
			"tengu:+PC:WBmasB:pc2:\n" + 
			"hook mover:+CA:RmasR:ca2:\n" + 
			"shogun:+LT:KaKaaKmabK:lt2:\n" + 
			"shogun:+RT:KaKaaKmabK:rt2:\n" + 
			"teaching king:+DV:QADGHcafKmcabKcafmpafKmpafcavK:dv2:\n" + 
			"divine dragon:+DS:QNADcaKmcabK:ds2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"king:+CP:K:cp2:\n" + 
			"emperor:+K:U:k2:";
	
	private static String xiangqi = "files=9\n" + 
			"ranks=10\n" + 
			"promoZone=5\n" + 
			"promoOffset=1\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/xiangqi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"shades=111000111/111000111/111000111/111111111/111111111/000000000/000000000/000111000/000111000/000111000\n" + 
			"symmetry=mirror\n" + 
			"squareSize=54\n" + 
			"soldier:S:fW:soldier:a4,c4,e4,g4,i4\n" + 
			"soldier:Q:fsW:soldier:\n" + 
			"cannon:C:mRcpR:cannon:b3,h3\n" + 
			"chariot:R:R:chariot:a1,i1\n" + 
			"horse:H:mafsW:horse:b1,h1\n" + 
			"elephant:E:mafF:elephant:c1,g1\n" + 
			"advisor:A:F:advisor:d1,f1\n" + 
			"general:G:WfkR:general:e1";
	
	private static String yangsi = "files=10\n" + 
			"ranks=10\n" + 
			"promoChoice=QMARSCNBVW\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a3-j3\n" + 
			"knight:N:N:knight:c2,h2\n" + 
			"bishop:B:B:bishop:d2,g2\n" + 
			"rook:R:R:rook:a2,j2\n" + 
			"queen:Q:Q:queen:e2\n" + 
			"wizard:W:FC:wizard:b1,i1\n" + 
			"champion:S:WAD:champion:b2,i2\n" + 
			"marshall:M:RN:marshall:a1,j1\n" + 
			"archbishop:A:BN:archbishop:d1,g1\n" + 
			"cannon:C:mRcpR:cannon:c1,h1\n" + 
			"vao:V:mBcpB:vao:e1,f1\n" + 
			"king:K:KisO3isO2:king:f2";
	
	public static String getPresetText(String name)
	{
		if(name.equals("cannon_shosu_shogi"))
		{
			return cannon_shosu_shogi;
		}
		else if(name.equals("chess"))
		{
			return chess;
		}
		else if(name.equals("chushin_shogi"))
		{
			return chushin_shogi;
		}
		else if(name.equals("futashikana_shogi"))
		{
			return futashikana_shogi;
		}
		else if(name.equals("grand_chess"))
		{
			return grand_chess;
		}
		else if(name.equals("gross_chess"))
		{
			return gross_chess;
		}
		else if(name.equals("hectochess"))
		{
			return hectochess;
		}
		else if(name.equals("hook_shogi"))
		{
			return hook_shogi;
		}
		else if(name.equals("manchu_chess"))
		{
			return manchu_chess;
		}
		else if(name.equals("microshogi"))
		{
			return microshogi;
		}
		else if(name.equals("minishogi"))
		{
			return minishogi;
		}
		else if(name.equals("mitsugumi_shogi"))
		{
			return mitsugumi_shogi;
		}
		else if(name.equals("omega_chess"))
		{
			return omega_chess;
		}
		else if(name.equals("ryugi"))
		{
			return ryugi;
		}
		else if(name.equals("shogi"))
		{
			return shogi;
		}
		else if(name.equals("shosu_shogi"))
		{
			return shosu_shogi;
		}
		else if(name.equals("suzumu_shogi"))
		{
			return suzumu_shogi;
		}
		else if(name.equals("taishin_shogi"))
		{
			return taishin_shogi;
		}
		else if(name.equals("xiangqi"))
		{
			return xiangqi;
		}
		else if(name.equals("yangsi"))
		{
			return yangsi;
		}
		else
		{
			return "";
		}
	}
}
