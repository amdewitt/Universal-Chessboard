package piece;

import javafx.scene.image.*;
import java.net.*;

/**
 * The Piece class defines individual pieces and stores their properties. It
 * also</br>
 * doubles as the ImageView Object that the piece image is viewed through.
 * 
 * @author Adam
 *
 */
public class Piece {
	private StringBuffer name = new StringBuffer(""); // piece name
	private StringBuffer id = new StringBuffer(""); // piece ID
	private StringBuffer betza = new StringBuffer(""); // piece moves in XBetza notation
	private StringBuffer imageDir; // piece image directory
	private StringBuffer imagePrefix; // piece image prefix
	private StringBuffer imageName; // piece image name
	private Image image;

	// Piece properties

	/*
	 * Determines royalty. 0 - non-royal (normal piece) 1 - royal (must be captured
	 * to win) 2 - iron (cannot be captured at all)
	 */
	private int royal = 0;

	/*
	 * Whether capturing this piece forces the capturer to promote to a friendly
	 * version of this piece
	 */
	boolean contagious = false;
	
	/*
	 * Whether capturing this piece forces the capturer to promote to a friendly
	 * version of this piece and promote (Shogi-style)
	 */
	boolean contagiousPromotion = false;

	// Create Piece

	/**
	 * Constructor Creates a new piece.
	 * 
	 * @param pieceName  the piece's name
	 * @param pieceID    the piece's ID (usually a series of letters)
	 * @param pieceBetza the piece's move in XBetza notation.
	 * @param imageName  the file path of the piece image.
	 */
	public Piece(String pieceName, String pieceID, String pieceBetza, String imageDir, String imagePrefix, String imageName) {
		name = new StringBuffer(pieceName); // set required variables
		id = new StringBuffer(pieceID);
		betza = new StringBuffer(pieceBetza);
		this.imageDir = new StringBuffer(imageDir);
		this.imagePrefix = new StringBuffer(imagePrefix);
		this.imageName = new StringBuffer(imageName);
		MakeImage();
	}

	private void MakeImage() {
		String imagePath = imageDir.toString() + imagePrefix.toString() + imageName.toString();
		try {
			URL imageURL = new URL(imagePath.toString());
			image = MakeImageFromURL(imageURL);
		} catch (MalformedURLException mue) {
			try {
				image = new Image(this.getClass().getResourceAsStream(imagePath.toString()));
			} catch (Exception e) {
				image = new Image("/null/null.png");
			}
		}
	}

	public Image MakeImageFromURL(URL url)
	{
		try
		{
			URLConnection connection = url.openConnection();
			connection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
			Image image = new Image(connection.getInputStream());
			return image;
		}
		catch(Exception e)
		{
			return new Image("/null/null.png");
		}
	}

	// Control and Information methods for piece properties

	/**
	 * Set piece name
	 * 
	 * @param pieceName the piece's new name
	 */
	public void setPieceName(String pieceName) {
		name = new StringBuffer(pieceName);
	}

	/**
	 * Get piece name
	 * 
	 * @return the piece's name
	 */
	public String getPieceName() {
		return name.toString();
	}

	/**
	 * Set piece ID
	 * 
	 * @param pieceID the piece's new ID
	 */
	public void setPieceID(String pieceID) {
		id = new StringBuffer(pieceID);
	}

	/**
	 * Get piece ID
	 * 
	 * @return the piece's ID
	 */
	public String getPieceID() {
		return id.toString();
	}

	/**
	 * Set piece moves using XBetza Notation
	 * 
	 * @param pieceName the piece's new moves in XBetza Notation
	 */
	public void setPieceBetza(String pieceBetza) {
		betza = new StringBuffer(pieceBetza);
	}

	/**
	 * Get piece moves in XBetza notation
	 * 
	 * @return the piece's moves in XBetza Notation
	 */
	public String getPieceBetza() {
		return betza.toString();
	}
	
	/**
	 * Set piece image path
	 * @param imagePath the new image path
	 */
	public void setPieceImagePath(String imageDir, String imagePrefix, String imageName) {
		this.imageDir = new StringBuffer(imageDir);
		this.imagePrefix = new StringBuffer(imagePrefix);
		this.imageName = new StringBuffer(imageName);
		MakeImage();
	}

	/**
	 * Get piece image path
	 * @return the piece's image path
	 */
	public String getPieceImagePath() {
		String imagePath = imageDir.toString() + imagePrefix.toString() + imageName.toString();
		return imagePath;
	}

	public Image getPieceImage() {
		return image;
	}

	/**
	 * Sets the piece's royalty 0 - non-royal (normal piece) 1 - royal (must be
	 * captured to win) 2 - iron (cannot be captured at all) Defaults to 0 if value
	 * is invalid
	 * 
	 * @param royalty the piece's royalty value
	 */
	public void setRoyalty(int royalty) {
		if (royalty < 0 || royalty > 2) {
			royal = 0;
		} else {
			royal = royalty;
		}
	}

	/**
	 * Get piece's royalty
	 * 
	 * @return the piece's royalty
	 */
	public int getRoyalty() {
		return royal;
	}
	
	/**
	 * Set whether this piece is contagious and promotes the capturer after it transforms.</br>
	 * Sets the value of this property to false if the piece is contagious and should not</br>
	 * promote after transforming.
	 * 
	 * @param contagiousPromotion whether this piece is contagious and promotes the capturer after it transforms
	 */
	public void setContagiousPromotion(boolean contagiousPromotion) {
		if(contagious == true)
		{
			this.contagiousPromotion = false;
		}
		else
		{
			this.contagiousPromotion = contagiousPromotion;
		}
	}

	/**
	 * Get whether this piece is contagious and promotes the capturer after it transforms.
	 * 
	 * @return whether this piece is contagious and promotes the capturer after it transforms
	 */
	public boolean getContagiousPromotion() {
		return contagiousPromotion;
	}
	
	/**
	 * Set whether this piece is contagious.</br>
	 * If this property is true, the contagious</br>
	 * promotion property is set to false.
	 * 
	 * @param contagious whether this piece is contagious
	 */
	public void setContagious(boolean contagious) {
		this.contagious = contagious;
		if(this.contagious == true)
		{
			contagiousPromotion = false;
		}
	}

	/**
	 * Get whether this piece is contagious.
	 * 
	 * @return whether this piece is contagious
	 */
	public boolean getContagious() {
		return contagious;
	}
}
