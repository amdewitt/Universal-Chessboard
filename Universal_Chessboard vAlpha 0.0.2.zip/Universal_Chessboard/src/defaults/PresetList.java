package defaults;

/**
 * The PresetList class stores all of the default presets used in the Universal Chessboard so they can be</br>
 * fetched regardless of whether the program is run in Eclipse or from a .jar file.
 */
public class PresetList {
	private static String cannon_shosu_shogi = "name=Cannon Shosu Shogi\n" + 
			"author=Adam DeWitt\n" + 
			"files=10\n" + 
			"ranks=10\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=10\n" + 
			"promoZone=3\n" + 
			"promoOffset=11\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=7,1\n" + 
			"forceShogiPromotionZone=8,2\n" + 
			"graphicsDir=/futashikana_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=45\n" + 
			"pawn:P:fW:p:a3-j3\n" + 
			"dog:D:bFfW:d:c4,h4\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:i2\n" + 
			"silver cannon:I:mBcpB:i:d2,g2\n" + 
			"gold cannon:C:mRcpR:c:c2,h2\n" + 
			"lance:L:fR:l:a1,j1\n" + 
			"knight:N:ffN:n:b1,i1\n" + 
			"silver general:S:FfW:s:c1,h1\n" + 
			"gold general:G:WfF:g:d1,g1\n" + 
			"queen:Q:Q:q:e1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"side mover:+D:WsR:d2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"bishop general:+I:BWDcpB:i2:\n" + 
			"rook general:+C:RFAcpR:c2:\n" + 
			"vertical mover:+L:WvR:l2:\n" + 
			"white horse:+N:N:n2:\n" + 
			"vice general:+S:WfF:s2:\n" + 
			"great general:+G:FfsW:g2:\n" + 
			"king:K:K:k:f1";
	
	private static String chess = "default";
	
	private static String chushin_shogi = "name=Chushin Shogi\n" + 
			"author=Adam DeWitt\n" + 
			"files=18\n" + 
			"ranks=18\n" + 
			"maxPromote=44\n" + 
			"promoZone=6\n" + 
			"promoOffset=50\n" + 
			"promoChoice=shogi\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=62\n" + 
			"royal=95\n" + 
			"symmetry=rotate\n" + 
			"squareSize=39\n" + 
			"pawn:P:fW:p:a6-r6\n" + 
			"dog:D:bFfW:d:f7,m7\n" + 
			"knight:N:N:n:b1,q1\n" + 
			"iron general:I:fFbW:i:d1,o1\n" + 
			"copper general:C:fFvW:c:e1,n1\n" + 
			"silver general:S:FfW:s:f1,m1\n" + 
			"blind tiger:BT:FsbW:bt:g2,l2\n" + 
			"ferocious leopard:FL:FvW:fl:c1,p1\n" + 
			"gold general:G:WfF:g:g1,l1\n" + 
			"left general:LT:FvrW:lt:h1\n" + 
			"right general:RT:FvlW:rt:k1\n" + 
			"drunk elephant:DE:FsfW:de:i1\n" + 
			"flying horse:FH:F2:fh:e3,n3\n" + 
			"flying dragon:FN:W2:fn:f3,m3\n" + 
			"roaring dog:RD:K3:rd:d2,o2\n" + 
			"reverse chariot:RV:vR:rv:a2,r2\n" + 
			"lance:L:fRbW2:l:a1,r1\n" + 
			"kirin:KY:FD:ky:h3\n" + 
			"phoenix:PH:WA:ph:k3\n" + 
			"side mover:SM:WsR:sm:a5,r5\n" + 
			"vertical mover:VM:WvR:vm:b5,q5\n" + 
			"bishop:B:B:b:c4,p4\n" + 
			"side soldier:SS:WsRfW2:ss:a4,r4\n" + 
			"vertical soldier:VS:WfRsW2:vs:b4,q4\n" + 
			"rook:R:R:r:c5,p5\n" + 
			"side chariot:SC:sRvW2:sc:a3,r3\n" + 
			"vertical chariot:VC:vRsW2:vc:b3,q3\n" + 
			"dragon horse:DH:BW:dh:e4,n4\n" + 
			"dragon king:DK:RF:dk:f4,m4\n" + 
			"violent falcon:VF:BN:vf:d4,o4\n" + 
			"fierce eagle:VE:RN:ve:d5,o5\n" + 
			"chariot soldier:CS:BvRsW2:cs:c2,e2,n2,p2\n" + 
			"horned falcon:HF:BbsRfWfDfcavWfmabW:hf:e5,n5\n" + 
			"soaring eagle:SE:RbBfFfAfcavFfmabF:se:f5,m5\n" + 
			"lion:LN:KNADcaKmcabK:ln:i3\n" + 
			"lion dog:LD:KADGHcafKmcabKcafmpafKmpafcavK:ld:k2\n" + 
			"queen:Q:Q:q:j3\n" + 
			"free eagle:FE:QADcasFcafFmcabF:fe:j4\n" + 
			"lion hawk:LH:BWNADcaKmcabK:lh:i4\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:g5,l5\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:h5,k5\n" + 
			"violent horse:VH:R3pafpafcBmcBcpB:vh:i5,j5\n" + 
			"violent dragon:VD:B3pafpafcRmcRcpR:vd:g3,l3\n" + 
			"water buffalo:WB:BsRvW2:wb:g4,l4\n" + 
			"free demon:HK:BsRvW5:hk:d3,o3\n" + 
			"free dream eater:HB:BvRsW5:hb:c3,p3\n" + 
			"furious fiend:FF:KNADGHcaKmcabKcafmpafKmpafcavK:ff:h2\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:j2\n" + 
			"great general:GG:pafpafcQmcQcpQ:gg:i2\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:h4,k4\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"shogun:+LT:KaKaaKmabK:lt2:\n" + 
			"shogun:+RT:KaKaaKmabK:rt2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"violent falcon:+FH:BN:fh2:\n" + 
			"fierce eagle:+FN:RN:fn2:\n" + 
			"lion dog:+RD:KADGHcafKmcabKcafmpafKmpafcavK:rd2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"chariot soldier:+VS:BvRsW2:vs2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"free demon:+SC:BsRvW5:sc2:\n" + 
			"free dream eater:+VC:BvRsW5:vc2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"violent horse:+VF:R3pafpafcBmcBcpB:vf2:\n" + 
			"violent dragon:+VE:B3pafpafcRmcRcpR:ve2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"bishop general:+HF:pafpafcBmcBcpB:hf2:\n" + 
			"rook general:+SE:pafpafcRmcRcpR:se2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"furious fiend:+LD:KNADGHcaKmcabKcafmpafKmpafcavK:ld2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"golden bird:+FE:QDcasWcafWmcabW:fe2:\n" + 
			"great dragon:+LH:RFNADcaKmcabK:lh2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"horse master:+VH:pafpafcBmcBcpBKaKmabK:vh2:\n" + 
			"dragon master:+VD:pafpafcRmcRcpRKaKmabK:vd2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"king:K:K:k:j1";
	
	private static String futashikana_shogi = "name=Futashikana Shogi\n" + 
			"author=Adam DeWitt\n" + 
			"files=11\n" + 
			"ranks=11\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=11\n" + 
			"promoZone=3\n" + 
			"promoOffset=12\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=8,1\n" + 
			"forceShogiPromotionZone=9,2\n" + 
			"graphicsDir=/futashikana_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=45\n" + 
			"pawn:P:fW:p:a3-c3,d4,e3-g3,h4,i3-k3\n" + 
			"kirin:O:FD:o:b1\n" + 
			"phoenix:X:WA:x:j1\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:j2\n" + 
			"side soldier:M:sRfR2:m:d3\n" + 
			"vertical soldier:V:fRsR2:v:h3\n" + 
			"lance:L:fR:l:a1,k1\n" + 
			"knight:N:ffN:n:c1,i1\n" + 
			"silver general:S:FfW:s:d1,h1\n" + 
			"gold general:G:WfF:g:e1,g1\n" + 
			"queen:Q:Q:q:f2\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"horned falcon:+O:BN:o2:\n" + 
			"soaring eagle:+X:RN:x2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"water buffalo:+M:BsRvW2:m2:\n" + 
			"chariot soldier:+V:BvRsW2:v2:\n" + 
			"vertical mover:+L:WvR:l2:\n" + 
			"white horse:+N:N:n2:\n" + 
			"vice general:+S:WfF:s2:\n" + 
			"great general:+G:FfsW:g2:\n" + 
			"king:K:K:k:f1";
	
	private static String grand_chess = "name=Grand Chess\n" + 
			"author=Christian Freeling\n" + 
			"files=10\n" + 
			"ranks=10\n" + 
			"holdingsType=1\n" + 
			"promoZone=3\n" + 
			"promoChoice=*Q*M*A*R*B*N!P\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDifmnHfmWfceF:pawn:a3-j3\n" + 
			"knight:N:N:knight:b2,i2\n" + 
			"bishop:B:B:bishop:c2,h2\n" + 
			"rook:R:R:rook:a1,j1\n" + 
			"queen:Q:Q:queen:d2\n" + 
			"marshall:M:RN:marshall:f2\n" + 
			"archbishop:A:BN:archbishop:g2\n" + 
			"king:K:K:king:e2";
	
	private static String gross_chess = "name=Gross Chess\n" + 
			"author=Fergus Duniho\n" + 
			"files=12\n" + 
			"ranks=12\n" + 
			"holdingsType=1\n" + 
			"promoZone=3\n" + 
			"promoChoice=!P*N*B*R2*S2*W*C2*V*A1*M1*Q1\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a3-l3\n" + 
			"knight:N:N:knight:d2,i2:4\n" + 
			"bishop:B:B:bishop:e2,h2:4\n" + 
			"rook:R:R:rook:b2,k2:4\n" + 
			"queen:Q:Q:queen:f2:2\n" + 
			"wizard:W:FC:wizard:d1,i1\n" + 
			"champion:S:WAD:champion:c2,j2\n" + 
			"marshall:M:RN:marshall:a1,l1\n" + 
			"archbishop:A:BN:archbishop:b1,k1\n" + 
			"cannon:C:mRcpR:cannon:e1,h1\n" + 
			"vao:V:mBcpB:vao:c1,j1\n" + 
			"king:K:KilO4isO3isO2:king:g2";
	
	private static String hectochess = "name=Hectochess\n" + 
			"author=Adam DeWitt\n" + 
			"files=10\n" + 
			"ranks=10\n" + 
			"promoChoice=QMARSONBW\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a3-j3\n" + 
			"knight:N:N:knight:c2,h2\n" + 
			"bishop:B:B:bishop:d2,g2\n" + 
			"rook:R:R:rook:a2,j2\n" + 
			"queen:Q:Q:queen:e2\n" + 
			"wizard:W:FC:wizard:b1,i1\n" + 
			"champion:S:WAD:champion:b2,i2\n" + 
			"marshall:M:RN:marshall:a1\n" + 
			"archbishop:A:BN:archbishop:j1\n" + 
			"leo:O:mQcpQ:leo:c1,h1\n" + 
			"king:K:KisO3isO2:king:f2";
	
	private static String hook_shogi = "name=Hook Shogi\n" + 
			"author=Adam DeWitt\n" + "files=19\n" + 
			"ranks=19\n" + 
			"maxPromote=49\n" + 
			"promoZone=0\n" + 
			"promoOffset=51\n" + 
			"promoChoice=capture\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=49\n" + 
			"royal=99\n" + 
			"royal=100\n" + 
			"contagiousPromotion=46\n" + 
			"contagiousPromotion=47\n" + 
			"contagious=97\n" + 
			"contagious=98\n" + 
			"symmetry=rotate\n" + 
			"squareSize=39\n" + 
			"pawn:P:fW:p:a6-s6\n" + 
			"dog:D:bFfW:d:f7,n7\n" + 
			"knight:N:N:n:c4,q4\n" + 
			"earth general:E:vW:e:b1,r1\n" + 
			"stone general:O:fF:o:c1,q1\n" + 
			"tile general:T:fFbW:t:d1,p1\n" + 
			"iron general:I:fFfW:i:e1,o1\n" + 
			"copper general:C:fFvW:c:f1,n1\n" + 
			"silver general:S:FfW:s:g1,m1\n" + 
			"blind tiger:BT:FsbW:bt:i2,k2\n" + 
			"ferocious leopard:FL:FvW:fl:h2,l2\n" + 
			"gold general:G:WfF:g:h1,l1\n" + 
			"cat sword:CT:F:ct:c2,q2\n" + 
			"angry boar:AB:W:ab:d3,p3\n" + 
			"evil wolf:EW:fFfsW:ew:h3,l3\n" + 
			"coiled serpent:CO:bFvW:co:g2\n" + 
			"blind dog:BD:fFsbW:bd:e2\n" + 
			"old monkey:OM:FbW:om:o2\n" + 
			"reclining dragon:RN:WbF:rn:m2\n" + 
			"flying horse:FH:F2:fh:g4,m4\n" + 
			"flying dragon:FN:W2:fn:e4,o4\n" + 
			"roaring dog:RD:K3:rd:a4,s4\n" + 
			"reverse chariot:RV:vR:rv:a2,s2\n" + 
			"lance:L:fRbW2:l:a1,s1\n" + 
			"kirin:KY:FD:ky:h4,l4\n" + 
			"phoenix:PH:WA:ph:i3,k3\n" + 
			"warrior:WR:WfFA:wr:i4\n" + 
			"poisonous snake:PS:FvWD:ps:k4\n" + 
			"left chariot:LC:fRbWflbrB:lc:b5\n" + 
			"right chariot:RC:fRbWfrblB:rc:r5\n" + 
			"side mover:SM:WsR:sm:c5,q5\n" + 
			"vertical mover:VM:WvR:vm:e5,o5\n" + 
			"bishop:B:B:b:f5,n5\n" + 
			"rook:R:R:r:a5,s5\n" + 
			"side chariot:SC:sRvW2:sc:d5,p5\n" + 
			"vertical chariot:VC:vRsW2:vc:f3,n3\n" + 
			"dragon horse:DH:BW:dh:g5,m5\n" + 
			"dragon king:DK:RF:dk:h5,l5\n" + 
			"fire dragon:F:RfB4bB2:f:b3,r3\n" + 
			"water dragon:W:RbB4fB2:w:a3,s3\n" + 
			"earth dragon:H:BsR4vR2:h:b2,r2\n" + 
			"wind dragon:A:BvR4sR2:a:b4,r4\n" + 
			"lion:LN:KNADcaKmcabK:ln:j3\n" + 
			"lion dog:LD:KADGHcafKmcabKcafmpafKmpafcavK:ld:j4\n" + 
			"queen:Q:Q:q:j5\n" + 
			"deva:DV:lfbFW:dv:i1\n" + 
			"dark spirit:DS:rfbFW:ds:k1\n" + 
			"drunk elephant:DE:FsfW:de:j2\n" + 
			"king:K:K:k:j1\n" + 
			"tengu:TG:WBmasB:tg:i5\n" + 
			"hook mover:HM:RmasR:hm:k5\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"reverse chariot:+E:vR:e2:\n" + 
			"side chariot:+O:sRvW2:o2:\n" + 
			"vertical chariot:+T:vRsW2:t2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"free cat:+CT:B:ct2:\n" + 
			"running boar:+AB:R:ab2:\n" + 
			"free wolf:+EW:KsR:ew2:\n" + 
			"free serpent:+CO:bBvR:co2:\n" + 
			"wizard stork:+BD:BsfRbW:bd2:\n" + 
			"mountain witch:+OM:BsbRfW:om2:\n" + 
			"free dragon:+RN:RbB:rn2:\n" + 
			"violent falcon:+FH:BN:fh2:\n" + 
			"fierce eagle:+FN:RN:fn2:\n" + 
			"lion dog:+RD:KADGHcafKmcabKcafmpafKmpafcavK:rd2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"tengu:+WR:WBmasB:wr2:\n" + 
			"hook mover:+PS:RmasR:ps2:\n" + 
			"left army:+LC:KrvBrR:lc2:\n" + 
			"right army:+RC:KlvBlR:rc2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"free demon:+SC:BsRvW5:sc2:\n" + 
			"free dream eater:+VC:BvRsW5:vc2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"kirin master:+F:BbsRfWfDfHfcafWfmcabWfcafmpafWfmpafcavW:f2:\n" + 
			"phoenix master:+W:RbBfFfAfGfcafFfmcabFfcafmpafFfmpafcavF:w2:\n" + 
			"earthward net:+H:BWaKmabK:h2:\n" + 
			"skyward net:+A:RFaKmabK:a2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"furious fiend:+LD:KNADGHcaKmcabKcafmpafKmpafcavK:ld2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"teaching king:+DV:QADGHcafKmcabKcafmpafKmpafcavK:dv2:\n" + 
			"divine dragon:+DS:QNADcaKmcabK:ds2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"emperor:+K:U:k2:";
	
	private static String manchu_chess = "name=Manchu Chess\n" + 
			"files=9\n" + 
			"ranks=10\n" + 
			"promoZone=5\n" + 
			"promoOffset=1\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/xiangqi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"shades=111000111/111000111/111000111/111111111/111111111/000000000/000000000/000111000/000111000/000111000\n" + 
			"symmetry=none\n" + 
			"squareSize=54\n" + 
			"soldier:S:fW:soldier:a4,c4,e4,g4,i4,,a7,c7,e7,g7,i7\n" + 
			"soldier:Q:fsW:soldier:\n" + 
			"cannon:C:mRcpR:cannon:,,b8,h8\n" + 
			"chariot:R:R:chariot:,,a10,i10\n" + 
			"manchu chariot:M:RcpRmafsW:chariot:a1\n" + 
			"horse:H:mafsW:horse:,,b10,h10\n" + 
			"elephant:E:mafF:elephant:c1,g1,,c10,g10\n" + 
			"advisor:A:F:advisor:d1,f1,,d10,f10\n" + 
			"general:G:WfkR:general:e1,,e10";
	
	private static String microshogi = "name=Microshogi\n" + 
			"author=Oyama Yasuharu (attributed)\n" + 
			"files=4\n" + 
			"ranks=5\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"allowDropPromotions=true\n" + 
			"maxPromote=4\n" + 
			"promoZone=0\n" + 
			"promoOffset=4\n" + 
			"promoChoice=microshogi\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/shogi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=54\n" + 
			"pawn:P:fW:p:d2\n" + 
			"bishop:B:B:b:c1\n" + 
			"silver general:S:FfW:s:a1\n" + 
			"gold general:G:WfF:g:b1\n" + 
			"knight:+P:ffN:n:\n" + 
			"tokin:+B:BW:p2:\n" + 
			"lance:+S:fR:l:\n" + 
			"rook:+G:R:r:\n" + 
			"king:K:K:k:d1";
	
	private static String minishogi = "name=Minishogi\n" + 
			"author=Shigenobu Kusumoto\n" + 
			"files=5\n" + 
			"ranks=5\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=4\n" + 
			"promoOffset=5\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"graphicsDir=/shogi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=54\n" + 
			"pawn:P:fW:p:a2\n" + 
			"bishop:B:B:b:d1\n" + 
			"rook:R:R:r:e1\n" + 
			"silver general:S:FfW:s:c1\n" + 
			"gold general:G:WfF:g:b1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"promoted silver:+S:WfF:s2:\n" + 
			"king:K:K:k:a1";
	
	private static String maka_dai_dai_shogi = "name=Maka Dai Dai Shogi\n" + 
			"files=19\n" + 
			"ranks=19\n" + 
			"maxPromote=47\n" + 
			"promoZone=0\n" + 
			"promoOffset=50\n" + 
			"promoChoice=capture\n" + 
			"forcePromotions=1\n" + 
			"graphicsDir=/maka_dai_dai_shogi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=27\n" + 
			"royal=76\n" + 
			"royal=100\n" + 
			"contagiousPromotion=24\n" + 
			"contagiousPromotion=25\n" + 
			"contagious=74\n" + 
			"contagious=75\n" + 
			"symmetry=rotate\n" + 
			"squareSize=39\n" + 
			"pawn:P:fW:p:a6-s6\n" + 
			"go between:GB:vW:go:f7,n7\n" + 
			"earth general:E:vW:go:b1,r1\n" + 
			"stone general:ST:fF:st:c1,q1\n" + 
			"tile general:T:bWfF:t:d1,p1\n" + 
			"iron general:I:fWfF:i:e1,o1\n" + 
			"copper general:C:vWfF:c:f1,n1\n" + 
			"silver general:S:FfW:s:g1,m1\n" + 
			"gold general:G:WfF:g:h1,l1\n" + 
			"ferocious leopard:FL:vWF:fl:h2,l2\n" + 
			"evil wolf:EW:fsWfF:ew:h3,l3\n" + 
			"blind tiger:BT:FsbW:bt:i2,k2\n" + 
			"angry boar:AB:W:ab:d3,p3\n" + 
			"cat sword:CS:F:cs:c2,q2\n" + 
			"coiled serpent:Co:vWbF:co:g2\n" + 
			"reclining dragon:RD:WbF:rd:m2\n" + 
			"chinese cock:CC:bsWfF:cc:e2\n" + 
			"old monkey:OM:FbW:om:o2\n" + 
			"old rat:OR:fF2bW2:or:b3,r3\n" + 
			"blind bear:BB:FbR:bb:f3,n3\n" + 
			"phoenix:PH:WA:ph:k3\n" + 
			"kirin:KY:FD:ky:i3\n" + 
			"lion:LN:KNADcaKmcabK:ln:j3\n" + 
			"dark spirit:DS:lbfFrW:ds:k1\n" + 
			"deva:DV:rbfFlW:dv:i1\n" + 
			"drunk elephant:DE:FfsW:de:j2\n" + 
			"king:K:K:k:j1\n" + 
			"lance:L:fR:l:a1,s1\n" + 
			"reverse chariot:RV:vR:rv:a2,s2\n" + 
			"knight:N:ffN:n:c4,q4\n" + 
			"donkey:DY:WvD:dy:a4,s4\n" + 
			"violent ox:VO:W2:vo:e4,o4\n" + 
			"flying dragon:FD:F2:fd:g4,m4\n" + 
			"guardian of the gods:GG:W3fF:gg:k4\n" + 
			"wrestler:W:F3sW:w:i4\n" + 
			"buddhist devil:BD:fF3bsW:bd:h4\n" + 
			"she-devil:SD:F2W5:sd:l4\n" + 
			"left chariot:LC:fRbWflbrB:lc:b5\n" + 
			"right chariot:RC:fRbWfrblB:rc:r5\n" + 
			"side mover:SM:sRvW:sm:c5,q5\n" + 
			"side flyer:SF:sRF:sf:d5,p5\n" + 
			"vertical mover:VM:vRsW:vm:e5,o5\n" + 
			"bishop:B:B:b:f5,n5\n" + 
			"rook:R:R:r:a5,s5\n" + 
			"capricorn:CA:BmasB:ca:i5\n" + 
			"hook mover:HM:RmasR:hm:k5\n" + 
			"lion dog:LD:KADGHcavKcafmpafKmpafcavK:ld:j4\n" + 
			"dragon horse:DH:BW:dh:g5,m5\n" + 
			"dragon king:DK:RF:dk:h5,l5\n" + 
			"queen:Q:Q:q:j5\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"free goer:+GB:vR:go2:\n" + 
			"free earth:+E:vR:go2:\n" + 
			"free stone:+ST:fB:st2:\n" + 
			"free tile:+T:bRfB:t2:\n" + 
			"free iron:+I:fRfB:i2:\n" + 
			"free copper:+C:vRfB:c2:\n" + 
			"free silver:+S:BfR:s2:\n" + 
			"free gold:+G:RfB:g2:\n" + 
			"free leopard:+FL:vRB:fl2:\n" + 
			"free wolf:+EW:fsRfB:ew2:\n" + 
			"free tiger:+BT:BbsR:bt2:\n" + 
			"free boar:+AB:BsR:ab2:\n" + 
			"free cat:+CS:B:cs2:\n" + 
			"free serpent:+CO:bBvR:co2:\n" + 
			"free dragon:+RD:bBR:rd2:\n" + 
			"wizard stork:+CC:BbRfW:cc2:\n" + 
			"mountain witch:+OM:BfRbW:om2:\n" + 
			"bat:+OR:fRbB:or2:\n" + 
			"free bear:+BB:BsR:bb2:\n" + 
			"golden bird:+PH:vRsW2F3:ph2:\n" + 
			"great dragon:+KY:sRvW2F3:ky2:\n" + 
			"furious fiend:+LN:K3NADcaKcabKmabK:ln2:\n" + 
			"buddhist spirit:+DS:QNADcaKcabKmabK:ds2:\n" + 
			"teaching king:+DV:QADGHcavKcafmpafKmpafcavK:dv2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"emperor:+K:U:k2:";
	
	private static String mitsugumi_shogi = "name=Mitsugumi Shogi\n" + 
			"author=Adam DeWitt\n" + "files=13\n" + 
			"ranks=13\n" + 
			"maxPromote=22\n" + 
			"promoZone=4\n" + 
			"promoOffset=24\n" + 
			"promoChoice=shogi\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=39\n" + 
			"pawn:P:fW:p:a4-m4\n" + 
			"dog:D:bFfW:d:d5,j5\n" + 
			"knight:N:N:n:b1,l1\n" + 
			"silver general:S:FfW:s:d1,j1\n" + 
			"blind tiger:BT:FsbW:bt:f1,h1\n" + 
			"ferocious leopard:FL:FvW:fl:c1,k1\n" + 
			"gold general:G:WfF:g:e1,i1\n" + 
			"lance:L:fRbW2:l:a1,m1\n" + 
			"kirin:KY:FD:ky:c2\n" + 
			"phoenix:PH:WA:ph:j2\n" + 
			"vertical mover:VM:WvR:vm:a2,m2\n" + 
			"bishop:B:B:b:c3,k3\n" + 
			"side soldier:SS:WsRfW2:ss:a3,m3\n" + 
			"rook:R:R:r:b3,l3\n" + 
			"dragon horse:DH:BW:dh:d3,j3\n" + 
			"dragon king:DK:RF:dk:e3,i3\n" + 
			"chariot soldier:CS:BvRsW2:cs:d2\n" + 
			"lion:LN:KNADcaKmcabK:ln:f2\n" + 
			"queen:Q:Q:q:h2\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:f3\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:g3\n" + 
			"water buffalo:WB:BsRvW2:wb:k2\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:h3\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:g2\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"king:K:K:k:g1";
	
	private static String omega_chess = "name=Omega Chess\n" + 
			"author=Daniel MacDonald\n" + 
			"files=12\n" + 
			"ranks=12\n" + 
			"promoZone=2\n" + 
			"promoChoice=QRSNBW\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#CF8948\n" + 
			"darkShade=#FFCC9C\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"hole:b1-k1,b12-k12,a2-a11,l2-l11\n" + 
			"pawn:P:ifmnDifmnHfmWfceF:pawn:b3-k3\n" + 
			"knight:N:N:knight:d2,i2\n" + 
			"bishop:B:B:bishop:e2,h2\n" + 
			"rook:R:R:rook:c2,j2\n" + 
			"queen:Q:Q:queen:f2\n" + 
			"wizard:W:FC:wizard:a1,l1\n" + 
			"champion:S:WAD:champion:b2,k2\n" + 
			"king:K:KisO2:king:g2";
	
	private static String ryugi = "name=Ryugi\n" + 
			"author=Adam DeWitt\n" + "files=10\n" + 
			"ranks=10\n" + 
			"promoChoice=QDMRBNI\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=rotate\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a2-d2,e3-f3,g2-j2\n" + 
			"knight:N:N:knight:e2,f2\n" + 
			"kirin:I:FD:kirin:b1,i1\n" + 
			"bishop:B:B:bishop:c1,h1\n" + 
			"rook:R:R:rook:a1,j1\n" + 
			"marshall:M:RN:marshall:d1\n" + 
			"dragon:D:BN0:dragon:g1\n" + 
			"queen:Q:Q:queen:e1\n" + 
			"king:K:KisO3isO2:king:f1";
	
	private static String shogi = "name=Shogi\n" + 
			"files=9\n" + 
			"ranks=9\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=6\n" + 
			"promoZone=3\n" + 
			"promoOffset=7\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=4,1\n" + 
			"forceShogiPromotionZone=5,2\n" + 
			"graphicsDir=/shogi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=54\n" + 
			"pawn:P:fW:p:a3-i3\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:h2\n" + 
			"lance:L:fR:l:a1,i1\n" + 
			"knight:N:ffN:n:b1,h1\n" + 
			"silver general:S:FfW:s:c1,g1\n" + 
			"gold general:G:WfF:g:d1,f1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"promoted lance:+L:WfF:l2:\n" + 
			"promoted knight:+N:WfF:n2:\n" + 
			"promoted silver:+S:WfF:s2:\n" + 
			"king:K:K:k:e1";
	
	private static String shosu_shogi = "name=Shosu Shogi\n" + 
			"author=Adam DeWitt\n" + "files=10\n" + 
			"ranks=10\n" + 
			"holdingsType=-1\n" + 
			"enableDrops=true\n" + 
			"maxPromote=7\n" + 
			"promoZone=3\n" + 
			"promoOffset=8\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=1\n" + 
			"forceShogiPromotionZone=1,1\n" + 
			"forceShogiPromotionZone=4,1\n" + 
			"forceShogiPromotionZone=5,2\n" + 
			"graphicsDir=/futashikana_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"symmetry=rotate\n" + 
			"squareSize=45\n" + 
			"pawn:P:fW:p:a3-j3\n" + 
			"bishop:B:B:b:b2\n" + 
			"rook:R:R:r:i2\n" + 
			"lance:L:fR:l:a1,j1\n" + 
			"knight:N:ffN:n:b1,i1\n" + 
			"silver general:S:FfW:s:c1,h1\n" + 
			"gold general:G:WfF:g:d1,g1\n" + 
			"queen:Q:Q:q:e1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"vertical mover:+L:WvR:l2:\n" + 
			"white horse:+N:N:n2:\n" + 
			"vice general:+S:WfF:s2:\n" + 
			"great general:+S:FsfW:g2:\n" + 
			"king:K:K:k:f1";
	
	private static String suzumu_shogi = "name=Suzumu Shogi\n" + 
			"author=Adam DeWitt\n" + "files=16\n" + 
			"ranks=16\n" + 
			"maxPromote=30\n" + 
			"promoZone=5\n" + 
			"promoOffset=35\n" + 
			"promoChoice=shogi\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=45\n" + 
			"royal=66\n" + 
			"symmetry=mirror\n" + 
			"squareSize=39\n" + 
			"pawn:P:fW:p:a5-p5\n" + 
			"dog:D:bFfW:d:e6,l6\n" + 
			"knight:N:N:n:b1,o1\n" + 
			"iron general:I:fFbW:i:d1,m1\n" + 
			"copper general:C:fFvW:c:e1,l1\n" + 
			"silver general:S:FfW:s:f1,k1\n" + 
			"blind tiger:BT:FsbW:bt:f2,k2\n" + 
			"ferocious leopard:FL:FvW:fl:c1,n1\n" + 
			"gold general:G:WfF:g:g1,j1\n" + 
			"drunk elephant:DE:FsfW:de:h1\n" + 
			"reverse chariot:RV:vR:rv:a2,p2\n" + 
			"lance:L:fRbW2:l:a1,p1\n" + 
			"kirin:KY:FD:ky:g2\n" + 
			"phoenix:PH:WA:ph:j2\n" + 
			"side mover:SM:WsR:sm:a4,p4\n" + 
			"vertical mover:VM:WvR:vm:b4,o4\n" + 
			"bishop:B:B:b:c3,n3\n" + 
			"side soldier:SS:WsRfW2:ss:a3,p3\n" + 
			"vertical soldier:VS:WfRsW2:vs:b3,o3\n" + 
			"rook:R:R:r:c4,n4\n" + 
			"dragon horse:DH:BW:dh:d3,m3\n" + 
			"dragon king:DK:RF:dk:e3,l3\n" + 
			"chariot soldier:CS:BvRsW2:cs:c2,d2,m2,n2\n" + 
			"horned falcon:HF:BbsRfWfDfcavWfmabW:hf:d4,m4\n" + 
			"soaring eagle:SE:RbBfFfAfcavFfmabF:se:e4,l4\n" + 
			"lion:LN:KNADcaKmcabK:ln:h2\n" + 
			"queen:Q:Q:q:i2\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:f4,k4\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:g4,j4\n" + 
			"water buffalo:WB:BsRvW2:wb:f3,k3\n" + 
			"free eagle:FE:QADcasFcafFmcabF:fe:i3\n" + 
			"lion hawk:LH:BWNADcaKmcabK:lh:h3\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:i4\n" + 
			"great general:GG:pafpafcQmcQcpQ:gg:h4\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:g3,j3\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"chariot soldier:+VS:BvRsW2:vs2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"bishop general:+HF:pafpafcBmcBcpB:hf2:\n" + 
			"rook general:+SE:pafpafcRmcRcpR:se2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"king:K:K:k:i1";
	
	private static String taikyoku_shogi = "name=Taikyoku Shogi (Simplified)\n" + 
			"author=Adam DeWitt (simplifications only)\n" + 
			"files=36\n" + 
			"ranks=36\n" + 
			"promoOffset=208\n" + 
			"promoZone=0\n" + 
			"maxPromote=195\n" + 
			"promoChoice=capture\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/taikyoku/\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=192\n" + 
			"royal=381\n" + 
			"royal=400\n" + 
			"royal=404\n" + 
			"symmetry=rotate\n" + 
			"squareSize=37\n" + 
			"pawn:P:fW:p:a11-jj11\n" + 
			"go between:GB:vW:gb:k12,z12\n" + 
			"dog:D:fFfW:d:f12,o12,v12,ee12\n" + 
			"left chariot:LC:fRlWfrblB:lc:a10\n" + 
			"side monkey:MK:fFbWsR:mk:b10,ii10\n" + 
			"vertical mover:VM:WvR:vm:c10,hh10\n" + 
			"flying ox:OX:BvR:ox:d10,gg10\n" + 
			"longbow soldier:LB:bWsW2fF3fR:lb:e10,ff10\n" + 
			"vertical pup:VP:fRbWbF:vp:f10,ee10\n" + 
			"vertical horse:VH:fFbWfR:vh:g10,dd10\n" + 
			"burning soldier:BN:bWsW3fF5fW7:bn:h10,cc10\n" + 
			"dragon horse:DH:BW:dh:i10,bb10\n" + 
			"dragon king:DK:RF:dk:j10,aa10\n" + 
			"sword soldier:SE:fFbW:se:k10,z10\n" + 
			"horned falcon:HF:QfD:hf:l10,y10\n" + 
			"soaring eagle:EL:QfA:el:m10,x10\n" + 
			"spear soldier:SP:WfR:sp:n10,w10\n" + 
			"vertical leopard:VL:WfFfR:vl:o10,v10\n" + 
			"savage tiger:TG:fR:tg:p10,u10\n" + 
			"crossbow soldier:SB:bWsW3fF3fW5:sb:q10,t10\n" + 
			"lion dog:LD:QGH:ld:r10\n" + 
			"roaring dog:DG:RfBbB3H:dg:s10\n" + 
			"right chariot:RC:fRrWflbrB:rc:jj10\n" + 
			"chariot soldier:CH:BvRWnD:ch:a9,jj9\n" + 
			"side soldier:SL:WsRfnD:sl:b9,ii9\n" + 
			"vertical soldier:VR:WfRsnD:vr:c9,hh9\n" + 
			"wind general:WN:fFbWsW3:wn:d9,gg9\n" + 
			"river general:RE:fFbWsW3:re:e9,ff9\n" + 
			"mountain gemeral:M:fF3vW:m:f9,ee9\n" + 
			"front standard:SD:RF3:sd:g9,dd9\n" + 
			"horse soldier:HS:bWsW3fBfR:hs:h9,cc9\n" + 
			"wood general:GN:fF2:gn:i9,bb9\n" + 
			"ox soldier:OS:bWsW3fBfR:os:j9,aa9\n" + 
			"earth general:EA:vW:ea:k9,z9\n" + 
			"boar soldier:BS:bWsW2fBfR:bs:l9,y9\n" + 
			"stone general:SG:fF:sg:m9,x9\n" + 
			"leopard soldier:LP:bWsW2fBfR:lp:n9,w9\n" + 
			"tile general:T:fFbW:t:o9,v9\n" + 
			"bear soldier:BE:bWsW2fBfR:be:p9,u9\n" + 
			"iron general:I:fFfW:i:q9,t9\n" + 
			"earth chariot:EC:WvR:ec:a8,jj8\n" + 
			"blue dragon:BL:sW2rfBvR:bl:b8\n" + 
			"enchanted badger:EB:W2:eb:c8,hh8\n" + 
			"horseman:HO:fBvRsW2:ho:d8,gg8\n" + 
			"swooping owl:OW:bFfW:ow:e8,ff8\n" + 
			"climbing monkey:CM:fFvW:cm:f8,ee8\n" + 
			"cat sword:CS:F:cs:g8,dd8\n" + 
			"swallow's wings:SW:WfFsR:sw:h8,cc8\n" + 
			"blind monkey:BM:FsW:bm:i8,bb8\n" + 
			"blind tiger:BT:FsbW:bt:j8,aa8\n" + 
			"oxcart:OC:fR:oc:k8,z8\n" + 
			"side flier:SF:FsR:sf:l8,y8\n" + 
			"blind bear:BB:FsW:bb:m8,x8\n" + 
			"old rat:OR:bFfW:or:n8,w8\n" + 
			"square mover:SQ:R:sq:o8,v8\n" + 
			"coiled serpent:SN:bFvW:sn:p8,u8\n" + 
			"reclining dragon:RD:W:rd:q8,t8\n" + 
			"vermillion sparrow:VI:KflbrB:vi:ii8\n" + 
			"tile chariot:TC:frblFvR:tc:a7,jj7\n" + 
			"vertical wolf:VW:sWbW3fR:vw:b7,ii7\n" + 
			"side ox:SX:frblFsR:sx:c7,hh7\n" + 
			"donkey:DO:W2:do:d7,gg7\n" + 
			"flying horse:FH:F2:fh:e7,ff7\n" + 
			"violent bear:VB:bFfF2sW:vb:f7,ee7\n" + 
			"angry boar:AB:fF2sfW:ab:g7,dd7\n" + 
			"evil wolf:EW:fFsfW:ew:h7,cc7\n" + 
			"liberated horse:LH:bW2fFfR:lh:i7,bb7\n" + 
			"flying cock:CK:fFsW:ck:j7,aa7\n" + 
			"old monkey:OM:FbW:om:k7,z7\n" + 
			"chinese cock:CC:fFsbW:cc:l7,y7\n" + 
			"western barbarian:WS:sWvW2fF:ws:m7\n" + 
			"eastern barbarian:ES:sWvW2fF:es:n7\n" + 
			"violent stag:VS:FfW:vs:o7,v7\n" + 
			"violent wolf:NT:WfF:nt:p7,u7\n" + 
			"treacherus fox:TF:BvRjBjvRmpafmpyafFvmpafmpyafWAvDGvH:tf:q7,t7\n" + 
			"southern barbarian:SU:vWsW2fF:su:w7\n" + 
			"northern barbarian:NB:vWsW2fF:nb:x7\n" + 
			"wood chariot:WC:flbrFvR:wc:a6,jj6\n" + 
			"white horse:WH:fBvR:wh:b6,ii6\n" + 
			"left howling dog:LHD:fRbW:lhd:c6\n" + 
			"side mover:SM:WsR:sm:d6,gg6\n" + 
			"prancing stag:PR:vWsW2fF:pr:e6,ff6\n" + 
			"water buffalo:WB:BsRWnD:wb:f6,ee6\n" + 
			"ferocious leopard:FL:FvW:fl:g6,dd6\n" + 
			"fierce eagle:EG:F2sfW:eg:h6,cc6\n" + 
			"flying dragon:FD:A:fd:i6,bb6\n" + 
			"poisonous snake:PS:bWsfW2fF:ps:j6,aa6\n" + 
			"flying goose:DY:fFvW:fy:k6,z6\n" + 
			"strutting crow:ST:bFfW:st:l6,y6\n" + 
			"blind dog:BI:fFsbW:bi:m6,x6\n" + 
			"water general:WG:fF3vW:wg:n6,w6\n" + 
			"fire general:F:vW3fF:f:o6,v6\n" + 
			"kirin:KR:FsD:kr:p6\n" + 
			"capricorn:CA:WBmasB:ca:q6\n" + 
			"great turtle:GT:BvRsR3vH:gt:r6\n" + 
			"little turtle:LL:BvRsR2vD:ll:s6\n" + 
			"phoenix:PH:WA:ph:u6\n" + 
			"right howling dog:RHD:fRbW:rhd:hh6\n" + 
			"stone chariot:CI:vRsW2fF:ci:a5,jj5\n" + 
			"cloud eagle:CE:vRsWfF3:ce:b5,ii5\n" + 
			"bishop:B:B:b:c5,hh5\n" + 
			"rook:R:R:r:d5,gg5\n" + 
			"side wolf:WF:flbrFsR:wf:e5,ff5\n" + 
			"flying cat:FC:bFbWfGsfH:fc:f5,ee5\n" + 
			"mountain falcon:MF:RfBbB2fD:mf:g5,dd5\n" + 
			"vertical tiger:VT:fRbW2:vt:h5,cc5\n" + 
			"soldier:SO:R:so:i5,bb5\n" + 
			"little standard:LS:RbFfF2:ls:j5,aa5\n" + 
			"cloud dragon:CL:BbRsfW:cl:k5,z5\n" + 
			"copper chariot:CR:vRfF3:cr:l5,y5\n" + 
			"running chariot:RH:R:rh:m5,x5\n" + 
			"ram's-head soldier:HE:fBbW:he:n5,w5\n" + 
			"violent ox:VO:fBvW:vo:o5,v5\n" + 
			"great dragon:GD:BvW3:gd:p5,u5\n" + 
			"golden bird:GO:bF3sW3fBvRfjBfmpafmpyafFfmpafmpafmpyafFfAfGfDY:go:q5,t5\n" + 
			"deva:DV:lfbFW:dv:r5\n" + 
			"dark spirit:DS:rfbFW:ds:s5\n" + 
			"silver chariot:SV:bFfF2vR:sv:a4,jj4\n" + 
			"vertical bear:VE:WfRsnD:ve:b4,ii4\n" + 
			"knight:N:ffN:n:c4,hh4\n" + 
			"pig general:PI:fF4bW2:pi:d4,gg4\n" + 
			"chicken general:CG:bFfW4:cg:e4,ff4\n" + 
			"pup general:PG:bFfW4:pg:f4,ee4\n" + 
			"horse general:H:fFbWfW3:h:g4,dd4\n" + 
			"ox general:O:fFbWfW3:o:h4,cc4\n" + 
			"center standard:CN:RF3:cn:i4,bb4\n" + 
			"side boar:SA:KsR:sa:j4,aa4\n" + 
			"silver rabbit:SR:fB2bB:sr:k4,z4\n" + 
			"golden deer:GL:bB2fB:gl:l4,y4\n" + 
			"lion:LN:KNADcaKmcabK:ln:m4,x4\n" + 
			"captive cadet:CT:F3sfW3:ct:n4,w4\n" + 
			"great stag:GS:RbB2fA:gs:o4,v4\n" + 
			"violent dragon:VD:R2pafpafpafpafBpafpafpafBpafpafBmcBpB:vd:p4,u4\n" + 
			"woodland demon:WL:fBvRsW2:wl:q4,t4\n" + 
			"vice general:VG:DpafpafpafpafBpafpafpafBpafpafBmcBpB:vg:s4\n" + 
			"gold chariot:GC:FsW2vR:gc:a3,jj3\n" + 
			"side dragon:SI:sfR:si:b3,ii3\n" + 
			"running stag:RN:bW2fBsR:rn:c3,hh3\n" + 
			"running wolf:RW:fWfBsR:rw:d3,gg3\n" + 
			"bishop general:BG:pafpafpafpafBpafpafpafBpafpafBmcBpB:bg:e3,ff3\n" + 
			"rook general:RO:pafpafpafpafRpafpafpafRpafpafRmcRpR:ro:f3,ee3\n" + 
			"left tiger:LT:lvFrvBrR:lt:g3\n" + 
			"left dragon:LE:lW2rvBrR:le:h3\n" + 
			"beast officer:BO:F3sW2fW3:bo:i3,bb3\n" + 
			"wind dragon:WD:lbFrbfBsR:wd:j3,aa3\n" + 
			"free pup:FP:bFsW2fBvR:fp:k3,z3\n" + 
			"rushing bird:RB:FsWfW2:rb:l3,y3\n" + 
			"old kite:OK:F2sW:ok:m3,x3\n" + 
			"peacock:PC:bB2fBfmasB:pc:n3,w3\n" + 
			"water dragon:WA:RbB4fB2:wa:o3,v3\n" + 
			"fire dragon:FI:RfB4bB2:fi:p3,u3\n" + 
			"copper general:C:fFvW:c:q3,t3\n" + 
			"right dragon:RI:rW2lvBlR:ri:cc3\n" + 
			"right tiger:TT:rvFlvBlR:tt:dd3\n" + 
			"reverse chariot:RV:vR:rv:a2,jj2\n" + 
			"white elephant:WE:K2:we:b2\n" + 
			"turtle dove:TD:fF5sbW:td:c2,hh2\n" + 
			"flying swallow:FS:fBbW:fs:d2,gg2\n" + 
			"captive officer:CO:F3sfW2:co:e2,ff2\n" + 
			"rain dragon:RA:KbBsbR:ra:f2,ee2\n" + 
			"forest demon:FO:fBbRsfW3:fo:g2,dd2\n" + 
			"mountain stag:MS:fF3fWsW2bW4:ms:h2,cc2\n" + 
			"running pup:RP:WvR:rp:i2,bb2\n" + 
			"running serpent:RU:WvR:ru:j2,aa2\n" + 
			"side serpent:SS:bWfW3sR:ss:k2,z2\n" + 
			"great dove:GR:BW3:gr:l2,y2\n" + 
			"running tiger:RT:vRsW2:rt:m2,x2\n" + 
			"running bear:BA:vRsW2:ba:n2,w2\n" + 
			"buddhist devil:BD:fF3sbW:bd:o2\n" + 
			"wrestler:WR:F3:wr:p2\n" + 
			"silver general:S:FfW:s:q2,t2\n" + 
			"neighboring king:NK:FsfW:nk:r2\n" + 
			"drunk elephant:DE:FsfW:de:s2\n" + 
			"guardian of the gods:GU:W3:gu:u2\n" + 
			"yaksha:YA:fFbWsW3:ya:v2\n" + 
			"fragrant elephant:FG:K2:fg:ii2\n" + 
			"lance:L:fR:l:a1,jj1\n" + 
			"turtle-snake:TS:KfrblB:ts:b1\n" + 
			"running rabbit:RR:bFbWfBfR:rr:c1,hh1\n" + 
			"whale:W:bBvR:w:d1,gg1\n" + 
			"fire demon:DM:BsRWnD:dm:e1,ff1\n" + 
			"left mountain eagle:LME:RlbfBrbB2lvA:lme:f1\n" + 
			"beast cadet:BC:F2sfW2:bc:h1,cc1\n" + 
			"running horse:HR:bWfBfRbA:hr:i1,bb1\n" + 
			"free demon:FR:BsRvW5:fr:j1,aa1\n" + 
			"earth dragon:ED:fFbWfW2bB:ed:k1,z1\n" + 
			"free dream eater:FT:BvRsW5:ft:m1,x1\n" + 
			"queen:Q:Q:q:n1,w1\n" + 
			"rear standard:RS:RF2:rs:o1,v1\n" + 
			"left general:LG:K:lg:p1\n" + 
			"gold general:G:WfF:g:q1,t1\n" + 
			"crown prince:CP:K:cp:s1\n" + 
			"right general:RG:K:rg:u1\n" + 
			"right mountain eagle:RME:RrbfBlbB2rvA:rme:ee1\n" + 
			"white tiger:WT:vW2lfBsR:wt:ii1\n" + 
			"great master:GM:sW5bF5fBvRfGfH:gm:r9\n" + 
			"great standard:GE:RfBbB3:ge:s9\n" + 
			"lion hawk:LI:jBKNADcaKmcabK:li:r8\n" + 
			"free eagle:FE:QjQmpafmpyafKfmpafmpafmpyafFADGHfDY:fe:s8\n" + 
			"roc master:RM:sW5bF5vRfmpafmpyafFfG:rm:r7\n" + 
			"center master:MT:sW3bF3fBbRjfBjvRFfAvD:mt:s7\n" + 
			"hook mover:HM:RmasR:hm:t6\n" + 
			"great general:GG:pafpafpafpafQpafpafpafQpafpafQmcQpQ:gg:r4\n" + 
			"kirin master:KM:BvRsR3vH:km:r3\n" + 
			"phoenix master:PM:BvRsR3fG:pm:s3\n" + 
			"tengu:LO:BmasB:lo:g1,dd1\n" + 
			"ceramic dove:CD:BW2:cd:l1\n" + 
			"wooden dove:WO:BW2mpafmpafafFmpafmpafafafFG:wo:y1\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"drunk elephant:+GB:FsfW:gb2:\n" + 
			"multi general:+D:fBvR:d2:\n" + 
			"left iron chariot:+LC:lWrfbB:lc2:\n" + 
			"side soldier:+MK:WsRfnD:mk2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"fire ox:+OX:BvRsW:ox2:\n" + 
			"longbow general:+LB:BvRsW5:lb2:\n" + 
			"leopard king:+VP:K5:vp2:\n" + 
			"dragon horse:+VH:BW:vh2:\n" + 
			"burning general:+BN:bW2sW3fBfR:bn2:\n" + 
			"horned falcon:+DH:QfD:dh2:\n" + 
			"soaring eagle:+DK:QfA:dk2:\n" + 
			"sword general:+SE:fF3bWfW3:se2:\n" + 
			"great falcon:+HF:QvD:hf2:\n" + 
			"great eagle:+EL:QAD:el2:\n" + 
			"spear general:+SP:bW2sW3fR:sp2:\n" + 
			"great leopard:+VL:bWsW2fF3fR:vl2:\n" + 
			"great tiger:+TG:WsbR:tg2:\n" + 
			"crossbow general:+SB:bW2sW2fBfR:sb2:\n" + 
			"great elephant:+LD:RfB3bBjRbjBbmpafmpyafFbmpafmpafmpyafFbADbGbDY:ld2:\n" + 
			"lion dog:+DG:QGH:dg2:\n" + 
			"right iron chariot:+RC:rWlfbB:rc2:\n" + 
			"heavenly tetrarch king:+CH:QjQADcabK:ch2:\n" + 
			"water buffalo:+SL:BsRWnD:sl2:\n" + 
			"chariot soldier:+VR:BvRWnD:vr2:\n" + 
			"violent wind:+WN:KBvR:wn2:\n" + 
			"chinese river:+RE:KBsR:re2:\n" + 
			"peaceful mountain:+M:BsfW5:m2:\n" + 
			"great standard:+SD:RfBbB3:sd2:\n" + 
			"running horse:+HS:bWfBfRbA:hs2:\n" + 
			"white elephant:+GN:K2:gn2:\n" + 
			"running ox:+OS:bB2fBsfR:os2:\n" + 
			"white elephant:+EA:K2:ea2:\n" + 
			"running boar:+BS:WvR:bs2:\n" + 
			"white elephant:+SG:K2:sg2:\n" + 
			"running leopard:+LP:fBsfR:lp2:\n" + 
			"white elephant:+T:K2:t2:\n" + 
			"strong bear:+BE:bW2BsfR:be2:\n" + 
			"white elephant:+I:K2:i2:\n" + 
			"young bird:+EC:bF2sW2vR:ec2:\n" + 
			"divine dragon:+BL:lW2vrRrfB:bl2:\n" + 
			"ceramic dove:+EB:BW2:eb2:\n" + 
			"cavalier:+HO:RfB:ho2:\n" + 
			"cloud eagle:+OW:vRsWfF3:ow2:\n" + 
			"violent stag:+CM:FfW:cm2:\n" + 
			"dragon horse:+CS:BW:cs2:\n" + 
			"gliding swallow:+SW:R:sw2:\n" + 
			"flying stag:+BM:KvR:bm2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"plodding ox:+OC:FvR:oc2:\n" + 
			"side dragon:+SF:sfR:sf2:\n" + 
			"flying stag:+BB:KvR:bb2:\n" + 
			"bird of paradise:+OR:fBvR:or2:\n" + 
			"strong chariot:+SQ:RfB:sq2:\n" + 
			"coiled dragon:+SN:bBvR:sn2:\n" + 
			"great dragon:+RD:BvW3:rd2:\n" + 
			"divine sparrow:+VI:KlfbB:vi2:\n" + 
			"running tile:+TC:vRsW2:tc2:\n" + 
			"running wolf:+VW:fWfBsR:vw2:\n" + 
			"flying ox:+SX:BvR:sx2:\n" + 
			"ceramic dove:+DO:BW2:do2:\n" + 
			"queen:+FH:Q:fh2:\n" + 
			"great bear:+VB:WfBfR:vb2:\n" + 
			"free boar:+AB:WfBsfR:ab2:\n" + 
			"venomous wolf:+EW:K:ew2:\n" + 
			"heavenly horse:+LH:vvNfR:lh2:\n" + 
			"raiding falcon:+CK:fFsWfR:ck2:\n" + 
			"mountain witch:+OM:bBbR:om2:\n" + 
			"wizard stork:+CC:fBsbR:cc2:\n" + 
			"lion dog:+WS:QGH:ws2:\n" + 
			"lion:+ES:KNADcaKmcabK:es2:\n" + 
			"rushing boar:+VS:FsfW:vs2:\n" + 
			"bear's eyes:+NT:K:nt2:\n" + 
			"mountain crane:+TF:QmpafmpyafKGH:tf2:\n" + 
			"golden bird:+SU:bF3sW3fBvRfjBfmpafmpyafFfmpafmpafmpyafFfAfGfDY:su2:\n" + 
			"wooden dove:+NB:BW2mpafmpafafFmpafmpafafafFG:nb2:\n" + 
			"wind snapping turtle:+WC:fB2vR:wc2:\n" + 
			"great horse:+WH:fBvRsW2:wh2:\n" + 
			"left dog:+LHD:bWrbBfR:lhd2:\n" + 
			"free boar:+SM:WfBsfR:sm2:\n" + 
			"square mover:+PR:R:pr2:\n" + 
			"great dream eater:+WB:QsH:wb2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"soaring eagle:+EG:QfA:eg2:\n" + 
			"dragon king:+FD:RF:fd2:\n" + 
			"hook mover:+PS:RmasR:ps2:\n" + 
			"swallow's wings:+DY:WfFsR:fy2:\n" + 
			"flying falcon:+ST:BfW:st2:\n" + 
			"violent stag:+BI:FfW:bi2:\n" + 
			"vice general:+WG:DpafpafpafpafBpafpafpafBpafpafBmcBpB:wg2:\n" + 
			"great general:+F:pafpafpafpafQpafpafpafQpafpafQmcQpQ:f2:\n" + 
			"golden bird:+KR:bF3sW3fBvRfjBfmpafmpyafFfmpafmpafmpyafFfAfGfDY:kr2:\n" + 
			"hook mover:+CA:RmasR:ca2:\n" + 
			"spirit turtle:+GT:QH:gt2:\n" + 
			"treasure turtle:+LL:QD:ll2:\n" + 
			"golden bird:+PH:bF3sW3fBvRfjBfmpafmpyafFfmpafmpafmpyafFfAfGfDY:ph2:\n" + 
			"right dog:+RHD:bWlbBfR:rhd2:\n" + 
			"walking heron:+CI:fF2sW2vR:ci2:\n" + 
			"strong eagle:+CE:Q:ce2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"free wolf:+WF:fBsfR:wf2:\n" + 
			"rook:+FC:R:fc2:\n" + 
			"horned falcon:+MF:QfD:mf2:\n" + 
			"free tiger:+VT:BsbR:vt2:\n" + 
			"cavalier:+SO:RfB:so2:\n" + 
			"rear standard:+LS:RF2:ls2:\n" + 
			"great dragon:+CL:BvW3:cl2:\n" + 
			"copper elephant:+CR:KvR:cr2:\n" + 
			"burning chariot:+RH:sWfBvR:rh2:\n" + 
			"tiger soldier:+HE:bWfW2fB:he2:\n" + 
			"flying ox:+VO:BvR:vo2:\n" + 
			"ancient dragon:+GD:BvpafpafpafpafcRvpafpafpafcRvpafpafcRvRvcpR:gd2:\n" + 
			"free bird:+GO:RbB3fBfjBfmpafmpyafFfmpafmpafmpyafFfAfGfDY:go2:\n" + 
			"teaching king:+DV:QjQmpafmpyafKmpafmpafmpyafKADGHWXDY:dv2:\n" + 
			"buddhist spirit:+DS:QNADcaKmcabK:ds2:\n" + 
			"goose wing:+SV:FsW3vR:sv2:\n" + 
			"free bear:+VE:BvR:ve2:\n" + 
			"side soldier:+N:WsRfnD:n2:\n" + 
			"free pig:+PI:bFsW2fBvR:pi2:\n" + 
			"free chicken:+CG:fBvRsW2:cg2:\n" + 
			"free pup:+PG:bFsW2fBvR:pg2:\n" + 
			"free horse:+H:bFsW2fBvR:h2:\n" + 
			"free ox:+O:bFsW2fBvR:o2:\n" + 
			"front standard:+CN:RF3:cn2:\n" + 
			"free boar:+SA:WfBsfR:sa2:\n" + 
			"whale:+SR:bBvR:sr2:\n" + 
			"white horse:+GL:fBvR:gl2:\n" + 
			"furious fiend:+LN:K3NADcaKmcabK:ln2:\n" + 
			"captive officer:+CT:F3sfW2:ct2:\n" + 
			"free stag:+GS:Q:gs2:\n" + 
			"great dragon:+VD:BvW3:vd2:\n" + 
			"right phoenix:+WL:BvRsW5:wl2:\n" + 
			"great general:+VG:pafpafpafpafQpafpafpafQpafpafQmcQpQ:vg2:\n" + 
			"playful cockatoo:+GC:bF2fF3sW5vR:gc2:\n" + 
			"running dragon:+SI:bW5BsfR:si2:\n" + 
			"free stag:+RN:Q:rn2:\n" + 
			"free wolf:+RW:fBsfR:rw2:\n" + 
			"rain demon:+BG:sR2fR3bRfpafpafpafpafcBfpafpafpafcBfpafpafcBfBfcpB:bg2:\n" + 
			"flying crocodile:+RO:bB2fB3pafpafpafpafRpafpafpafRpafpafRmcRpR:ro2:\n" + 
			"turtle-snake:+LT:KfrblB:lt2:\n" + 
			"vermillion sparrow:+LE:KflbrB:le2:\n" + 
			"beast bird:+BO:bW2sW3BfR:bo2:\n" + 
			"free dragon:+WD:BsbR:wd2:\n" + 
			"free dog:+FP:bF2sW2fBvR:fp2:\n" + 
			"free demon:+RB:BsRvW5:rb2:\n" + 
			"tengu:+OK:BmasB:ok2:\n" + 
			"tengu:+PC:BmasB:pc2:\n" + 
			"phoenix master:+WA:BvRsR3fG:wa2:\n" + 
			"kirin master:+FI:BvRsR3vH:fi2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"blue dragon:+RI:sW2rfBvR:ri2:\n" + 
			"white tiger:+TT:vW2lfBsR:tt2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"elephant king:+WE:BW2:we2:\n" + 
			"great dove:+TD:BW3:td2:\n" + 
			"rook:+FS:R:fs2:\n" + 
			"captive bird:+CO:bW2sW3BfR:co2:\n" + 
			"great dragon:+RA:BvW3:ra2:\n" + 
			"thunder runner:+FO:sbW4fBfR:fo2:\n" + 
			"great stag:+MS:RbB2fA:ms2:\n" + 
			"free leopard:+RP:BvR:rp2:\n" + 
			"free serpent:+RU:bBvR:ru2:\n" + 
			"great shark:+SS:RfB5bB2:ss2:\n" + 
			"wooden dove:+GR:BW2mpafmpafafFmpafmpafafafFG:gr2:\n" + 
			"free tiger:+RT:BsbR:rt2:\n" + 
			"free bear:+BA:BvR:ba2:\n" + 
			"heavenly tetrarch:+BD:K4:bd2:\n" + 
			"heavenly tetrarch:+WR:K4:wr2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"front standard:+NK:RF3:nk2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"heavenly tetrarch:+GU:K4:gu2:\n" + 
			"heavenly tetrarch:+YA:K4:ya2:\n" + 
			"elephant king:+FG:BW2:fg2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"divine turtle:+TS:KrfbB:ts2:\n" + 
			"treacherous fox:+RR:BvRjBjvRmpafmpyafFvmpafmpyafWAvDGvH:rr2:\n" + 
			"great whale:+W:BvR:w2:\n" + 
			"free fire:+DM:BsRvW5:dm2:\n" + 
			"soaring eagle:+LME:QfA:lme2:\n" + 
			"beast officer:+BC:F3sW2fW3:bc2:\n" + 
			"free demon:+HR:BsRvW5:hr2:\n" + 
			"queen:+FR:Q:fr2:\n" + 
			"rain dragon:+ED:KbBsbR:ed2:\n" + 
			"queen:+FT:Q:ft2:\n" + 
			"great general:+Q:pafpafpafpafQpafpafpafQpafpafQmcQpQ:q2:\n" + 
			"center standard:+RS:RF3:rs2:\n" + 
			"left army:+LG:KrvBrR:lg2:\n" + 
			"rook:+G:R:g2:\n" + 
			"king:+CP:K2:cp2:\n" + 
			"right army:+RG:KlvBlR:rg2:\n" + 
			"soaring eagle:+RME:QfA:rme2:\n" + 
			"divine tiger:+WT:bW2sfRlfB:wt2:\n" + 
			"king:K:K2:k:r1";
	
	private static String taishin_shogi = "name=Taishin Shogi\n" + 
			"author=Adam DeWitt\n" + 
			"files=25\n" + 
			"ranks=25\n" + 
			"maxPromote=79\n" + 
			"promoZone=0\n" + 
			"promoOffset=86\n" + 
			"promoChoice=capture\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/taishin_mnemonic/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFFF80\n" + 
			"darkShade=#FFFF80\n" + 
			"shogiMode=true\n" + 
			"flipPiecesOnBoardFlip=true\n" + 
			"royal=78\n" + 
			"royal=79\n" + 
			"royal=163\n" + 
			"royal=164\n" + 
			"royal=165\n" + 
			"contagiousPromotion=75\n" + 
			"contagiousPromotion=76\n" + 
			"contagious=161\n" + 
			"contagious=162\n" + 
			"symmetry=rotate\n" + 
			"squareSize=39\n" + 
			"pawn:P:fW:p:a7-y7\n" + 
			"dog:D:bFfW:d:h8,r8\n" + 
			"knight:N:N:n:d2,v2\n" + 
			"earth general:E:vW:e:d5,v5\n" + 
			"stone general:O:fF:o:e5,u5\n" + 
			"tile general:T:fFbW:t:f5,t5\n" + 
			"iron general:I:fFfW:i:g5,s5\n" + 
			"copper general:C:fFvW:c:h5,r5\n" + 
			"silver general:S:FfW:s:k2,o2\n" + 
			"blind tiger:BT:FsbW:bt:j3,p3\n" + 
			"ferocious leopard:FL:FvW:fl:c4,w4\n" + 
			"gold general:G:WfF:g:k1,o1\n" + 
			"cat sword:CT:F:ct:c3,w3\n" + 
			"angry boar:AB:W:ab:k6,o6\n" + 
			"evil wolf:EW:fFfsW:ew:l6,n6\n" + 
			"coiled serpent:CO:bFvW:co:i5,q5\n" + 
			"blind dog:BD:fFsbW:bd:f4,t4\n" + 
			"old monkey:OM:FbW:om:h4,r4\n" + 
			"reclining dragon:RN:WbF:rn:j6,p6\n" + 
			"flying horse:FH:F2:fh:d1,v1\n" + 
			"flying dragon:FN:W2:fn:d3,v3\n" + 
			"roaring dog:RD:K3:rd:f1,t1\n" + 
			"reverse chariot:RV:vR:rv:a2,y2\n" + 
			"lance:L:fRbW2:l:a1,y1\n" + 
			"whale:WL:bBvR:wl:c1,w1\n" + 
			"white horse:WH:fBvR:wh:b3,x3\n" + 
			"howling dog:HD:fRbW:hd:a6,y6\n" + 
			"kirin:KY:FD:ky:n4,l4\n" + 
			"phoenix:PH:WA:ph:i3,q3\n" + 
			"warrior:WR:WfFA:wr:j4,p4\n" + 
			"poisonous snake:PS:FvWD:ps:e2,u2\n" + 
			"left chariot:LC:fRbWflbrB:lc:a5\n" + 
			"right chariot:RC:fRbWfrblB:rc:y5\n" + 
			"soldier:SO:RbB:so:a3,y3\n" + 
			"side mover:SM:WsR:sm:f6,t6\n" + 
			"vertical mover:VM:WvR:vm:g6,s6\n" + 
			"bishop:B:B:b:g2,s2\n" + 
			"side soldier:SS:WsRfW2:ss:e3,u3\n" + 
			"vertical soldier:VS:WfRsW2:vs:f3,t3\n" + 
			"rook:R:R:r:g1,s1\n" + 
			"side chariot:SC:sRvW2:sc:b5,x5\n" + 
			"vertical chariot:VC:vRsW2:vc:c5,w5\n" + 
			"dragon horse:DH:BW:dh:h1,r1\n" + 
			"dragon king:DK:RF:dk:i1,q1\n" + 
			"fire dragon:F:RfB4bB2:f:i6,q6\n" + 
			"water dragon:W:RbB4fB2:w:h6,r6\n" + 
			"earth dragon:H:BsR4vR2:h:c6,w6\n" + 
			"wind dragon:A:BvR4sR2:a:b6,x6\n" + 
			"violent falcon:VF:BN:vf:k4,o4\n" + 
			"fierce eagle:VE:RN:ve:k3,o3\n" + 
			"chariot soldier:CS:BvRsW2:cs:a4,y4\n" + 
			"mountain falcon:MF:RfBbB2fD:mf:d6,v6\n" + 
			"left mountain eagle:LE:RlbfBrbB2lvA:le:e6\n" + 
			"right mountain eagle:RE:RrbfBlbB2rvA:re:u6\n" + 
			"horned falcon:HF:BbsRfWfDfcavWfmabW:hf:g4,s4\n" + 
			"soaring eagle:SE:RbBfFfAfcavFfmabF:se:c2,w2\n" + 
			"lion:LN:KNADcaKmcabK:ln:h3,r3\n" + 
			"lion dog:LD:KADGHcafKmcabKcafmpafKmpafcavK:ld:g3,s3\n" + 
			"queen:Q:Q:q:j1,p1\n" + 
			"free eagle:FE:QADcasFcafFmcabF:fe:m6\n" + 
			"lion hawk:LH:BWNADcaKmcabK:lh:m5\n" + 
			"bishop general:BG:pafpafcBmcBcpB:bg:d4,v4\n" + 
			"rook general:RG:pafpafcRmcRcpR:rg:e4,u4\n" + 
			"violent horse:VH:R3pafpafcBmcBcpB:vh:h2,r2\n" + 
			"violent dragon:VD:B3pafpafcRmcRcpR:vd:i2,q2\n" + 
			"vice master:VA:DpafpafcBmcBcpB:va:b1,x1\n" + 
			"great master:GA:ApafpafcRmcRcpR:ga:b2,x2\n" + 
			"water buffalo:WB:BsRvW2:wb:b4,x4\n" + 
			"free demon:HK:BsRvW5:hk:j2,p2\n" + 
			"free dream eater:HB:BvRsW5:hb:f2,t2\n" + 
			"peacock:PC:bB2fBfmasB:pc:i4,q4\n" + 
			"capricorn:CA:BmasB:ca:e1,u1\n" + 
			"left general:LT:FvrW:lt:l2\n" + 
			"right general:RT:FvlW:rt:n2\n" + 
			"deva:DV:lfbFW:dv:l1\n" + 
			"dark spirit:DS:rfbFW:ds:n1\n" + 
			"drunk elephant:DE:FsfW:de:m3\n" + 
			"crown prince:CP:K:cp:m2\n" + 
			"king:K:K:k:m1\n" + 
			"furious fiend:FF:KNADGHcaKmcabKcafmpafKmpafcavK:ff:m4\n" + 
			"vice general:VG:pafpafcBmcBcpBKaKaaKmabK:vg:n3\n" + 
			"great general:GG:pafpafcQmcQcpQ:gg:l3\n" + 
			"heavenly tetrarch:HT:jsR3jBjvRcabK:ht:j5,p5\n" + 
			"fire demon:FD:BsRKaKaaKcaKmcabK:fd:k5,o5\n" + 
			"tengu:TG:WBmasB:tg:l5\n" + 
			"hook mover:HM:RmasR:hm:n5\n" + 
			"tokin:+P:WfF:p2:\n" + 
			"multi general:+D:bBfR:d2:\n" + 
			"side soldier:+N:WsRfW2:n2:\n" + 
			"reverse chariot:+E:vR:e2:\n" + 
			"side chariot:+O:sRvW2:o2:\n" + 
			"vertical chariot:+T:vRsW2:t2:\n" + 
			"vertical soldier:+I:WfRsW2:i2:\n" + 
			"side mover:+C:WsR:c2:\n" + 
			"vertical mover:+S:WvR:s2:\n" + 
			"flying stag:+BT:KvR:bt2:\n" + 
			"bishop:+FL:B:fl2:\n" + 
			"rook:+G:R:g2:\n" + 
			"free cat:+CT:B:ct2:\n" + 
			"running boar:+AB:R:ab2:\n" + 
			"free wolf:+EW:KsR:ew2:\n" + 
			"free serpent:+CO:bBvR:co2:\n" + 
			"wizard stork:+BD:BsfRbW:bd2:\n" + 
			"mountain witch:+OM:BsbRfW:om2:\n" + 
			"free dragon:+RN:RbB:rn2:\n" + 
			"violent falcon:+FH:BN:fh2:\n" + 
			"fierce eagle:+FN:RN:fn2:\n" + 
			"lion dog:+RD:KADGHcafKmcabKcafmpafKmpafcavK:rd2:\n" + 
			"whale:+RV:bBvR:rv2:\n" + 
			"white horse:+L:fBvR:l2:\n" + 
			"great whale:+WL:bBvRsR2:wl2:\n" + 
			"great horse:+WH:fBvRsR2:wh2:\n" + 
			"roaring dog:+HD:K3:hd2:\n" + 
			"lion:+KY:KNADcaKmcabK:ky2:\n" + 
			"queen:+PH:Q:ph2:\n" + 
			"tengu:+WR:WBmasB:wr2:\n" + 
			"hook mover:+PS:RmasR:ps2:\n" + 
			"left army:+LC:KrvBrR:lc2:\n" + 
			"right army:+RC:KlvBlR:rc2:\n" + 
			"cavalier:+SO:RfB:so2:\n" + 
			"free boar:+SM:BsR:sm2:\n" + 
			"flying ox:+VM:BvR:vm2:\n" + 
			"dragon horse:+B:BW:b2:\n" + 
			"water buffalo:+SS:BsRvW2:ss2:\n" + 
			"chariot soldier:+VS:BvRsW2:vs2:\n" + 
			"dragon king:+R:RF:r2:\n" + 
			"free demon:+SC:BsRvW5:sc2:\n" + 
			"free dream eater:+VC:BvRsW5:vc2:\n" + 
			"horned falcon:+DH:BbsRfWfDfcavWfmabW:dh2:\n" + 
			"soaring eagle:+DK:RbBfFfAfcavFfmabF:dk2:\n" + 
			"kirin master:+F:BbsRfWfDfHfcafWfmcabWfcafmpafWfmpafcavW:f2:\n" + 
			"phoenix master:+W:RbBfFfAfGfcafFfmcabFfcafmpafFfmpafcavF:w2:\n" + 
			"earthward net:+H:BWaKmabK:h2:\n" + 
			"skyward net:+A:RFaKmabK:a2:\n" + 
			"violent horse:+VF:R3pafpafcBmcBcpB:vf2:\n" + 
			"violent dragon:+VE:B3pafpafcRmcRcpR:ve2:\n" + 
			"heavenly tetrarch:+CS:jsR3jBjvRcabK:cs2:\n" + 
			"horned falcon:+MF:BbsRfWfDfcavWfmabW:mf2:\n" + 
			"soaring eagle:+LE:RbBfFfAfcavFfmabF:le2:\n" + 
			"soaring eagle:+RE:RbBfFfAfcavFfmabF:re2:\n" + 
			"bishop general:+HF:pafpafcBmcBcpB:hf2:\n" + 
			"rook general:+SE:pafpafcRmcRcpR:se2:\n" + 
			"lion hawk:+LN:BWNADcaKmcabK:ln2:\n" + 
			"furious fiend:+LD:KNADGHcaKmcabKcafmpafKmpafcavK:ld2:\n" + 
			"free eagle:+Q:QADcasFcafFmcabF:q2:\n" + 
			"golden bird:+FE:QDcasWcafWmcabW:fe2:\n" + 
			"great dragon:+LH:RFNADcaKmcabK:lh2:\n" + 
			"vice general:+BG:pafpafcBmcBcpBKaKaaKmabK:bg2:\n" + 
			"great general:+RG:pafpafcQmcQcpQ:rg2:\n" + 
			"horse master:+VH:pafpafcBmcBcpBKaKmabK:vh2:\n" + 
			"dragon master:+VD:pafpafcRmcRcpRKaKmabK:vd2:\n" + 
			"vice general:+VA:pafpafcBmcBcpBKaKaaKmabK:va2:\n" + 
			"great general:+GA:pafpafcQmcQcpQ:ga2:\n" + 
			"fire demon:+WB:BsRKaKaaKcaKmcabK:wb2:\n" + 
			"great demon:+HK:BsRKaKaaKmabK:hk2:\n" + 
			"great dream eater:+HB:BvRKaKaaKmabK:hb2:\n" + 
			"tengu:+PC:WBmasB:pc2:\n" + 
			"hook mover:+CA:RmasR:ca2:\n" + 
			"shogun:+LT:KaKaaKmabK:lt2:\n" + 
			"shogun:+RT:KaKaaKmabK:rt2:\n" + 
			"teaching king:+DV:QADGHcafKmcabKcafmpafKmpafcavK:dv2:\n" + 
			"divine dragon:+DS:QNADcaKmcabK:ds2:\n" + 
			"crown prince:+DE:K:de2:\n" + 
			"king:+CP:K:cp2:\n" + 
			"emperor:+K:U:k2:";
	
	private static String xiangqi = "name=Xiangqi\n" + 
			"files=9\n" + 
			"ranks=10\n" + 
			"promoZone=5\n" + 
			"promoOffset=1\n" + 
			"promoChoice=shogi\n" + 
			"forcePromotions=2\n" + 
			"graphicsDir=/xiangqi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"shades=111000111/111000111/111000111/111111111/111111111/000000000/000000000/000111000/000111000/000111000\n" + 
			"symmetry=mirror\n" + 
			"squareSize=54\n" + 
			"soldier:S:fW:soldier:a4,c4,e4,g4,i4\n" + 
			"soldier:Q:fsW:soldier:\n" + 
			"cannon:C:mRcpR:cannon:b3,h3\n" + 
			"chariot:R:R:chariot:a1,i1\n" + 
			"horse:H:mafsW:horse:b1,h1\n" + 
			"elephant:E:mafF:elephant:c1,g1\n" + 
			"advisor:A:F:advisor:d1,f1\n" + 
			"general:G:WfkR:general:e1";
	
	private static String yangsi = "name=Yangsi\n" + 
			"author=Adam DeWitt\n" + "files=10\n" + 
			"ranks=10\n" + 
			"promoChoice=QMARSCNBVW\n" + 
			"graphicsDir=/yangsi/\n" + 
			"whitePrefix=w\n" + 
			"blackPrefix=b\n" + 
			"lightShade=#FFCC9C\n" + 
			"darkShade=#CF8948\n" + 
			"squareSize=54\n" + 
			"symmetry=mirror\n" + 
			"pawn:P:ifmnDfmWfceF:pawn:a3-j3\n" + 
			"knight:N:N:knight:c2,h2\n" + 
			"bishop:B:B:bishop:d2,g2\n" + 
			"rook:R:R:rook:a2,j2\n" + 
			"queen:Q:Q:queen:e2\n" + 
			"wizard:W:FC:wizard:b1,i1\n" + 
			"champion:S:WAD:champion:b2,i2\n" + 
			"marshall:M:RN:marshall:a1,j1\n" + 
			"archbishop:A:BN:archbishop:d1,g1\n" + 
			"cannon:C:mRcpR:cannon:c1,h1\n" + 
			"vao:V:mBcpB:vao:e1,f1\n" + 
			"king:K:KisO3isO2:king:f2";
	
	public static String getPresetText(String name)
	{
		if(name.equals("cannon_shosu_shogi"))
		{
			return cannon_shosu_shogi;
		}
		else if(name.equals("chess"))
		{
			return chess;
		}
		else if(name.equals("chushin_shogi"))
		{
			return chushin_shogi;
		}
		else if(name.equals("futashikana_shogi"))
		{
			return futashikana_shogi;
		}
		else if(name.equals("grand_chess"))
		{
			return grand_chess;
		}
		else if(name.equals("gross_chess"))
		{
			return gross_chess;
		}
		else if(name.equals("hectochess"))
		{
			return hectochess;
		}
		else if(name.equals("hook_shogi"))
		{
			return hook_shogi;
		}
		else if(name.equals("manchu_chess"))
		{
			return manchu_chess;
		}
		else if(name.equals("microshogi"))
		{
			return microshogi;
		}
		else if(name.equals("minishogi"))
		{
			return minishogi;
		}
		else if(name.equals("maka_dai_dai_shogi"))
		{
			return maka_dai_dai_shogi;
		}
		else if(name.equals("mitsugumi_shogi"))
		{
			return mitsugumi_shogi;
		}
		else if(name.equals("omega_chess"))
		{
			return omega_chess;
		}
		else if(name.equals("ryugi"))
		{
			return ryugi;
		}
		else if(name.equals("shogi"))
		{
			return shogi;
		}
		else if(name.equals("shosu_shogi"))
		{
			return shosu_shogi;
		}
		else if(name.equals("suzumu_shogi"))
		{
			return suzumu_shogi;
		}
		else if(name.equals("taikyoku_shogi"))
		{
			return taikyoku_shogi;
		}
		else if(name.equals("taishin_shogi"))
		{
			return taishin_shogi;
		}
		else if(name.equals("xiangqi"))
		{
			return xiangqi;
		}
		else if(name.equals("yangsi"))
		{
			return yangsi;
		}
		else
		{
			return "";
		}
	}
}
