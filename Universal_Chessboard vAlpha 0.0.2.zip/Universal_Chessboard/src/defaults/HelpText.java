package defaults;

/**
 * The Help class stores all of the help texts used in the Universal Chessboard so they can be</br>
 * fetched regardless of whether the program is run in Eclipse or from a .jar file.
 */
public class HelpText {
	private static String key_bindings = "Menu Shortcuts\n" + 
			"\n" + 
			"File Menu\n" + 
			"\n" + 
			"Ctrl-N: New Game - Starts a new game, asking for confirmation before doing so. Does nothing if the currently loaded game has no moves in it.\n" + 
			"\n" + 
			"Ctrl-Shift-N: Load Game Preset - Opens the dialog for loading a game preset.\n" + 
			"\n" + 
			"Ctrl-Shift-R: Reload Current Preset - Reloads the current preset and preserves the current game, asking for confirmation before doing so. Useful if you need to reload the piece images, especially if the images are from the Internet.\n" + 
			"\n" + 
			"Edit Menu\n" + 
			"\n" + 
			"Ctrl-O: FEN Code - Opens the dialog for loading a board position from FEN Code.\n" + 
			"\n" + 
			"Ctrl-I: Game Moves - Opens the dialog for appending game moves using text.\n" + 
			"\n" + 
			"View Menu\n" + 
			"\n" + 
			"F2: Flip View - Rotates the board 180 degrees.\n" + 
			"\n" + 
			"Ctrl-0: Reset Viewing Size/Position - Changes the width and height of the window to fit within the current viewing screen and centers the window on screen. This feature allows the user to resize the board without having to worry about the window borders straying off-screen. Scroll bars are automatically provided whenever the board itself is too large to be viewed within the window.\n" + 
			"\n" + 
			"M: Show Move History - Opens a dialog that shows the current game's move sequence. The move sequence is updated in real time as move are made or undone.\n" + 
			"\n" + 
			"H: Show Holdings - Opens the holdings, a dialog that gives you a complete piece overview and is used to drop pieces with the mouse when drops are enabled.\n" + 
			"\n" + 
			"Board Shortcuts\n" + 
			"\n" + 
			"Ctrl-Up Arrow: << - Navigates to the beginning/initial position of the game.\n" + 
			"\n" + 
			"Ctrl-Left Arrow: < - Navigates to the position before the currently displayed position.\n" + 
			"\n" + 
			"Ctrl-Right Arrow: > - Navigates to the position before the currently displayed position.\n" + 
			"\n" + 
			"Ctrl-Down Arrow: >> - Navigates to the end/current position of the game.\n" + 
			"\n" + 
			"Ctrl-Z: Undo Move - Undoes the last move.\n" + 
			"\n" + 
			"Ctrl-Click: Multi-Move - This is an ad-hoc method for allowing a piece to make two or more moves at once. If a board square is clicked while the Ctrl key is down, instead of moving the piece, the board marks the clicked square as an intermediate square in the move. Any number of squares may be marked as intermediate with this method. Clicking a board square normally after at least one square is marked as intermediate causes the piece to move through the intermediate squares in the order they were marked before stopping at the destination square. The moving piece captures all enemy pieces on the squares it moves through. Note that Ctrl-clicking the selected piece deselects it if no board squares are marked as intermediate.";
	
	private static String fen_code = "FEN Code\n" + 
			"\n" + 
			"Forsythe-Edwards Notation (FEN for short) is a system that provides a way to store board positions in a compact string (called a FEN code or FEN string). Although it was originally designed to describe positions in chess games, the system can naturally be expanded to describe positions for many more games as well. In fact, FEN can be used to support any chess variant with any number of pieces and a finite board size, so long as each piece has a unique ID. The Universal Chessboard uses a FEN system similar to the original, but with a few tweaks that allow it to support as many chess variants as possible.\n" + 
			"\n" + 
			"How FEN Code Works\n" + 
			"\n" + 
			"The extended FEN Code used by the Universal Chessboard works with any finite board size, not just an 8x8 board. However, FEN strings are unique to the game they came from, and cannot be used for other games unless they have the same board size, the same number of piece types, and the same collection of piece IDs. The piece type that an ID points to is irrelevant, but it must be unique, point to a specific (color-independent) piece type, and have at least one English letter. Additionally, all letters in an ID must have the same case. The case of the letter(s) determines the piece's color. Usually, uppercase IDs point to white pieces, and lowercase to black pieces. However, having the line 'shogiMode=true' in the preset file makes the opposite true.\n" + 
			"\n" + 
			"This FEN system also allows for more pieces than those found in chess. Aside from the 26 piece types possible with single English letters, IDs consisting of multiple characters are also supported. The parser treats such IDs are implemented by enclosing them in a set of curly brackets (Ex. {+P}). Because of this, curly brackets cannot be used as part of a piece ID. Any other character may be used, and IDs inside the curly brackets can have any number of characters, as long as one of them is an English letter.\n" + 
			"\n" + 
			"Additionally, this FEN system also allows you to manipulate the content of the holdings by enclosing a series of piece IDs in square brackets. Like with curly brackets, square brackets can only be used for the purpose they were given, and cannot be used as part of a piece ID. Another thing to note about the hand is that only piece IDs are allowed inside the square brackets. Putting anything else results in an invalid FEN string.\n" + 
			"\n" + 
			"The Universal Chessboard's FEN Parser\n" + 
			"\n" + 
			"As a whole, the FEN string describing each position is in a left-to-right, top-to-bottom order from White's perspective. When getting a FEN string from the current board position, the parser begins by describing the leftmost square in rank (number of ranks - 1). This is the top left space on a rectangular board. It then continues to describe the board one rank at a time until it finishes with rank 0. For example, the parser describes the starting position in a chess game like this:\n" + 
			"rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR\n" + 
			"\n" + 
			"Loading a board position from a FEN String is a much more complicated process. When doing this, the parser creates a specialized buffer and stores the new position there as it is created, performing rigorous error checks on every part of the FEN string. The position on the actual board does not change unless there are no errors in the FEN string. If no errors are detected, the new position is copied from the buffer to the string. The game log for currently loaded game is cleared afterward to prevent it from being corrupted by the position change.\n" + 
			"\n" + 
			"The Universal Chessboard's FEN System\n" + 
			"\n" + 
			"Here is a summary of the characters used in the FEN Code:\n" + 
			"\n" + 
			"Slashes: / - These separate individual ranks in the FEN string. In order to be considered valid, the FEN String must contain (number of ranks - 1) slashes that aren't part of an ID enclosed in curly brackets.\n" + 
			"\n" + 
			"Any base-10 number N - represents a series of N empty squares. Minus signs (-) are not treated as part of the number. Numbers may not be used as part of a piece ID, and an InvalidNumberException is thrown when numbers are found inside piece IDs.\n" + 
			"\n" + 
			"Any English letter: a-z or A-Z -> These are the key ingredients of any piece ID. Single letters by themselves can be used as piece IDs in the FEN string, or they can be joined with other characters in an ID enclosed in curly brackets.\n" + 
			"\n" + 
			"Minus Sign: - -> Indicates a hole in the board. Holes are spaces on the board that do not exist. Because of this, they cannot be moved to, nor can they be moved through unless the moving piece is jumping over the hole.\n" + 
			"\n" + 
			"Curly Brackets: {} -> These enclose a piece ID that contains multiple characters. They are not considered a part of the ID itself, and because of this, they cannot be used as part of a piece ID. Note that there must be a closing curly bracket for every opening curly bracket in a FEN rank. An InvalidCurlyBracketException is thrown if unbalanced curly brackets are found or a curly bracket is used as part of a piece ID.\n" + 
			"\n" + 
			"Square Brackets: [] -> These enclose a series of piece IDs that are in the holdings. Like curly brackets, they cannot be used as part of a piece ID. Note that there must be a closing square bracket for every opening square bracket in a FEN rank. An InvalidSquareBracketException is thrown if unbalanced square brackets are found or a square bracket is used as part of a piece ID.\n" + 
			"\n" + 
			"Empty String -> This is a shortcut for indicating an empty rank regardless of the number of files the board has. Note that an empty string has no characters in it. so if you wanted an empty board, you could simply enter a series of slashes (\"///////\" for chess).\n" + 
			"\n" + 
			"Rules\n" + 
			"\n" + 
			"The Universal Chessboard's FEN system has a few rules that every FEN string must follow:\n" + 
			"\n" + 
			"1. The FEN string cannot be an empty string. The parser throws a NullFENCodeException when this rule is violated.\n" + 
			"\n" + 
			"2. The number of ranks in the FEN string must be equal to the number of ranks on the board (nRanks). Because of this, at the very least, it must have exactly (nRanks - 1) slashes that aren't part of a piece ID. Otherwise, a RanksOutOfBoundsException is thrown.\n" + 
			"\n" + 
			"3. No rank can have a square count greater than the number of files on the board. The square count is the sum of all (positive) numbers, the number of piece IDs not enclosed in square brackets, and the number of minus signs in the FEN rank (Ex. The square count for the FEN rank \"-2p{+p}p2[ppp]-\" is 2 + 2 + (2 * '-') + (2 * 'p') + (1 * '{+p}') = 9). Empty strings between slashes are treated as empty ranks. If one rank violates this rule, a FileOutOfBoundsException is thrown. If multiple ranks violate this rule, a FilesOutOfBoundsException is thrown.\n" + 
			"\n" + 
			"4. Slashes, base-10 numbers, English Letters, and minus signs are the only characters that can appear by themselves. All other characters must either enclose a piece ID (curly brackets), enclose a series of piece IDs in the holdings (square brackets), or be used as part of a piece ID with multiple characters. An InvalidCharException is thrown if this rule is broken.\n" + 
			"\n" + 
			"5. All piece IDs that appear in the FEN string must be valid piece IDs for the game the FEN string is being used for, and IDs with multiple characters must be enclosed in a set of curly brackets. If an invalid ID is found, an InvalidPieceIDException or InvalidHandID Exception is thrown.\n" + 
			"\n" + 
			"6. Only piece IDs can appear inside square brackets. If this rule is violated, an InvalidHandIDException is thrown.\n" + 
			"\n" + 
			"FEN Code Exceptions\n" + 
			"\n" + 
			"FEN Code Exceptions are 'exceptions' thrown by the parser when it detects an error in the FEN string it is trying to load. (Note that these are not programming exceptions, but rather strings that the parser uses to populate the error text box). They give a brief explanation of what went wrong. Some exceptions also show which instances of themselves were trigger or where the error occurs in the FEN String. The parser always exits the loading process without doing anything whenever an exception occurs. This means that if you fix one area of your code, you may encounter other errors that need to be fixed before the code can be successfully loaded. Below is a summary of all exceptions thrown by the parser.\n" + 
			"\n" + 
			"Legend for Values in Parentheses\n" + 
			"Instance - The instance number of this exception, ranging from 0 to (number of identical exceptions - 1). Larger numbers occur later on in the loading process, and vice versa.\n" + 
			"Rank N - The Nth FEN rank from the beginning (top-left) of the FEN string contains this error.\n" + 
			"Character N - The Nth character from the left of the FEN rank is causing this error.\n" + 
			"\n" + 
			"NullFENCodeException - Occurs when an empty string is passed to the parser.\n" + 
			"\n" + 
			"RanksOutOfBoundsException(Instance) - Occurs when the number of ranks in the FEN String isn't the same as the number of ranks on the board.\n" + 
			"\n" + 
			"FileOutOfBoundsException - Occurs when a single rank in the FEN String has more files than the number of files on the board. This exception indicates the erronous rank with the Rank N value from the Legend for Values in Parentheses.\n" + 
			"\n" + 
			"FilesOutOfBoundsException - Occurs when multiple ranks have more files than the number of files on the board. This exception indicates the erronous ranks with a comma-separated list of Rank N values from the Legend for Values in Parentheses.\n" + 
			"\n" + 
			"InvalidNumberException(Rank N, Character N) - Occurs when a base-10 digit isn't being used in the way it should be.\n" + 
			"\n" + 
			"InvalidCurlyBracketException(Rank N, Character N) - Occurs when a curly bracket ({ or }) isn't being used in the way it should be.\n" + 
			"\n" + 
			"InvalidSquareBracketException(Rank N, Character N) - Occurs when a square bracket ([ or ]) isn't being used in the way it should be.\n" + 
			"\n" + 
			"InvalidCharException(Rank N, Character N) - Occurs when a character other than a slash, English letter of either case, base-10 digit, or minus sign appears in the FEN string without being part of a valid piece ID, indicating the character that caused this error.\n" + 
			"\n" + 
			"InvalidPieceIDException(Instance) - Occurs when an invalid piece ID is encountered, indicating the piece ID that caused this error.\n" + 
			"\n" + 
			"InvalidHandIDException(Instance) - Occurs when anything other than a valid piece ID appears inside square brackets.";
	
	public static String getKeyBindings()
	{
		return key_bindings;
	}
	
	public static String getFENCode()
	{
		return fen_code;
	}
}
