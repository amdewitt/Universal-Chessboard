package defaults;

public class Modifications {
	private static String mods = "";
	
	public static String getModificationsText()
	{
		return mods;
	}
}
