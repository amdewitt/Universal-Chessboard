package defaults;

public class PieceSetCredits {
	private static String credits = "Chess, Yangsi, Xiangqi, Shogi sets - musketeerchess.com\n\n" + 
			"Mnemonic sets for large Shogi variants (Futashikana, Taishin, Maka Dai Dai Shogi, Taikyoku) - H.G. Muller, expanded by the author, Adam DeWitt\n\n" +
			"Shogi pieces for large Shogi variants - the author, Adam DeWitt, with Special Thanks to pixilart.com";
	
	public static String getPieceSetCredits()
	{
		return credits;
	}
}
