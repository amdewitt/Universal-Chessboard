package board;

public class PieceInHand {
	private int piece;
	private int amount;
	
	public PieceInHand(int piece, int amount)
	{
		this.piece = piece;
		this.amount = amount;
	}
	
	public int getPiece()
	{
		return piece;
	}
	
	public int getAmount()
	{
		return amount;
	}
}
