package defaults;

/**
 * The About class stores the text of the About tab so it can be</br>
 * fetched regardless of whether the program is run in Eclipse or from a .jar file.
 */
public class About {
	private static String aboutText = "Universal Chessboard (WIP) v. Alpha 0.0 - A JavaFX 8 application that allows you to create and play your own chess variants, within certain parameters.\n" + 
			"    Copyright (C) <year TBD>  Adam Michael DeWitt\n" + 
			"\n" + 
			"    This program is free software: you can redistribute it and/or modify\n" + 
			"    it under the terms of the GNU General Public License as published by\n" + 
			"    the Free Software Foundation, either version 3 of the License, or\n" + 
			"    (at your option) any later version.\n" + 
			"\n" + 
			"    This program is distributed in the hope that it will be useful,\n" + 
			"    but WITHOUT ANY WARRANTY; without even the implied warranty of\n" + 
			"    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n" + 
			"    GNU General Public License for more details.\n" + 
			"\n" + 
			"    You should have received a copy of the GNU General Public License\n" + 
			"    along with this program.  If not, see https://www.gnu.org/licenses/gpl-3.0.txt.\n" + 
			"\n" + 
			"Additional Notes\n" + 
			"\n" + 
			"What the GNU General Public License Applies To \n" + 
			"\n" + 
			"It is important to note that the GPL only applies to the project itself. It does not apply to the chess variants created and/or played using this project, nor does it apply to board diagrams, board positions, FEN codes, move sequences, game logs, and piece fonts.\n" + 
			"\n" + 
			"The chess variants created and/or played using this project belong to their respective owners or are in the public domain. Additionally, board diagrams, board positions, FEN codes, move sequences, game logs, and piece fonts are considered to be in the public domain unless stated otherwise. However, credit should always be given where credit is due.\n" + 
			"\n" + 
			"Documenting Modifications\n" + 
			"\n" + 
			"If you modify a copy of this project, the GPL requires that you let others know that you modified it, along with the date of modification. You should document your changes by typing the documentation in a text (.txt) file, converting it to a Java string, and placing said Java string into the mods field of the Modifications.java file, which can be found at the following relative path \"Universal_Chessboard/src/defaults/Modifications.java\". The application will automatically add a Modifications item to the Help Menu which shows the contents of this file if it isn't empty. Note: If you view the Modifications class in an IDE, pasting the regular text in the appropriate spot will convert the text into a Java string for you.\n" + 
			"\n" + 
			"The author is not responsible for anything that goes wrong when using a modified copy of this project.\n" + 
			"\n" + 
			"External Links\n" + 
			"\n" + 
			"You can find the project source code on GitHub as an Eclipse IDE Project at the following URL: https://github.com/amdewitt/Universal-Chessboard\n" + 
			"\n" + 
			"You can contact the author via e-mail at adammichaeldewitt@gmail.com.";
	
	public static String getAboutText()
	{
		return aboutText;
	}
}
